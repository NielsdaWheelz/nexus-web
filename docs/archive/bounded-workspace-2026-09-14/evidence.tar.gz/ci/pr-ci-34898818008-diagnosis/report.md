# completed ci preflight comparison

status: naturally completed failure; read-only artifact review.
origin: https://github.com/NielsdaWheelz/nexus-web/actions/runs/34898818008

new workflow head:b6928c60a32e8cc651cb9511097b9cb12ae70994.
new receipt:f6f40be0753d0bb5, controller source90b2a441e262fad03137c7a4a426af29c9aae52c.
base remains051a57b780ef2bd8785e2a2abf37b44e10999d85.

| controller receipt | elapsed to terminal/first failure | retained selections | distinct selected source paths | primary failure |
| --- | --- | --- | --- | --- |
|52653c1fbd4ef3d8 (workflow34896942860, head dd21213)|967.276s|36271|2444|old caption coherent-owner pin|
|f6f40be0753d0bb5 (workflow34898818008, head b6928c60)|108.687s|36275|2448|worker fault target outside product allowlist|

the later source includes local glob-match reuse. the complete preflight
interval fell between these naturally completed runs, with four additional
selected paths/records. this is not an isolated matcher benchmark: policy
metadata changed and failure occurred at different guards; no per-phase stack
or timings were retained. exact selector output regression and later complete
execution remain distinct required evidence. no elapsed threshold is invented.

new exact error: manifest row230, fault-product-only, apps/worker/main.py.
this is the already corrected registry-fault source problem; it is not a new
product failure. both runs produced synthetic policy/controller failure before
any capability process. all12 other capabilities are not_run; command, browser,
runtime and build evidence arrays remain empty. new owned peak is214mib
process-tree rss, zero container working set (earlier218mib). no memory
qualification follows from this preflight-only comparison.

the latest job selected-proof step ran21:27:30–21:29:23UTC. upload/runtime cleanup/
generated-build cleanup succeeded; Enforce proof result failed as intended.
no workflow or resource was modified or cancelled by this review.

summary sha256:3f4386822bcbf5a7902c3be84391df233d9344e7b0b869ef1a5fe8acd445ba18.
artifact retained at /tmp/pr-ci-34898818008-artifact.
existing oi-223 owns the latency evidence; no additional ticket is needed.
