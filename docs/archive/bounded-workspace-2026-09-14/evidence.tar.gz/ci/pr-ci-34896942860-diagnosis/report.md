# completed pr ci evidence

status: naturally completed failure; read-only diagnosis.
origin: https://github.com/NielsdaWheelz/nexus-web/actions/runs/34896942860

workflow head: dd21213bfaca8650e60049d939c7b2195240820e.
controller source recorded in its receipt:2431480c382242bba1a291ec8ef769d4e64fc49b.
base:051a57b780ef2bd8785e2a2abf37b44e10999d85.
receipt:52653c1fbd4ef3d8.

controller duration and first-actionable-failure fields both equal967276ms
(16m7.276s). selection completed enough to retain36271 selection records across
2444 distinct source paths. fixed_commands, browsers, runtime and build context
are all empty. policy is a synthetic controller failure; all12 other capabilities
are not_run. no product assertion or runtime qualification executed.

the exact failure is fault-coherent-owner-drift at manifest row222. at the
workflow head this is reader-epub-caption-loss, with owner79df181b. current main
b6928c60 carries its reviewed replacement3a193352. that disposition is separate
from this failing old receipt; this report makes no replay claim. the other
current worker fault path problem was not reached by this old run's primary
failure and remains a separate reviewed draft.

reported owned peak is218mib process-tree rss and zero container working set.
the earlier one-cpu observation is consistent with controller preflight work,
but no stack was obtained and the artifact does not isolate per-phase selection
time. do not present the full967.276s as a measured _glob_matches duration or a
verified improvement baseline. retain it as the exact unoptimized controller
preflight interval and compare later actual observations with that scope.

upload, runtime cleanup and generated-build cleanup steps succeeded. final
Enforce proof result failed as intended. no workflow/resource was modified,
cancelled or cleaned by this audit. existing oi-223 records the selection issue;
no additional defect was discovered beyond the known coherent-caption pin.

summary sha256:03ee0389f59b898bd0903d2081c0fbb47066f3b04c78a88251ccd9bd30b7e6c0.
artifact retained at /tmp/pr-ci-34896942860-artifact.
