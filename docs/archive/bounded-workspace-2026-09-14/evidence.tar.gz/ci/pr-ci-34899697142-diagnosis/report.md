# pr ci 34899697142

status: completed failure; read-only diagnosis
origin: github workflow 34899697142, completed 2026-09-14t21:44:55z
area: selected pr proof

workflow head: 0d3b2164aea65bf06f5948b31ecb1e59e58e1f11. tested merge source: e6f342ff92fdde23a605f7172ab36cea3f941ef8; base: 051a57b780ef2bd8785e2a2abf37b44e10999d85. receipt: 538ee89bdfb8ce0c.

policy passed in 8,389 ms. static-python then failed its first ruff command in 267 ms: import ordering in runner.py and tests/conftest.py, undefined claim_job in test_bounded_media_extraction.py2445, and unnecessary utf-8 encode in test_epub_structural_anchors.py243. current source retains these four findings; root assigned their correction to client. no behavioral capability executed; all eleven later capabilities were blocked at 0 ms. no browser, build or container runtime was started by this receipt. upload and both runtime/build cleanup steps succeeded; final enforcement correctly failed the job.

receipt elapsed / first actionable failure: 466598 ms. selected records: 36275; distinct source paths: 2448. peak process tree rss: 236 mib; container working set: 0. this total elapsed time is not a measured selection-only duration or a matcher performance attribution.

preview lookup was stopped after root confirmed the github success status for the requested deployment at 0d3b. no separate vercel deployment inspection or runtime verification is claimed.

retained raw summary: /tmp/pr-ci-34899697142-artifact/nexus-test-pr-34899697142/runs/538ee89bdfb8ce0c/summary.json
sha256: 2095d0897254a3808413e66680f344844f7e2c2697f0654067cfb14e41343140

retained raw command log: /tmp/pr-ci-34899697142-artifact/nexus-test-pr-34899697142/runs/538ee89bdfb8ce0c/static-python-1.log
sha256: 70fda69dc28c71073a64f9316dbdd525f0915ce10e950b48ec29a1f7db69c06a

retained run context: /tmp/pr-ci-34899697142-artifact/nexus-test-pr-34899697142/runs/538ee89bdfb8ce0c/run-context.json
sha256: f83d74e19deeee58c5bddf4544a3fbbd33ef8748785bb89a4fd48d816291c7d6

raw github status: /tmp/pr-ci-34899697142-run.json

no tests, main edits, cancellations, cleanup operations or deployments were performed for this audit.
