# native retry-after design review

status: source/design review only; no main edits or tests
origin: oi-204 peer review, 2026-09-14
area: existing native transfer/store/job scheduler

no design blocker found in the six-owner candidate plus the revised checkpoint callback. the accepted shape is one nullable instant on the existing transfer row. no new scheduler, delay policy, job id, sleeper or retry counter is needed.

the scalar must remain separate from queued reason: OfflineReadingStore.reclassifyTransfersForPolicyChange rewrites state_json for inactive rows. existing copy operations retain the scalar. deferForServerCapacity keeps the maximum recorded floor and changes only the exact current id/staging row. the service retains its current run-generation callback fence. after account purge the old row is absent; begin-only transition already closes claim through the existing binding/transition checks.

nextRunnableTransfer checks the floor before legacy generation selection, token mint, package or baseline network calls. hasQueuedWork continues to mean durable demand for ensureScheduled. runnerCheckpoint instead checks eligible work and gives its existing finish callback reschedule=true for durable deferred work under the same queue lock. this avoids both an idle spin and loss of the os retry. no minimum-latency user-initiated job is introduced.

startup cleanup currently preserves only schema-one conversion staging. retaining the exact archive and verified-directory names owned by current nonfailed transfer rows is required to preserve a capacity refusal across reopen. interrupted active rows are reconciled first and already remove/rotate their old staging; unrelated files remain orphan cleanup candidates.

required proof boundaries, not yet executed:
- actual origin socket responses: seconds and http-date, absent header preserving old backoff, invalid/repeated/unrepresentable values following the declared existing error contract;
- actual store + job checkpoint: early wake makes no eligible claim and finishes with retry requested; exact boundary becomes eligible; another eligible row can drain;
- exact staged archive and verified bytes, selected generation and row identity survive real database close/reopen and inactive network-policy rewrite;
- stale staging/id callback after replacement or account purge cannot change a successor; begin-only account transition keeps claims closed;
- actual v3-to-v4 migration preserves every old row and adds a null floor. v1 fixture reconstructs historical columns by dropping retry_not_before too; original row, foreign-key and source oracles remain intact.

these observations do not attest actual android execution, automatic retry timing, or candidate green. final mutable draft/proof hashes remain publication's handoff responsibility.
