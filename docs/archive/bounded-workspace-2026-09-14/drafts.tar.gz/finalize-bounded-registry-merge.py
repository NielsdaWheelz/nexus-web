import json,pathlib,subprocess,hashlib
repo=pathlib.Path('/home/niels/src/personal/nexus-web-bounded-workspace');D=json.load(open('/tmp/bounded-registry-merge-inputs.json'));draft=pathlib.Path('/tmp/bounded-registry-resolved-draft')
# Keep the bounded source/reader/archive contract. Only independently reviewed upstream contracts survive.
kept_new={'article-semantic-main-bypass','test-linked-runtime-port-reservation-bypass','browse-provider-query-round-trip-bypass','worker-provider-execution-import-bypass'}
p='testdata/faults/manifest.json';f=json.loads((draft/p).read_text());heads={r['id']:r for r in D[p]['head']['faults']}
f['faults']=[r for r in f['faults'] if r['id'] in heads or r['id'] in kept_new]
for i,row in enumerate(f['faults']):
 if row['id'] in {'offline-reading-mixed-publication-generation','reader-position-end-locus-bypass','document-map-pulse-early-release','epub-structural-anchor-preservation-bypass','reader-restore-write-suppression-bypass'}:
  f['faults'][i]=dict(heads[row['id']])
 if row['id']=='document-import-parser-dimension-bypass':f['faults'][i]['changed_owner_sha256']='55b240c98613d67828972e182f0db6748e1c7190be23fcba1453fe9d3a12f0bc'
# Structural fixture preserves every previous oracle and adds visibility; actual hashing includes reviewed imports/support.
for row in f['faults']:
 if row['id']=='epub-structural-anchor-preservation-bypass' and 'changed_owner_sha256' in row:row['changed_owner_sha256']='3b427bef4287f0a055c186b057dfa05c6d5ac1c54bb463e503b0213c13fd199d'
(draft/p).write_text(json.dumps(f,indent=2)+'\n')
p='testdata/manifest.json';corpus=D[p]['head'];(draft/p).write_text(json.dumps(corpus,indent=2)+'\n')
p='testdata/proofs.json';proofs=json.loads((draft/p).read_text());headrisks={r['id']:r for r in D[p]['head']['priority_risks']}
excluded_sources={'apps/android/app/src/main/java/app/nexus/android/offline/reading/OfflineReaderDocumentVerifier.kt','python/nexus/services/reader_structure.py','python/nexus/services/epub_structure.py','apps/web/src/components/reader/ReaderDocumentMap*.tsx','apps/web/src/lib/reader/usePendingDocumentMapPulse.ts'}
excluded_proofs={'pytest:python/tests/migrations/test_reader_structure_migration.py::test_reader_structure_repair_preserves_fragment_identity_and_cursor','pytest:python/tests/migrations/test_web_reader_cursor_migration.py::test_reader_structure_repair_reanchors_only_exact_stale_web_cursors','pytest:python/tests/service/test_reader_cursor_admission.py::test_document_cursor_admits_only_owned_source_addresses','vitest:apps/web/src/components/reader/ReaderDocumentMapOverviewRail.browser.test.tsx','vitest:apps/web/src/components/reader/ReaderDocumentMapDetail.browser.test.tsx','vitest:apps/web/src/lib/reader/usePendingDocumentMapPulse.browser.test.tsx','pytest:python/tests/service/test_epub_structural_anchors.py::test_epub_structure_preserves_semantic_sections_across_render_units','pytest:python/tests/service/test_epub_structural_anchors.py','pytest:python/tests/service/test_offline_reading_package_delivery.py::test_direct_package_is_account_generation_integrity_and_replay_bound'}
for row in proofs['priority_risks']:
 row['source_globs']=[v for v in row['source_globs'] if v not in excluded_sources]
 row['proofs']=[v for v in row['proofs'] if v not in excluded_proofs]
 if row['id']=='citation-provenance-identity':
  canonical='pytest:python/tests/service/test_epub_structural_anchors.py::test_epub_ingest_repairs_structural_anchors_without_reordering_intervals'
  if canonical not in row['proofs']:row['proofs'].append(canonical)
for row in proofs['journeys']:
 if row['id']=='reader-progress-resume':
  original=next(x for x in D[p]['head']['journeys'] if x['id']==row['id'])
  row['source_globs']=original['source_globs']
(draft/p).write_text(json.dumps(proofs,indent=2)+'\n')
# Restore delivery test inputs/faults by exact Git bytes before installing the reconciled manifests.
def git(ref,p):return subprocess.check_output(['git','show',f'{ref}:{p}'],cwd=repo)
def paths(ref):return subprocess.check_output(['git','ls-tree','-r','--name-only',ref,'testdata'],cwd=repo,text=True).splitlines()
head_paths=set(paths('HEAD'))
for p in head_paths:
 target=repo/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(git('HEAD',p))
for row in f['faults']:
 target=repo/row['patch']
 if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==row['sha256']:continue
 for ref in ['origin/main','01b5b6d5db^']:
  try:blob=git(ref,row['patch'])
  except subprocess.CalledProcessError:continue
  if hashlib.sha256(blob).hexdigest()==row['sha256']:
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(blob);break
 else:raise RuntimeError('no reviewed patch matches '+row['id'])
keep=head_paths|{r['patch'] for r in f['faults']}
for p in (set(paths('origin/main'))|set(paths('01b5b6d5db^')))-keep:
 target=repo/p
 if target.is_file():target.unlink()
for p in D:(repo/p).write_bytes((draft/p).read_bytes())
print('faults',len(f['faults']),'corpus',len(corpus['artifacts']),'risks',len(proofs['priority_risks']))
