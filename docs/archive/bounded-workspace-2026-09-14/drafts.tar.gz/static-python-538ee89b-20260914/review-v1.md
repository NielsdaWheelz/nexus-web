# retained ci static repair draft

status: drafted; execution pending. origin: ci 34899697142, retained run 538ee89bdfb8ce0c, synthetic source e6f342ff, 2026-09-14. area: python proof composition.

all four reported findings are represented in product-and-proof-v1.patch. it is based on current delivery f1b8ea6bf487ffefe70bb146ad05957f4b974058, which already contains the separately reviewed reporter redaction. main was not modified.

- runner.py: remove the second empty line between imports and the first module assignment. import order and values are unchanged.
- tests/conftest.py: the same correction before pytest_plugins. preserve the collection-time network guard and plugin registration order.
- test_bounded_media_extraction.py: finish the missed migration in test_in_flight_source_progress_serializes_through_the_declared_media_wire. existing testkit claim_job_row calls the real queue claim and unwraps its row; the current queue returns ClaimedJob rather than JobRow. pass that row's execution_id into the required execution context and its attempts into completion. otherwise the undefined-name repair would expose two missing-required-argument failures. no new adapter, invented claim, or weakened serialization/progress assertion.
- test_epub_structural_anchors.py: replace the ascii-only container string's default utf-8 encoding with identical bytes literals. source paths, nesting, ids, bytes and all anchor assertions stay unchanged.

contract evidence: tests/testkit/queue_claims.py:17 calls nexus/jobs/queue.py:871; JobExecutionContext at queue.py:130 requires execution_id; complete_job at queue.py:2098 requires attempt_no. the two neighboring extraction proofs already use these same current contracts.

no coherent metadata change is needed. the parser-dimension exact owner remains 55b240c98613d67828972e182f0db6748e1c7190be23fcba1453fe9d3a12f0bc; only a sibling test changes. the structural-anchor exact owner likewise remains 196427bb6351850d893e5d99d89140e9ad11d8f00858cf1b9975262bfcc37b7d and has no coherent opt-in. runner is product code; conftest keeps its normal imported-support identity without changing any pinned source slice.

source and exact-owner hashes are retained in inventory-v1.json. no formatter, lint, policy or behavior command was executed. the four static errors are actual ci evidence; the two follow-on missing arguments are source-confirmed findings, not executed failures. next paved selection should include the corrected exact media-wire test and long-navigation-id test alongside required static-python; canonical proof/fault semantics are unchanged.
