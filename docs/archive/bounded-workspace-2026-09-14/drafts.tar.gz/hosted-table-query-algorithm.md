# selected-cell query: concrete algorithm review

status: design only, no endpoint or product edits. source: current python sparse
producer and native OfflineReadingTableHeaders.kt characterization, including
its literal-slot differential oracle. no new latency or allocation limit.

## exact candidate relations

let the principal rectangle be [r,re) x [c,ce), and source ordinal identify a cell
within the exact retained generation/fragment/table. preserve that ordinal:
geometry order differs from authored order when footers are deferred.

1. select the principal by original (row,column), and the table/caption row.
   an authored headers attribute, even empty/invalid, selects the explicit path.
2. explicit: join only that principal's already-deduplicated targets to source
   cells; filter self/empty, including allowed td targets. page by authored target
   ordinal. no automatic or group fallback.
3. horizontal candidates: column_start < c AND row_start < re AND row_end > r.
   vertical: row_start < r AND column_start < ce AND column_end > c.
   EXISTS for a nonempty matching row/column header can omit an irrelevant axis.
   for an active axis retain EVERY intersecting cell, including empty/data/none/
   other header kinds: they change unique coverage and opacity even when they
   cannot be returned.
4. group append is source-order keyset SQL. rowgroup headers share the principal's
   nonnull row_group. colgroup headers anchor inside the group containing the
   principal anchor column. both require row_start < re AND column_start < ce,
   nonempty and not principal. exclusive header kinds make both group phases and
   automatic phases disjoint; these joins need no all-result dedup set.

use a small number of SELECTs with bounded fetch batches, not a round trip per
cell/event. exact principal/target joins and source-ordinal/group indexes mirror
the native schema. an id keyset limits returned rows, not physically scanned
nonmatching cells; plans and buffer reads must show that price. reading scalar
geometry for one table is acceptable to characterize; it reads no HTML, canonical
text, units or metadata chain. join full source ranges only for the output page.

## minimal automatic reduction to characterize first

start with a small source-endpoint ray reducer in the existing selected-query
proof boundary, before choosing an interval-tree optimization:

- read candidate scalars into compact fixed-width columns, not ORM objects or
  per-cell metadata models; retain ordinal, rectangle, kind/empty and original
  orthogonal anchor/span for opacity;
- split the principal outer extent at candidate endpoints; every ray within one
  resulting band has identical coverage and header semantics;
- traverse outer bands ascending. sweep inner start/end events from principal
  edge toward zero; process the whole same-coordinate event batch. visit only
  intervals with exactly one covering cell. gaps and overlaps do not reset the
  previous unique-cell identity;
- per ray retain last unique cell, current header-block span keys and opaque
  span keys. data moves the block into opaque. a header adds its original
  orthogonal anchor/span to the block and emits only if its key is not opaque,
  its kind matches the axis and it is nonempty. initialize the block with the
  principal span when principal is not data;
- retain each returned cell at its first occurrence only. order is horizontal
  then vertical, outer ascending, inner descending, source ordinal. append the
  two disjoint group phases afterward.

this follows the independent literal oracle with source interval jumps, not the
native disk tree. huge implied coordinates cause no per-slot storage or loops.
it exposes cost before spending complexity on another optimized reducer.

## bounds and rejection criteria

N = candidate cells, B = distinct outer bands, H = unique results. B <= 2N+1 per
axis. sorting inner events per band costs O(B*N*log N), with O(N+H) live scalar/
state storage; one reusable sorted inner order removes repeated sorting but
still permits O(B*N) work. these are worst cases, not a latency qualification.
a single current EPUB table has fewer than 100,000 source elements under its
entry budget; that bound cannot be borrowed for every historical/web source.
rowspan=0 can grow beyond 65,534 with its group. colspan<=1000 does not make a
quadratic worst-case baseline an acceptable release guarantee.

this reducer is a measurement baseline, NOT a maximum-service guarantee. use
actual source-formable sparse, late-irrelevant, 8k overlap, maximum structural and
repeated-selection cases. retain SQL rows/buffers, scalar bytes, process peak
and first/full result times. if repeated-band work fails, a local endpoint tree
can reuse native coverage semantics without its SQLite calls; it must earn the
extra state on the same corpus. the native group-keyed opacity intervals have
no independently established linear-in-N worst-case size yet. its linear tree
does not by itself prove linear total scratch.

reject dense grids/per-implied-row loops, rectangle self-joins materializing
quadratic pairs, automatic pairs for every cell, per-node PostgreSQL calls,
Python model corpora with no measured price, and guessed admission increases.

## continuation remains an ownership decision

the native reducer retains result and reduction state across page() calls. the
hosted HTTP view has no equivalent cross-request owner. a signed ordering tuple
cannot remember all emitted ids or opaque intervals. recomputing from the start
and filtering result_key > after is correct pagination, but IS prefix
recomputation. do not call it a seek-bound query.

explicit/group-only paths page directly. automatic continuation requires either
explicitly accepting and qualifying recomputation, retaining this selected
query's state/results under a concrete lease owner that spans HTTP requests, or
proving a different independent first-occurrence predicate with bounded work.
no current hosted owner supplies option two; option three is not established.
do not invent a query cache/lifetime, encode a source-sized seen set in a cursor,
or freeze a wire that conceals the choice. the earlier no-prefix-rescan demand
and current stateless HTTP shape are not jointly solved by the native reducer.

## runtime fragmentation witness to measure

runtime's source inspection supplies a stronger work witness, not yet an
executed producer receipt: first tbody row has m adjacent scope=row rowspan=0
far headers, an ordinary td gap, one scope=row rowspan=0 near header, then a
rowspan=0 principal td. append n rows alternating a td colspan=2 and an empty tr.
occupied far columns force later td into the gap, overlapping only near. one
exact header-span group's nearest-header state alternates by row; every farther
same-span header revisits those pieces in the native header() loop. predicted
work is omega(m*n) with O(m+n) source, colspan only 2 and O(n) state. source
geometry and literal small cases must establish the recipe before performance
claims. this defeats an unproved colspan-based bound on whole-query work.
