# retained receipt canonical disposition

status: draft; main frozen at 5d687cdc8a; no source edit or test run

## current owner

`production-release-test-control` registers exactly one node for this path:
`pytest:python/tests/kernel/nexus_test_control/test_policy.py`.
there is no fault row for any node in that file, no exact alias, and no
changed-owner coherent pin. imports and `_minimal_repository` do change the
whole-file proof, but cannot drift a nonexistent fault pin. no existing pin,
priority ownership floor or proof registration should be refreshed.

current file sha256: `380ad61c475346f40a546835ae1b937a2c520670c2eb90147435ff002944dcba`.
v1 candidate: `82a5157ee5ea95988fc8bfec354fca237674927580a0c0f9cd7f2ab035344f86`.
v2 candidate: `d79850a760793535f16dccf0cb1bb559303fcbcdb3ebced55ee222f593320920`.
v3 candidate: `cf793a0c093ee2c3904f50d859d62a78ef3b60d2c55525be300f904d6d1ec7ea`.
v2 adds only the explicit diagnostic `missing receipt evidence was accepted`
(through the existing parameterized assertion); all oracle conditions are unchanged.
policy source remains v1 candidate
`4c240c27ea557022f68543776f3bd56b925ddb9d990f3eea6608b17e121d524a`.

## minimal fault and registration

`bounded-dossier-receipt-reference-bypass.patch` changes one product conditional
in `bounded_receipt_violations`: the missing-reference violation is suppressed.
it does not change proof data, the index, serializers, hash validation, status
classification, helpers, imports, or assertions.

register it against the EXISTING whole-file canonical node. the new fault id is
`bounded-dossier-receipt-reference-bypass`; expected assertion fingerprint text
is `missing receipt evidence was accepted`. no temporary alias is needed: the
existing canonical node has no fault owner to displace. the full ordinary policy
proof remains registered and executed.

`retained-receipt-fault-registration-v1.patch` appends just that row to the fault
manifest. it has no coherent-fault fields. `testdata/proofs.json` stays byte-identical.
index changes already select POLICY through the existing `testdata/` route;
policy source changes select policy self-tests and kernel-python. the v1
`_CONTROL_DATA` addition exempts this closed control record from fixture corpus
registration; it does not weaken corpus checks for ordinary artifacts.

## exact selections after reviewed integration and commit

ordinary:

`./scripts/test changed python/tests/kernel/nexus_test_control/test_policy.py`

explicit canonical sensitivity:

`./scripts/test prove --proof pytest:python/tests/kernel/nexus_test_control/test_policy.py --against fault:bounded-dossier-receipt-reference-bypass`

the missing parameter runs before the other mutation parameters. the candidate
must first accept the complete historical failed receipt; after removing its
row the fault must cause the explicit assertion to fail. import/setup failure
cannot satisfy the named assertion fingerprint.

## BASE-compatible public owner

v3 removes the new checker import from the proof. both new cases call the
existing `repository_violations` public boundary; the synthetic case starts from
the existing `_minimal_repository`, then retains the exact real failed receipt.
this proves the checker is actually wired into policy, not just callable in
isolation. no assertion condition or historical payload is weakened.

`_base_overlays` already includes all `testdata`, so candidate receipt metadata
is available to an unfixed BASE without a new overlay or controller mechanism.
BASE has the public policy function but lacks the new reference check, allowing
the missing-reference case to reach its behavioral assertion. this is source
reasoning, not an executed BASE red; unrelated older support differences must
still be reported honestly if they prevent execution.

explicit FAULT evidence does not rewrite the normal PR changed-owner rule.
there is no coherent override, new exact canonical alias, ownership-floor
refresh, or hidden BASE bypass. retain the existing whole-file canonical node.
