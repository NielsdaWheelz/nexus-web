# bounded receipt retention draft

status: draft; no main edit, policy run, or ticket closure
origin: 2026-09-14, main audit began at 318747fb5c; root committed a5c84ebc3d while metadata was read

## recovered metadata

all 680 exact 16-hex tokens in the four current progress dossiers are real run
ids with matching v3 summary and run context. no nonreceipt 16-hex token, missing
pair, conflicting copy, or missing referenced artifact was found. longer source,
input and artifact hashes were excluded by exact token boundaries.

306 pairs live in the delivery worktree; 374 in its task proof worktrees. the
reviewer checkpoints hold no exclusive cited pair. the complete path/hash/size
inventory is `inventory-v1.json`; artifact locations/sizes are in
`linked-artifacts-v1.json`. these local paths are discovery information only.

verdicts remain exactly 417 pass, 259 fail, 4 not_run. the 1,360 original metadata
files total 3,865,799 bytes; the largest pair is 28,941 bytes. 932 linked artifacts
exist (37,763,863 bytes); no artifact body was copied into this draft. all 209
recorded git commit objects remain available locally.

## retained index

proposed committed path: `testdata/evidence/bounded-workspace-receipts.json`.
`bounded-workspace-receipts-v1.json` contains one compact row per receipt, the
exact existing summary/context payloads, their original sha256 values, and each
referenced artifact's name, size and actual content hash. artifact names are
historical labels, not evidence that their bodies are committed or fetchable.

all original metadata files reproduce exactly through the existing serializer
form (`json.dumps(..., indent=2, sort_keys=True) + "\n"`). the 3,303,054-byte
index therefore retains original-byte provenance without a parallel summary
projection or 1,360 extra files. stored capability detail can contain the
controller's already-bounded failure tail; no separate raw log was imported.

summary/context are the controller's intended retained proof metadata. the draft
was checked for private-key markers, standard provider credential forms,
unredacted bearer values and credentialed urls: no matches. this does not
reconstruct each historical process's secret-redaction input. actual browser,
runtime/template, build, invocation and sensitivity/source identity fields are
preserved exactly where present. absent image/schema/input identities stay
absent. no source-sized fixture payload, response body or environment dump is
included.

## policy/proof draft

`retained-receipt-policy-v1.patch` changes only the existing policy owner and its
existing kernel proof file. it adds the index to existing control-data ownership
and a fixed four-dossier check through `repository_violations`, `_load_json`,
`_resolved_repository_file`, `_safe_relative`, `_SHA256` and `PolicyViolation`.

it rejects malformed/duplicate rows, altered original summary/context bytes,
wrong run identities and unresolved exact dossier references. it preserves
historical fail/not_run statuses. no executable launcher, receipt service,
generic registry, live path resolver or test run is introduced.

the existing `run_evidence_from_json` and `prove_evidence_from_json` recompute
proof digests against the current checkout. they are intentionally unchanged:
calling them on historical receipts would confuse archive integrity with
current proof validity. the new check verifies original-byte identity and
reference coverage only; it does not upgrade old receipts to current acceptance.

proof draft: actual four-dossier coverage plus a real retained failed receipt in
the existing temporary repository fixture; removing it, changing its summary or
context without the original digest, or duplicating it must fail. setup keeps
all exact metadata and does not forge a passing historical result.

next paved selection after review/integration:

`./scripts/test changed python/tests/kernel/nexus_test_control/test_policy.py`

canonical sensitivity remains required: omit only the dossier-reference
rejection, then require the missing-reference case to fail at its assertion and
the restored policy to pass. do not treat malformed-index setup as that red.

## limits retained

487 runs contain no sensitivity record; 308 contexts have no runtime, build or
browser identity (many are early/setup/native-only records). receipt availability
does not strengthen their actual scope. ordinary runs executed against dirty
snapshots can record only their base git head; e.g. 7c0e3c428b6814cb records
7fa89b88..., while its newly introduced owner did not exist in that commit.
existing dossier/source inventories remain necessary to establish that source.
this index neither invents missing source attestation nor closes combined replay,
resource qualification or oi-217.
