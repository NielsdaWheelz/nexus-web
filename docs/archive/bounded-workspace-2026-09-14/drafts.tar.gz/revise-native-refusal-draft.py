from pathlib import Path
import json,difflib,hashlib,shutil
root=Path('/home/niels/src/personal/nexus-web-bounded-native-proof');out=Path('/tmp/native-conversion-refusal-draft')
old=Path('/tmp/native-conversion-refusal-draft-v1')
if not old.exists():shutil.copytree(out,old)
p=out/'inventory.json';d=json.loads(p.read_text())
def edit(name,fn):
 src=root/name;f=out/name;s=(f if f.exists() else src).read_text();t=fn(s);assert s!=t,name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(t);d['files'][name]={'base_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'draft_sha256':hashlib.sha256(f.read_bytes()).hexdigest()};(out/(src.name+'.diff')).write_text(''.join(difflib.unified_diff(src.read_text().splitlines(True),t.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
base='apps/android/app/src/main/java/app/nexus/android/offline/reading/'
def store(s):
 s=s.replace('import android.system.Os\n','import android.system.Os\nimport android.system.ErrnoException\n',1)
 s=s.replace('''    data class Deferred(override val snapshot: ReadingStoreSnapshot) :
        OfflineReadingReconciliationOutcome
}''','''    data class Deferred(override val snapshot: ReadingStoreSnapshot) :
        OfflineReadingReconciliationOutcome

    data class Failed(override val snapshot: ReadingStoreSnapshot, val cause: Exception) :
        OfflineReadingReconciliationOutcome
}''',1)
 a='''    override fun syncDirectory(directory: File) {
        val descriptor = Os.open(directory.absolutePath, OsConstants.O_RDONLY, 0)
        try {
            Os.fsync(descriptor)
        } finally {
            Os.close(descriptor)
        }
    }'''
 b='''    override fun syncDirectory(directory: File) {
        try {
            val descriptor = Os.open(directory.absolutePath, OsConstants.O_RDONLY, 0)
            try {
                Os.fsync(descriptor)
            } finally {
                Os.close(descriptor)
            }
        } catch (error: ErrnoException) {
            // Kernel resource failures are retryable. Invalid descriptors,
            // arguments and other programming failures keep their exact cause.
            when (error.errno) {
                OsConstants.ENOENT -> throw NoSuchFileException(directory.path).apply { initCause(error) }
                OsConstants.EIO, OsConstants.ENOSPC, OsConstants.EDQUOT,
                OsConstants.EACCES, OsConstants.EPERM, OsConstants.EROFS,
                OsConstants.ENOMEM, OsConstants.EMFILE, OsConstants.ENFILE ->
                    throw IOException("directory durability unavailable: ${directory.path}", error)
                else -> throw error
            }
        }
    }'''
 assert s.count(a)==1;s=s.replace(a,b,1)
 a='''    private val reconciliationCallbacks =
        mutableListOf<(OfflineReadingReconciliationOutcome) -> Unit>()'''
 b=a+'''
    // One callback in the existing completion list coalesces explicit retries
    // that overlap a run whose snapshot still contains the previous refusal.
    private val retryReconciliation: (OfflineReadingReconciliationOutcome) -> Unit = { requestReconciliation() }'''
 assert s.count(a)==1;s=s.replace(a,b,1)
 a='''                    check(database.writableDatabase.update("offline_reader_packages", values, "id = ?", arrayOf(installed.id.toString())) == 1)
                }
                true'''
 b='''                    check(database.writableDatabase.update("offline_reader_packages", values, "id = ?", arrayOf(installed.id.toString())) == 1)
                }
                if (reconciliationRunning && retryReconciliation !in reconciliationCallbacks) {
                    reconciliationCallbacks += retryReconciliation
                }
                true'''
 assert s.count(a)==1;s=s.replace(a,b,1)
 s=s.replace('''    fun reconcileAsync(callback: (ReadingStoreSnapshot) -> Unit) {
        requestReconciliation { outcome -> callback(outcome.snapshot) }
    }''','''    fun reconcileAsync(callback: (OfflineReadingReconciliationOutcome) -> Unit) {
        requestReconciliation(callback)
    }''',1)
 a='''            } else {
                // The old fixed-ID job must ask JobScheduler to retain ownership until unlock.
                callback(OfflineReadingStalePolicyJobFinish.Retry)
            }
        }
    }'''
 b='''            } else if (outcome is OfflineReadingReconciliationOutcome.Deferred) {
                // The old fixed-ID job must ask JobScheduler to retain ownership until unlock.
                callback(OfflineReadingStalePolicyJobFinish.Retry)
            } else {
                // The cause has been reported; a defect must not spin the job.
                callback(OfflineReadingStalePolicyJobFinish.Complete)
            }
        }
    }'''
 assert s.count(a)==1;s=s.replace(a,b,1)
 s=s.replace('''        var suspendedForTransition = false
        try {''','''        var suspendedForTransition = false
        var failure: Exception? = null
        try {''',1)
 a='''        } catch (error: Exception) {
            if (error !is IOException && error !is SQLiteFullException && error !is SQLiteDiskIOException &&
                error !is OfflineReadingBindingSealLockedException) throw error
            // External resource deferral retains the existing closed exposure.
            android.util.Log.e("OfflineReading", "reconciliation could not access its storage", error)
        } finally {'''
 b='''        } catch (error: Exception) {
            if (error is IOException || error is SQLiteFullException || error is SQLiteDiskIOException ||
                error is OfflineReadingBindingSealLockedException) {
                android.util.Log.e("OfflineReading", "reconciliation could not access its storage", error)
            } else {
                failure = error
                android.util.Log.e("OfflineReading", "package reconciliation defect", error)
            }
        } finally {'''
 assert s.count(a)==1;s=s.replace(a,b,1)
 a='''                if (epoch != reconciliationEpoch) {
                    // A durable account transition owns exposure now; stale verification is ignored.
                    verifiedPackages.clear()
                }'''
 b='''                if (epoch != reconciliationEpoch) {
                    // A durable account transition owns exposure now; stale verification is ignored.
                    verifiedPackages.clear()
                } else if (failure != null) {
                    bindingLocked = true
                    reconciliationComplete = false
                    verifiedPackages.clear()
                }'''
 assert s.count(a)==1;s=s.replace(a,b,1)
 s=s.replace('''            val outcome = if (synchronized(this) {''','''            val outcome = if (failure != null) {
                OfflineReadingReconciliationOutcome.Failed(snapshot, failure)
            } else if (synchronized(this) {''',1)
 return s
edit(base+'OfflineReadingStore.kt',store)
def job(s):
 a='''                is OfflineReadingReconciliationOutcome.Deferred -> {
                    OfflineReadingScheduler.finishJobReconciliation()
                    finishAwaitingReconciliation(params, generation, reschedule = true)
                }'''
 b=a+'''
                is OfflineReadingReconciliationOutcome.Failed -> {
                    OfflineReadingScheduler.finishJobReconciliation()
                    finishAwaitingReconciliation(params, generation, reschedule = false)
                }'''
 assert s.count(a)==1;return s.replace(a,b,1)
edit(base+'OfflineReadingTransferJobService.kt',job)
def web(s):
 s=s.replace('import app.nexus.android.offline.reading.OfflineReadingStore\n','import app.nexus.android.offline.reading.OfflineReadingStore\nimport app.nexus.android.offline.reading.OfflineReadingReconciliationOutcome\n',1)
 s=s.replace('''            store.reconcileAsync { snapshot ->
                if (message.documentGeneration != bridge.currentDocumentGeneration()) return@reconcileAsync
                if (!hostedReconciledSnapshotAccepted(snapshot, accountId)) {''','''            store.reconcileAsync { outcome ->
                if (message.documentGeneration != bridge.currentDocumentGeneration()) return@reconcileAsync
                if (outcome is OfflineReadingReconciliationOutcome.Failed || !hostedReconciledSnapshotAccepted(outcome.snapshot, accountId)) {''',1)
 s=s.replace('''                reply(message.replyProxy, requestId, connected(snapshot))
            }
        }
    }

    private fun connectOfflineAfterRecovery''','''                reply(message.replyProxy, requestId, connected(outcome.snapshot))
            }
        }
    }

    private fun connectOfflineAfterRecovery''',1)
 s=s.replace('''                store.reconcileAsync { snapshot ->
                    if (message.documentGeneration != bridge.currentDocumentGeneration()) return@reconcileAsync
                    finishOfflineConnect(message, requestId, snapshot)
                }''','''                store.reconcileAsync { outcome ->
                    if (message.documentGeneration != bridge.currentDocumentGeneration()) return@reconcileAsync
                    if (outcome is OfflineReadingReconciliationOutcome.Failed) {
                        failConnect(message, requestId, "Failed")
                    } else finishOfflineConnect(message, requestId, outcome.snapshot)
                }''',1)
 return s
edit('apps/android/app/src/main/java/app/nexus/android/offline/readingweb/OfflineReadingWebCapability.kt',web)
edit('apps/android/app/src/test/java/app/nexus/android/offline/reading/OfflineReadingStoreLifecycleTest.kt',lambda s:s.replace('reopened.reconcileAsync { unlockedSnapshot = it }','reopened.reconcileAsync { unlockedSnapshot = it.snapshot }',1))
p.write_text(json.dumps(d,indent=2)+'\n')
print(d['files'][base+'OfflineReadingStore.kt']['draft_sha256'])
