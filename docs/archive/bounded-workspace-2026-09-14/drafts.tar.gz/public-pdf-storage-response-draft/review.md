# public pdf response composition draft

status: source draft only; no main edits or tests executed.

`product.patch` is the complete two-owner delta against recorded main preimages.
`supplement.patch` is the same adaptation after runtime's public admission draft
and the separately reviewed storage stream draft. apply one representation, not
both. `inventory.json` binds all three prerequisites and both source files.

## ownership

only `/public/resource-share/file` enters the existing package-transfer pool.
its route returns the same `StorageResponse` as other admitted storage routes.
`PublicFileBody.chunks` states the actual closable generator type. creating the
service result performs the existing authorized head checks but opens no get
body. response entry owns the first `next()` and every subsequent source read.

full downloads use `stream_object_checked`: its finally closes the storage
generator, whose finally closes the sdk body. range downloads pass the actual
storage generator directly, matching the existing member range route; its
finally closes the sdk body. the response shields its explicit
close before entering the worker, and admission retains its permit until that
physical close finishes. no close is delegated to garbage collection. closing
an unstarted result owns no open sdk body; repeated close on an already closed
generator does not repeat its sdk finally.

## retained contract and price

authorization, publication source, exact advisory head validation, title-derived
filename, range parsing, status 200/206/416, content-length/content-range,
content-disposition, private/no-store/security headers and token handling stay at
their existing owners. ordinary non-file public endpoints remain outside this
transfer pool. source-storage errors retain their existing types and messages;
no new digest authority or masked success is introduced.

full downloads now use the reviewed one-chunk lookahead: two reads before the
first body, at most 128 kib of explicit source chunks, one get. short reads are
data; the last declared-length chunk waits for exact eof. a first-read failure
can precede headers, while later failure interrupts the body. this does not make
all corruption a pre-header response. sdk/framework allocation and throughput
remain unqualified. ranges retain their inclusive requested-range semantics,
64 kib reads, premature-eof errors, and no whole-object eof/digest claim. the
removed public counter duplicated the sole concrete client's remaining-byte
loop; sdk read(n) cannot return more than n bytes. the counter's excess-length
branch therefore added no reachable guarantee on this actual boundary.

## smallest remaining proof

retain runtime's actual public grant + published pdf + minio service owner,
including occupied-pool 503/security headers, responsive bootstrap, repeated
full/range byte equality and raw caller cancellation under production asgi 2.3.
extend its actual sdk boundary to hold a later read and then close for both full
and range responses under deadline/disconnect. saved named ownership assertions
must run before later observation timeouts. retain all drain/release cleanup.

this reuses the same peer and app, not another storage or response mock. the
common response's existing send-failure and held-close fault owns explicit
response closure. the former range wrapper is gone; there is no wrapper-close
fault or reliance on garbage collection to qualify. actual public
route/pool/header/range observations still need execution with the combined
source. no runtime proof is changed in this draft, and no existing asgi 2.3
worker-abandonment claim follows from the separate 2.4 direct-send kernel.
