# text selection and prepared dom retirement — draft reconciliation

no main or client source was mutated to make this bundle. four main preimages were checked again after copying. source patch applies only previously reviewed token/scalar selection ownership, clearable prepared getters and current-map imperative reads. it preserves main tagged read settlement, allocation factors, separate pools, resource installation, tagged artwork and native changes.

source: `main-reconciliation-v1.patch`, exact before/proposal/current-client hashes in `inventory.json`. proofs: `main-proof-reconciliation-v1.patch` and `proof-inventory.json`. the fixture patch preserves main figure, stance and pane error-boundary additions; adds only existing-range conflict semantics and actual reader retirement inside retained pane chrome. new find fixture additions are excluded.

executed evidence: 37d5484723bad8d2 passed the complete pending ask dom/ack owner and existing selection/navigation owners, then failed later apparatus fixture. 3ed208243dd68fb1 passed all three exact selection cases, then failed the separate share owner. neither is a whole-command green. prior product retainer path evidence motivated these source changes; current combined main source still requires body and native replay.

the original ask witness is retained here for exact receipt identity. proposed `text-ask-retirement-live-witness-v1.patch` (sha917d421408e0f21839457b40d6bf11276a30b877f10a9bea3b94e87e8e43db2b) separately removes its asynchronous setup scope and dom-backed action locator. this correction is not yet executed and cannot inherit prior sensitivity. it retains one gc and the original collection/acknowledgment assertions.

atomic layer replacement remains separately pending: current main can release its view before replacement preparation, and failed rollback can leave that released view current. the separately reviewed prepare-before-swap candidate must be qualified; this bundle does not claim to fix that branch. no share, pdf identity, preparation retry or figure admission implementation is included.
