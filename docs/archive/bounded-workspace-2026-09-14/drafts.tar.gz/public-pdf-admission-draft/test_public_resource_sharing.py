"""Priority proof: anonymous bearer links stay bound to one durable subject."""

from __future__ import annotations

import asyncio
import hashlib
from threading import Event
from uuid import UUID, uuid4

import httpx
import pytest
from botocore.response import StreamingBody
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import Engine
from sqlalchemy.orm import Session
from starlette.types import Receive, Scope, Send

from nexus.api.read_admission import ReadAdmission

from nexus.db.models import (
    BillingEntitlementOverride,
    Media,
    MediaFile,
    MediaKind,
    MediaSourceAttempt,
    ProcessingStatus,
)
from nexus.public_resource_security import PUBLIC_RESOURCE_SHARE_RESPONSE_HEADERS
from nexus.services.bootstrap import ensure_user_and_default_library
from nexus.services.library_entries import ensure_media_in_default_library
from nexus.services.locator_resolver import resolve_highlight_reader_target_disposition
from nexus.services.public_resource_sharing import highlight_target_available
from nexus.services.resource_grants import (
    LinkGrantAudience,
    UserGrantAudience,
    create_grant,
    delete_grant,
)
from nexus.services.resource_graph.refs import ResourceRef
from nexus.storage.client import get_storage_client
from nexus.storage.paths import build_storage_path
from tests.testkit.auth import UserRecord
from tests.testkit.reader_pdf import published_pdf_sources


def _seed_pdf(
    db: Session,
    *,
    owner_id: UUID,
    title: str,
    payload: bytes,
) -> tuple[ResourceRef, str]:
    media_id = uuid4()
    attempt_id = uuid4()
    storage_path = build_storage_path(media_id, "pdf")
    db.add_all(
        [
            Media(
                id=media_id,
                kind=MediaKind.pdf.value,
                title=title,
                processing_status=ProcessingStatus.ready_for_reading,
                created_by_user_id=owner_id,
                page_count=1,
            ),
            MediaSourceAttempt(
                id=attempt_id,
                media_id=media_id,
                created_by_user_id=owner_id,
                source_type="uploaded_pdf_file",
                attempt_no=1,
                status="succeeded",
                intent_key=f"public-share-proof:{media_id}",
            ),
            MediaFile(
                media_id=media_id,
                storage_path=storage_path,
                content_type="application/pdf",
                size_bytes=len(payload),
                source_sha256=hashlib.sha256(payload).hexdigest(),
            ),
        ]
    )
    db.flush()
    ensure_media_in_default_library(db, owner_id, media_id)
    get_storage_client().put_object(storage_path, payload, "application/pdf")
    return ResourceRef("media", media_id), storage_path


def test_anonymous_link_matrix_binds_each_token_to_one_postgres_and_minio_subject(
    db_session: Session,
    test_user: UserRecord,
    anonymous_client: TestClient,
) -> None:
    """Link, user, invalid, cross-resource, and revoked paths stay distinct."""
    recipient_id = uuid4()
    ensure_user_and_default_library(
        db_session,
        recipient_id,
        f"public-share-recipient-{recipient_id}@example.invalid",
    )
    db_session.add(
        BillingEntitlementOverride(
            user_id=test_user.id,
            plan_tier="plus",
            reason="public resource sharing priority proof",
        )
    )
    first_payload = b"%PDF-1.4 exact first public subject"
    second_payload = b"%PDF-1.4 exact second public subject"
    first, first_path = _seed_pdf(
        db_session,
        owner_id=test_user.id,
        title="First sealed subject",
        payload=first_payload,
    )
    second, second_path = _seed_pdf(
        db_session,
        owner_id=test_user.id,
        title="Second sealed subject",
        payload=second_payload,
    )
    storage = get_storage_client()

    try:
        first_link = create_grant(
            db_session,
            viewer_user_id=test_user.id,
            subject=first,
            audience=LinkGrantAudience(),
        ).grant
        second_link = create_grant(
            db_session,
            viewer_user_id=test_user.id,
            subject=second,
            audience=LinkGrantAudience(),
        ).grant
        user_grant = create_grant(
            db_session,
            viewer_user_id=test_user.id,
            subject=first,
            audience=UserGrantAudience(user_id=recipient_id),
        ).grant
        assert first_link.share_token is not None, (
            f"first link grant {first_link.grant_id} did not expose its bearer token"
        )
        assert second_link.share_token is not None, (
            f"second link grant {second_link.grant_id} did not expose its bearer token"
        )
        assert user_grant.share_token is None, (
            f"user grant {user_grant.grant_id} incorrectly became anonymously bearer-readable"
        )

        first_headers = {"X-Nexus-Share-Token": str(first_link.share_token)}
        second_headers = {"X-Nexus-Share-Token": str(second_link.share_token)}
        first_bootstrap = anonymous_client.get(
            "/public/resource-share",
            headers=first_headers,
        )
        second_bootstrap = anonymous_client.get(
            "/public/resource-share",
            headers=second_headers,
        )
        assert first_bootstrap.status_code == 200, (
            f"first bearer grant failed bootstrap: {first_bootstrap.text}"
        )
        assert second_bootstrap.status_code == 200, (
            f"second bearer grant failed bootstrap: {second_bootstrap.text}"
        )
        assert first_bootstrap.json()["data"]["media"]["title"] == "First sealed subject", (
            f"first token resolved the wrong durable subject: {first_bootstrap.json()!r}"
        )
        assert second_bootstrap.json()["data"]["media"]["title"] == "Second sealed subject", (
            f"second token resolved the wrong durable subject: {second_bootstrap.json()!r}"
        )

        first_file = anonymous_client.get(
            "/public/resource-share/file",
            headers=first_headers,
        )
        second_file = anonymous_client.get(
            "/public/resource-share/file",
            headers=second_headers,
        )
        assert first_file.status_code == 200 and first_file.content == first_payload, (
            "first token did not stream exactly its PostgreSQL-owned MinIO object: "
            f"status={first_file.status_code}, body={first_file.content!r}"
        )
        assert second_file.status_code == 200 and second_file.content == second_payload, (
            "second token escaped its grant or streamed the wrong MinIO object: "
            f"status={second_file.status_code}, body={second_file.content!r}"
        )

        invalid = anonymous_client.get(
            "/public/resource-share",
            headers={"X-Nexus-Share-Token": "not-a-share-token"},
        )
        missing = anonymous_client.get("/public/resource-share")
        assert (invalid.status_code, invalid.json()["error"]["code"]) == (
            404,
            "E_NOT_FOUND",
        ), f"invalid bearer token was not masked: {invalid.text}"
        assert (missing.status_code, missing.json()["error"]["code"]) == (
            404,
            "E_NOT_FOUND",
        ), f"missing bearer token was not masked: {missing.text}"

        delete_grant(
            db_session,
            viewer_user_id=test_user.id,
            handle=first_link.handle,
        )
        revoked = anonymous_client.get(
            "/public/resource-share",
            headers=first_headers,
        )
        assert (
            revoked.status_code,
            revoked.json()["error"]["code"],
            revoked.json()["error"]["message"],
        ) == (
            invalid.status_code,
            invalid.json()["error"]["code"],
            invalid.json()["error"]["message"],
        ), f"revoked bearer leaked a distinguishable authorization state: {revoked.text}"
    finally:
        storage.delete_object(first_path)
        storage.delete_object(second_path)


def test_unattributable_pdf_provenance_is_never_publicly_projectable(engine: Engine) -> None:
    """Only the ``resolved`` disposition reaches a public audience.

    A highlight whose geometry belongs to a superseded binary is readable and
    reattachable to its owner, but painting it for an anonymous reader would put
    old geometry over different bytes. Public projection therefore selects the
    disposition explicitly instead of inferring it from an absent target.
    """
    with published_pdf_sources(engine) as fixture:
        with fixture.factory() as db:
            superseded, current = fixture.highlights[0], fixture.highlights[1]
            assert (
                resolve_highlight_reader_target_disposition(db, highlight_id=superseded).status
                == "source_unverified"
            ), "fixture no longer produces an unattributable PDF highlight"
            assert not highlight_target_available(db, highlight_id=superseded), (
                "unattributable PDF provenance became publicly projectable"
            )
            assert highlight_target_available(db, highlight_id=current), (
                "public projection refused a highlight the published binary still owns"
            )


def test_public_file_keeps_transfer_capacity_until_its_cancelled_sdk_read_finishes(
    db_session: Session,
    test_user: UserRecord,
    nexus_app: FastAPI,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    db_session.add(
        BillingEntitlementOverride(
            user_id=test_user.id,
            plan_tier="plus",
            reason="public file transfer admission proof",
        )
    )
    payload = b"%PDF-1.4 exact public transfer subject"
    subject, storage_path = _seed_pdf(
        db_session,
        owner_id=test_user.id,
        title="Held public transfer",
        payload=payload,
    )
    storage = get_storage_client()
    try:
        grant = create_grant(
            db_session,
            viewer_user_id=test_user.id,
            subject=subject,
            audience=LinkGrantAudience(),
        ).grant
        assert grant.share_token is not None
        headers = {"X-Nexus-Share-Token": str(grant.share_token)}
        nexus_app.state.package_transfer_admission = ReadAdmission(
            max_concurrency=1, deadline_seconds=30, retry_after_seconds=1, request_bytes=262144
        )

        async def scenario() -> None:
            loop = asyncio.get_running_loop()
            entered = asyncio.Event()
            read_finished = asyncio.Event()
            release = Event()
            held_body: StreamingBody | None = None
            closed: list[StreamingBody] = []
            original_read = StreamingBody.read
            original_close = StreamingBody.close

            def held_read(body: StreamingBody, amt: int | None = None) -> bytes:
                nonlocal held_body
                if held_body is not None:
                    return original_read(body, amt)
                held_body = body
                loop.call_soon_threadsafe(entered.set)
                try:
                    assert release.wait(timeout=5), "the proof did not release the SDK read"
                    return original_read(body, amt)
                finally:
                    loop.call_soon_threadsafe(read_finished.set)

            def observed_close(body: StreamingBody) -> None:
                closed.append(body)
                original_close(body)

            async def production_protocol(scope: Scope, receive: Receive, send: Send) -> None:
                # The installed Uvicorn uses this Starlette task-group branch.
                scope = {**scope, "asgi": {"version": "3.0", "spec_version": "2.3"}}
                await nexus_app(scope, receive, send)

            with monkeypatch.context() as sdk:
                # Only the external SDK body is controlled; storage, service,
                # response, admission, grant lookup and Minio remain real.
                sdk.setattr(StreamingBody, "read", held_read)
                sdk.setattr(StreamingBody, "close", observed_close)
                async with httpx.AsyncClient(
                    transport=httpx.ASGITransport(app=production_protocol), base_url="http://test"
                ) as client:
                    opening = asyncio.create_task(
                        client.get("/public/resource-share/file", headers=headers)
                    )
                    retired = None
                    read_finished_while_held = None
                    close_count_while_held = None
                    busy = None
                    bootstrap = None
                    observation_error = None
                    cleanup_error = None
                    request_error = None
                    try:
                        await asyncio.wait_for(entered.wait(), timeout=5)
                        assert held_body is not None
                        opening.cancel()
                        busy = await client.get("/public/resource-share/file", headers=headers)
                        bootstrap = await client.get("/public/resource-share", headers=headers)
                        retired = opening.done()
                        read_finished_while_held = read_finished.is_set()
                        close_count_while_held = closed.count(held_body)
                    except Exception as error:
                        observation_error = error
                    finally:
                        release.set()
                        try:
                            await asyncio.wait_for(read_finished.wait(), timeout=5)
                        except Exception as error:
                            cleanup_error = error
                        try:
                            await asyncio.wait_for(opening, timeout=5)
                        except (Exception, asyncio.CancelledError) as error:
                            request_error = error
                    if observation_error is not None:
                        raise observation_error
                    assert retired is False, "public cancellation retired a live SDK read"
                    assert read_finished_while_held is False
                    assert close_count_while_held == 0, "SDK close raced its live read"
                    assert busy is not None and busy.status_code == 503, (
                        "public file bypassed occupied transfer capacity"
                    )
                    assert busy.json()["error"]["code"] == "E_READ_CAPACITY"
                    assert busy.headers["retry-after"] == "1"
                    for name, value in PUBLIC_RESOURCE_SHARE_RESPONSE_HEADERS.items():
                        assert busy.headers[name] == value
                    assert "set-cookie" not in busy.headers
                    assert bootstrap is not None and bootstrap.status_code == 200
                    assert bootstrap.json()["data"]["media"]["title"] == "Held public transfer"
                    assert cleanup_error is None, cleanup_error
                    assert isinstance(request_error, asyncio.CancelledError), request_error
                    assert held_body is not None and closed.count(held_body) == 1, (
                        "cancelled public file did not close its exact SDK body once"
                    )
                    complete = await client.get("/public/resource-share/file", headers=headers)
                    assert complete.status_code == 200 and complete.content == payload
                    assert complete.headers["content-length"] == str(len(payload))
                    partial = await client.get(
                        "/public/resource-share/file", headers={**headers, "Range": "bytes=5-12"}
                    )
                    assert partial.status_code == 206 and partial.content == payload[5:13]
                    assert partial.headers["content-range"] == f"bytes 5-12/{len(payload)}"
                    for response in (complete, partial):
                        for name, value in PUBLIC_RESOURCE_SHARE_RESPONSE_HEADERS.items():
                            assert response.headers[name] == value
                        assert "set-cookie" not in response.headers

        asyncio.run(scenario())
    finally:
        storage.delete_object(storage_path)
