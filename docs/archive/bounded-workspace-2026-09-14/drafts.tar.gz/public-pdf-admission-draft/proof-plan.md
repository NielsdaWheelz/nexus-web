status: proposed; no execution or source activation
origin: 2026-09-14 public PDF physical ownership review
area: existing transfer admission on one public file route

source option: product.patch changes only route membership. the public router
keeps its prefix and ordinary routes; a nested file_transfers router selects
AdmittedPackageTransferRoute for /file alone. reuse the existing transfer pool,
deadline and body-size profile. no new state or limits.

APIResponsePolicyMiddleware already recognizes every /public/resource-share
response and applies the public security headers at response.start, including
an admission refusal before dependencies. Retry-After survives this policy.
when the pool is occupied, file requests uniformly receive capacity before
bearer validation; with capacity available, existing masking/range checks stay.

extend the existing service owner test_public_resource_sharing.py, reusing its
_seed_pdf helper and actual create_grant. control only the real storage SDK
body's read/close, with exact PostgreSQL subject and object key unchanged.

1. hold the first physical SDK read of the actual /public/resource-share/file;
   cancel its real caller task; observe the request remains unsettled and a
   second /file receives 503 E_READ_CAPACITY with Retry-After and every constant
   PUBLIC_RESOURCE_SHARE_RESPONSE_HEADERS value, with no Set-Cookie.
2. while held, the same valid grant's lightweight bootstrap still returns its
   exact title. release the SDK read; caller cancellation then settles and the
   SDK body closes once. a later full/range file request returns exact bytes.
3. use the same actual route under the one-second fixture transfer deadline;
   hold next and separately close to prove its permit stays occupied through
   physical completion. this case depends on publication's explicit response
   close owner as well as admission; do not substitute a fake response or claim
   route membership alone establishes close on deadline/disconnect.

retain the existing anonymous token matrix, range and security-header owners.
observe the old unadmitted-route red with this same physical boundary, then
candidate green. no new canonical owner/pin is proposed before exact review.
actual full-object/range throughput and overlap must qualify sharing the
existing package-transfer budget; these behavioral cases do not measure it.
