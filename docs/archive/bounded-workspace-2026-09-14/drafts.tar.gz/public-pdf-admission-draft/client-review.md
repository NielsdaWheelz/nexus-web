# public pdf admission independent review

status: source/proof design accepted; no execution receipt supplied by this review
origin: 2026-09-14, client agent; main unchanged

reviewed product.patch sha256:
`d5f105ee63538f1c90d09a7d7e32f57dcc95036b59295cd59ebf7d91d078c976`

reviewed proof.patch sha256:
`34fc2554fc3605b4c13df89ac279119fb7b27204ae54b8fcfd4205b5e3209926`

only the public file route joins the existing package-transfer admission owner.
installed FastAPI preserves each nested route's class through
`route_class_override=type(route)` in routing.py:1787. no second semaphore,
stream wrapper, cache, or cancellation owner is introduced.

get_public_pdf_file still resolves the token before parsing Range and selects
the same private source. full/range storage streams and _verified_stream retain
exact byte accounting and EOF checks. the route's 416 response, content length,
content disposition and range headers remain unchanged. outer
APIResponsePolicyMiddleware applies the public security policy to early capacity
errors as well as completed responses; the trusted-BFF auth boundary is unchanged.

both installed Uvicorn HTTP protocols publish spec_version 2.3
(h11_impl.py:205, httptools_impl.py:227). Starlette responses.py:273 therefore
uses its actual task-group branch, as the proof requests. only the external
botocore StreamingBody read/close boundary is controlled. the Minio object,
grant, database, service, ASGI response and admission remain real.

raw caller-task cancellation occurs after the first SDK read is visibly held.
while that read remains live, a second file request must get 503 with exact
capacity/retry/security headers, bootstrap must remain responsive, and neither
request retirement nor body close may race the read. after release, the original
request must finish cancelled and close that exact body once. the complete and
partial requests verify capacity recovery, exact EOF/body length and byte range.
no private admission count is used.

this proves caller-task cancellation and service composition, not a TCP peer
shutdown or maximum-sized PDF workload. existing anonymous grant/privacy tests
remain required alongside this added owner. actual red/green execution remains
for the paved runner after the source batch is committed.
