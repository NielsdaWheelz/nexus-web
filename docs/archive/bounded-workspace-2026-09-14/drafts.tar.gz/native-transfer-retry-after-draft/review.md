# native retry-after durable eligibility draft

status: reviewed design, source/proof draft only; no execution or main mutation.
origin: oi-204, 2026-09-14; based on the nine exact main preimages in inventory.json.

## defect and cut

`OfflineReadingOriginClient.requireSuccess` discards the owned response header.
`OfflineReadingTransfer`/schema 3 have no durable floor. the store selects every
nonfailed row. the old checkpoint counts every such row, so merely skipping an
ineligible row would spin. excluding it from durable demand would instead lose
os retry ownership.

six existing product owners change:

- origin client: single retry-after header to absolute instant, using the existing
  clock for unsigned delay seconds and okhttp's public date parser for http-date.
  missing header means no new floor. duplicate, malformed or unrepresentable
  values follow the existing malformed-response integrity failure; no upper cap
  silently shortens a valid representable delay.
- model/database/store: nullable retry_not_before on the existing transfer row;
  schema 3 gains null without rewriting any old value. schema 1 runs the unchanged
  prior migration before the same addition. new refusal updates use the existing
  current-binding/id/staging fence. max(existing,new) survives shortened/missing
  later headers; existing copy and policy updates preserve the scalar.
- scheduler/service: next-runnable filters future floors. has-queued retains its
  durable-demand meaning. the existing queue-lock checkpoint decides whether to
  continue and passes the durable-demand retry boolean to jobfinished. the
  existing user-initiated, persisted, network-constrained job and exponential
  backoff stay unchanged. no minimum latency, sleep, replacement scheduler or
  new retry cadence.
- store cleanup: preserve only the archive/verified names referenced by current
  nonfailed transfer rows alongside existing legacy migration names. orphan
  names still go. active interrupted attempts retain their existing reset/delete
  path. deferred files remain untrusted and are not published by this change.

prices: an os wake before the floor reads durable state and completes with retry;
its existing backoff may schedule the real attempt after the floor. staged files
occupy disk while deferred. the next real attempt still uses the existing full
transfer/verification path; this does not add partial-download resume. absolute
eligibility uses the existing store clock, including its wall-clock semantics;
this does not qualify clock changes or actual device background timing.

## proof boundary

three existing owners retain all previous cases:

- origin-client: actual fixed-origin socket transport and loopback http responses;
  null, zero, 60 seconds, 100 days, future/past http-date; malformed, duplicate and
  representational overflow remain integrity failures. each refusal causes exactly
  one request. expected dates are literal source-independent values.
- scheduler/store: actual jobinfo, sqlite, account binding and directory owner;
  future-floor claim refusal, other eligible work, early-wake finish with retry,
  policy replacement with user-initiated/persisted/no-delay/backoff constraints,
  real database reopen, exact staged archive/member bytes and orphan removal,
  one nanosecond before/exactly at floor, selected generation and identities,
  shorter/missing later floor, stale id/staging/account callbacks, absent-header
  immediate eligibility.
- database: prior schema-1 retained-row equality remains; reconstructing that
  historical schema drops the new column too. distinct schema-3 reconstruction
  proves exact transfer-row equality plus a null new floor.

these are host native proofs. the scheduler case observes the actual existing
checkpoint's retry decision; it does not claim android delivered a future job.
the origin and store boundaries are exercised separately; the jobservice's
existing callback/run fence forwards the parsed instant into the store. an
actual full jobservice/physical-os journey has not run.

## sensitivity and registration prerequisites

three temporary product-only patches are supplied, never applied or committed:

- origin-floor-fault.patch: discard the parsed floor; expected assertion
  `capacity refusal lost or shortened the server floor`.
- eligibility-fault.patch: remove only the durable floor predicate; expected
  assertion `server floor admitted an early transfer`.
- idle-retry-fault.patch: finish the existing idle owner with false; expected
  assertion `durable deferred work lost its OS retry`.

these are proposed fingerprints until actual receipts. ordinary old-source proof
overlay is not valid for the new interfaces; do not call a missing property,
column or method a behavioral red. use the explicit candidate faults after
normal candidate execution and reviewed source/proof integration.

origin-client and database are already coherent-pinned canonical whole-file
owners; their changed exact hashes require independent review before pin edits.
scheduler/store has its existing preparation-starvation fault. preserve all
three existing registered mutations; the new floor/idle cases need their own
auxiliary sensitivity. no registry edits are in this draft.

root executes the paved android host selection for the three changed owner paths,
then the temporary candidate fault comparisons. no new limit or throughput,
physical-device, timing-delivery or whole-task completion claim follows from this
unexecuted draft.
