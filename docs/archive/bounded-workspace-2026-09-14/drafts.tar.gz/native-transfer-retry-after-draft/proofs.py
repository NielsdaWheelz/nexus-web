from pathlib import Path
import difflib
import hashlib
import json
root=Path('/home/niels/src/personal/nexus-web-bounded-workspace')
out=Path('/tmp/native-transfer-retry-after-draft')
prefix='apps/android/app/src/test/java/app/nexus/android/offline/reading/'
changes={}
def edit(name, fn):
    path=prefix+name
    old=(root/path).read_text()
    new=fn(old)
    assert new!=old
    changes[path]=(old,new)
def replace(s,a,b):
    assert s.count(a)==1,(a,s.count(a))
    return s.replace(a,b)

def origin(s):
    anchor='    @Test\n    fun `worker preparation observes status before minting the same selected generation`() {'
    addition='''    @Test
    fun `capacity refusal carries the complete server retry floor through the real origin`() {
        val receivedAt = Instant.parse("2026-08-13T18:00:00.123456789Z")
        val client = realClient(Clock.fixed(receivedAt, ZoneOffset.UTC))
        val cases = listOf(
            null to null,
            "0" to receivedAt,
            "60" to Instant.parse("2026-08-13T18:01:00.123456789Z"),
            // A server delay above ordinary OS backoff remains intact, without a local cap.
            "8640000" to Instant.parse("2026-11-21T18:00:00.123456789Z"),
            "Thu, 13 Aug 2026 18:01:00 GMT" to Instant.parse("2026-08-13T18:01:00Z"),
            "Thu, 13 Aug 2026 17:59:00 GMT" to Instant.parse("2026-08-13T17:59:00Z"),
        )
        cases.forEachIndexed { index, (header, expected) ->
            val response = MockResponse().setResponseCode(503)
                .setBody("""{"error":{"code":"E_READ_CAPACITY","message":"Read capacity is busy"}}""")
            if (header != null) response.setHeader("Retry-After", header)
            server.enqueue(response)
            val refusal = assertThrows(OfflineReadingCapacityRefusedException::class.java) {
                OfflineReadingTransferOperations.register(transfer.id).use { operation ->
                    client.selectLegacyGeneration(transfer.copy(readerGeneration = null), accountId, network(), operation)
                }
            }
            assertEquals("capacity refusal lost or shortened the server floor", expected, refusal.retryNotBefore)
            assertEquals("capacity refusal issued another HTTP request", index + 1, server.requestCount)
            assertEquals("/api/media/$mediaId/reader-publication", server.takeRequest().path)
        }
    }

    @Test
    fun `malformed capacity retry headers remain integrity failures`() {
        val client = realClient(Clock.fixed(Instant.parse("2026-08-13T18:00:00Z"), ZoneOffset.UTC))
        val headers = listOf(
            listOf("-1"), listOf("1.5"), listOf(""), listOf("not a date"),
            listOf("999999999999999999999999999"), listOf(Long.MAX_VALUE.toString()),
            listOf("60", "120"),
        )
        headers.forEachIndexed { index, values ->
            val response = MockResponse().setResponseCode(503)
                .setBody("""{"error":{"code":"E_READ_CAPACITY","message":"Read capacity is busy"}}""")
            values.forEach { response.addHeader("Retry-After", it) }
            server.enqueue(response)
            val failure = assertThrows(OfflineReadingOriginException::class.java) {
                OfflineReadingTransferOperations.register(transfer.id).use { operation ->
                    client.selectLegacyGeneration(transfer.copy(readerGeneration = null), accountId, network(), operation)
                }
            }
            assertEquals("malformed Retry-After was treated as permission to retry", ReadingFailureReason.Integrity, failure.reason)
            assertTrue(failure.cause is IllegalArgumentException)
            assertEquals(index + 1, server.requestCount)
            server.takeRequest()
        }
    }

'''
    return replace(s,anchor,addition+anchor)
edit('OfflineReadingOriginClientTest.kt',origin)

def scheduler(s):
    s=replace(s,'import org.junit.Assert.assertEquals\n','import org.junit.Assert.assertArrayEquals\nimport org.junit.Assert.assertEquals\n')
    anchor='    private fun store(\n'
    addition='''    @Test
    fun `server retry floor survives durable reopen and policy replacement without spinning`() {
        OfflineReadingScheduler.runnerStopped()
        val startedAt = Instant.parse("2026-08-13T18:00:00Z")
        var now = startedAt
        val clock = object : Clock() {
            override fun getZone() = ZoneOffset.UTC
            override fun withZone(zone: java.time.ZoneId): Clock = Clock.fixed(now, zone)
            override fun instant(): Instant = now
        }
        val jobs = context.getSystemService(android.app.job.JobScheduler::class.java)
        val firstDatabase = OfflineReadingDatabase(context, databaseName)
        val first = store(firstDatabase, clock = clock, schedulerFactory = { OfflineReadingScheduler(context, it) })
        first.bindAccountAfterExternalPurge(accountId)
        first.enqueue(mediaId, "Deferred source", OfflineReadingMediaKind.Epub, 7)
        val transfer = first.nextRunnableTransfer()!!
        val staged = first.stagingArchiveFor(transfer)
        val bytes = byteArrayOf(1, 3, 5, 7, 9)
        staged.writeBytes(bytes)
        val verified = File(staged.parentFile, "${transfer.stagingName}.verified").apply { check(mkdirs()) }
        val verifiedMember = File(verified, "source-member").apply { writeBytes(bytes.reversedArray()) }
        val orphan = File(staged.parentFile, "unowned.zip").apply { writeBytes(byteArrayOf(42)) }
        val floor = Instant.parse("2026-08-13T18:01:00Z")
        try {
            assertTrue(first.deferForServerCapacity(transfer.id, transfer.stagingName, floor))
            assertTrue(first.hasQueuedWork())
            assertEquals("server floor admitted an early transfer", OfflineReadingRunnableClaim.Idle,
                first.claimRunnableTransfer(NetworkPolicy.UnmeteredOnly))
            assertArrayEquals(bytes, staged.readBytes())

            // A later eligible transfer is not blocked by the earlier server refusal.
            now = startedAt.plusSeconds(1)
            val other = UUID.fromString("028f2e74-5efc-7d0d-8a3a-142857142857")
            first.enqueue(other, "Eligible source", OfflineReadingMediaKind.Pdf, 8)
            assertEquals(other, (first.claimRunnableTransfer(NetworkPolicy.UnmeteredOnly)
                as OfflineReadingRunnableClaim.Run).transfer.mediaId)
            first.cancel(other)

            OfflineReadingScheduler.runnerStarted()
            var reschedule: Boolean? = null
            assertFalse("future floor made the runner spin",
                OfflineReadingScheduler.runnerCheckpoint(first) { reschedule = it })
            assertEquals("durable deferred work lost its OS retry", true, reschedule)
            assertFalse(OfflineReadingScheduler.runnerIsActive())
            first.setNetworkPolicy(NetworkPolicy.AnyConnected)
            val job = requireNotNull(jobs.getPendingJob(OFFLINE_READING_JOB_ID))
            assertTrue(job.isUserInitiated)
            assertTrue(job.isPersisted)
            assertEquals("user-initiated job gained an invalid time delay", 0L, job.minLatencyMillis)
            assertEquals(android.app.job.JobInfo.DEFAULT_INITIAL_BACKOFF_MILLIS, job.initialBackoffMillis)
            assertEquals(android.app.job.JobInfo.BACKOFF_POLICY_EXPONENTIAL, job.backoffPolicy)
            assertEquals(android.app.job.JobInfo.NETWORK_TYPE_ANY, job.networkType)
        } finally {
            OfflineReadingScheduler.runnerStopped()
            firstDatabase.close()
        }

        val reopenedDatabase = OfflineReadingDatabase(context, databaseName)
        try {
            val reopened = store(reopenedDatabase, clock = clock, schedulerFactory = { OfflineReadingScheduler(context, it) })
            assertTrue(reopened.hasQueuedWork())
            assertEquals("process recreation forgot the server floor", OfflineReadingRunnableClaim.Idle,
                reopened.claimRunnableTransfer(NetworkPolicy.AnyConnected))
            assertTrue("recovery deleted the deferred archive", staged.isFile)
            assertArrayEquals(bytes, staged.readBytes())
            assertTrue("recovery deleted verified staged bytes", verifiedMember.isFile)
            assertArrayEquals(bytes.reversedArray(), verifiedMember.readBytes())
            assertFalse("recovery retained an unowned staging file", orphan.exists())

            // The same durable attempt cannot have its floor shortened by an older refusal.
            assertTrue(reopened.deferForServerCapacity(transfer.id, transfer.stagingName, startedAt.plusSeconds(30)))
            assertTrue(reopened.deferForServerCapacity(transfer.id, transfer.stagingName, null))
            now = floor.minusNanos(1)
            assertEquals("server floor admitted an early transfer", OfflineReadingRunnableClaim.Idle,
                reopened.claimRunnableTransfer(NetworkPolicy.AnyConnected))
            now = floor
            val resumed = (reopened.claimRunnableTransfer(NetworkPolicy.AnyConnected)
                as OfflineReadingRunnableClaim.Run).transfer
            assertEquals("eligible transfer lost its selected generation", 7L, resumed.readerGeneration)
            assertEquals(transfer.id, resumed.id)
            assertEquals(transfer.bindingId, resumed.bindingId)
            assertEquals(transfer.stagingName, resumed.stagingName)
            assertEquals(floor, resumed.retryNotBefore)
            assertArrayEquals(bytes, staged.readBytes())
            reopened.cancel(mediaId)
            assertFalse(staged.exists())
            assertFalse(verified.exists())
            reopened.enqueue(mediaId, "Replacement source", OfflineReadingMediaKind.Epub, 8)
            assertFalse("retired refusal changed replacement work",
                reopened.deferForServerCapacity(transfer.id, transfer.stagingName, floor.plusSeconds(60)))
            val replacement = reopened.nextRunnableTransfer()!!
            assertEquals(8L, replacement.readerGeneration)
            assertFalse("old staging identity changed replacement work",
                reopened.deferForServerCapacity(replacement.id, transfer.stagingName, floor.plusSeconds(60)))
            reopened.logoutAndPurge()
            reopened.bindAccountAfterExternalPurge(UUID.fromString("33333333-3333-4333-8333-333333333333"))
            reopened.enqueue(mediaId, "Other account source", OfflineReadingMediaKind.Epub, 9)
            assertFalse("purged account refusal changed the current account",
                reopened.deferForServerCapacity(replacement.id, replacement.stagingName, floor.plusSeconds(60)))
            assertEquals(9L, reopened.nextRunnableTransfer()!!.readerGeneration)
        } finally {
            OfflineReadingScheduler.runnerStopped()
            reopenedDatabase.close()
        }
    }

    @Test
    fun `capacity refusal without a header keeps durable work immediately eligible`() {
        OfflineReadingScheduler.runnerStopped()
        OfflineReadingDatabase(context, databaseName).use { database ->
            val store = store(database, schedulerFactory = { OfflineReadingScheduler(context, it) })
            store.bindAccountAfterExternalPurge(accountId)
            store.enqueue(mediaId, "No server floor", OfflineReadingMediaKind.WebArticle, 7)
            val transfer = store.nextRunnableTransfer()!!
            assertTrue(store.deferForServerCapacity(transfer.id, transfer.stagingName, null))
            val pending = (store.claimRunnableTransfer(NetworkPolicy.UnmeteredOnly)
                as OfflineReadingRunnableClaim.Run).transfer
            assertEquals(transfer.id, pending.id)
            assertEquals(null, pending.retryNotBefore)
            assertEquals(ReadingTransferState.Queued(ReadingQueueReason.ServerCapacity), pending.state)
        }
        OfflineReadingScheduler.runnerStopped()
    }

'''
    return replace(s,anchor,addition+anchor)
edit('OfflineReadingSchedulerStoreBoundaryTest.kt',scheduler)

def database(s):
    s=replace(s, '                db.execSQL("ALTER TABLE offline_reader_transfers DROP COLUMN preparation_started_at")',
        '                db.execSQL("ALTER TABLE offline_reader_transfers DROP COLUMN preparation_started_at")\n                db.execSQL("ALTER TABLE offline_reader_transfers DROP COLUMN retry_not_before")')
    s=replace(s, '                // Only version 1 upgrades to the current schema.', '                // Reconstruct the shipped version 1 before invoking the real upgrade.')
    s=replace(s, 'assertEquals(3, db.version)', 'assertEquals(4, db.version)')
    anchor='    private val tables = '
    addition='''    @Test
    fun `version three transfer rows gain no invented retry floor`() {
        val context = RuntimeEnvironment.getApplication()
        val name = "reading-retry-upgrade-${UUID.randomUUID()}.db"
        try {
            val binding = UUID.randomUUID().toString()
            val now = "2026-09-13T00:00:00Z"
            val before: Map<String, String?>
            OfflineReadingDatabase(context, name).use { owner ->
                val db = owner.writableDatabase
                db.execSQL("ALTER TABLE offline_reader_transfers DROP COLUMN retry_not_before")
                db.execSQL("INSERT INTO offline_reader_binding VALUES(?, 1, ?, ?, ?, 1, ?)",
                    arrayOf(UUID.randomUUID().toString(), binding, UUID.randomUUID().toString(), byteArrayOf(1), now))
                db.execSQL("""
                    INSERT INTO offline_reader_transfers(
                        id, binding_id, media_id, requested_title, requested_media_kind, state_json,
                        automatic_restart_count, staging_name, requested_at, reader_generation, preparation_started_at
                    ) VALUES(?, ?, ?, 'Deferred', 'Epub', ?, 0, 'retained-attempt', ?, 7, ?)
                    """.trimIndent(), arrayOf(UUID.randomUUID().toString(), binding, UUID.randomUUID().toString(),
                        """{"kind":"Queued","reason":"ServerCapacity"}""", now, now))
                before = row(db, "offline_reader_transfers")
                db.version = 3
            }
            OfflineReadingDatabase(context, name).use { owner ->
                val db = owner.writableDatabase
                val after = row(db, "offline_reader_transfers")
                assertEquals(4, db.version)
                assertEquals("retry-floor migration changed a durable transfer", before,
                    after.filterKeys { it != "retry_not_before" })
                assertNull("schema three transfer acquired an invented delay", after.getValue("retry_not_before"))
                db.rawQuery("PRAGMA foreign_key_check", null).use { assertFalse(it.moveToFirst()) }
            }
        } finally {
            context.deleteDatabase(name)
        }
    }

'''
    return replace(s,anchor,addition+anchor)
edit('OfflineReadingDatabaseTest.kt',database)
for path,(old,new) in changes.items():
    dest=out/path
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(new)
(out/'proof.patch').write_text(''.join(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p,(a,b) in changes.items()))
inv=json.loads((out/'inventory.json').read_text())
inv.extend({'path':p,'preimage_sha256':hashlib.sha256(a.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(b.encode()).hexdigest()} for p,(a,b) in changes.items())
(out/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
