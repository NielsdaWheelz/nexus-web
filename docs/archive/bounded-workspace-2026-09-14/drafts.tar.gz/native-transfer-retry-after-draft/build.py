from pathlib import Path
import difflib
import hashlib
import json

root = Path('/home/niels/src/personal/nexus-web-bounded-workspace')
out = Path('/tmp/native-transfer-retry-after-draft')
main = 'apps/android/app/src/main/java/app/nexus/android/offline/reading/'
test = 'apps/android/app/src/test/java/app/nexus/android/offline/reading/'
changes = {}
def edit(path, fn):
    old = (root / path).read_text()
    new = fn(old)
    assert new != old, path
    changes[path] = (old, new)
def replace(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)

edit(main + 'OfflineReadingModels.kt', lambda s: replace(s,
    '    val preparationStartedAt: Instant?,\n)',
    '    val preparationStartedAt: Instant?,\n    // An owned-origin refusal survives policy changes and process recreation.\n    val retryNotBefore: Instant? = null,\n)'))

def origin(s):
    s = replace(s, 'import java.time.Clock\n', 'import java.time.Clock\nimport java.time.Duration\n')
    s = replace(s, 'internal class OfflineReadingCapacityRefusedException : Exception("E_READ_CAPACITY")',
        'internal class OfflineReadingCapacityRefusedException(\n    val retryNotBefore: Instant?,\n) : Exception("E_READ_CAPACITY")')
    s = replace(s, 'ReadingRefusal.Capacity -> OfflineReadingCapacityRefusedException()',
        'ReadingRefusal.Capacity -> OfflineReadingCapacityRefusedException(retryNotBefore(response))')
    s = replace(s, '    private fun parseContentDigest(header: String): ByteArray {', '''    private fun retryNotBefore(response: Response): Instant? {
        val values = response.headers.values("Retry-After")
        if (values.isEmpty()) return null
        require(values.size == 1) { "offline reading Retry-After is repeated" }
        val value = values.single()
        if (value.isNotEmpty() && value.all { it in '0'..'9' }) {
            val seconds = requireNotNull(value.toLongOrNull()) {
                "offline reading Retry-After is not representable"
            }
            val receivedAt = clock.instant()
            require(seconds <= Duration.between(receivedAt, Instant.MAX).seconds) {
                "offline reading Retry-After is not representable"
            }
            return receivedAt.plusSeconds(seconds)
        }
        return requireNotNull(response.headers.getInstant("Retry-After")) {
            "offline reading Retry-After is malformed"
        }
    }

    private fun parseContentDigest(header: String): ByteArray {''')
    return s
edit(main + 'OfflineReadingOriginClient.kt', origin)

def database(s):
    s = replace(s, '                preparation_started_at TEXT,', '                preparation_started_at TEXT,\n                retry_not_before TEXT,')
    start = s.index('        check(oldVersion == 1 && newVersion == 3)')
    end = s.index('\n    private fun migrateCursorSources', start)
    old = s[start:end]
    body = old[old.index('        migrateCursorSources(database)'):old.index('\n\n    }')]
    new = '''        check(oldVersion in setOf(1, 3) && newVersion == 4) {
            "unsupported offline reading database upgrade $oldVersion to $newVersion"
        }
        if (oldVersion == 1) {
''' + '\n'.join('    ' + line if line else line for line in body.splitlines()) + '''
        }
        database.execSQL("ALTER TABLE offline_reader_transfers ADD COLUMN retry_not_before TEXT")
    }
'''
    s = s[:start] + new + s[end:]
    return replace(s, 'private const val DATABASE_VERSION = 3', 'private const val DATABASE_VERSION = 4')
edit(main + 'OfflineReadingDatabase.kt', database)

def store(s):
    s = replace(s, '''        return readTransfers(binding.bindingId).firstOrNull {
            (it.id to it.stagingName) !in deferred && it.state !is ReadingTransferState.Failed
        }''', '''        val now = clock.instant()
        return readTransfers(binding.bindingId).firstOrNull {
            (it.id to it.stagingName) !in deferred && it.state !is ReadingTransferState.Failed &&
                (it.retryNotBefore == null || !now.isBefore(it.retryNotBefore))
        }''')
    s = replace(s, '    @Synchronized\n    internal fun updateTransferState(', '''    @Synchronized
    internal fun deferForServerCapacity(
        transferId: UUID,
        expectedStagingName: String,
        retryNotBefore: Instant?,
    ): Boolean {
        val current = readTransferById(transferId) ?: return false
        if (current.stagingName != expectedStagingName) return false
        val floor = when {
            current.retryNotBefore == null -> retryNotBefore
            retryNotBefore == null -> current.retryNotBefore
            else -> maxOf(current.retryNotBefore, retryNotBefore)
        }
        replaceTransfer(current.copy(
            state = ReadingTransferState.Queued(ReadingQueueReason.ServerCapacity),
            retryNotBefore = floor,
        ))
        notifySnapshotChanged()
        return true
    }

    @Synchronized
    internal fun updateTransferState(''')
    s = replace(s, '                   automatic_restart_count, staging_name, requested_at, reader_generation, preparation_started_at\n',
        '                   automatic_restart_count, staging_name, requested_at, reader_generation, preparation_started_at, retry_not_before\n')
    s = replace(s, '                    if (cursor.isNull(cursor.getColumnIndexOrThrow("preparation_started_at"))) null else cursor.instant("preparation_started_at"),',
        '                    if (cursor.isNull(cursor.getColumnIndexOrThrow("preparation_started_at"))) null else cursor.instant("preparation_started_at"),\n                    if (cursor.isNull(cursor.getColumnIndexOrThrow("retry_not_before"))) null else cursor.instant("retry_not_before"),')
    s = replace(s, '''                automatic_restart_count, staging_name, requested_at, reader_generation, preparation_started_at
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', '''                automatic_restart_count, staging_name, requested_at, reader_generation, preparation_started_at, retry_not_before
            ) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''')
    s = replace(s, '                transfer.preparationStartedAt?.toString(),', '                transfer.preparationStartedAt?.toString(),\n                transfer.retryNotBefore?.toString(),')
    s = replace(s, '            put("preparation_started_at", transfer.preparationStartedAt?.toString())',
        '            put("preparation_started_at", transfer.preparationStartedAt?.toString())\n            put("retry_not_before", transfer.retryNotBefore?.toString())')
    s = replace(s, '''        val retained = readPackages(bindingId).filter { it.packageSchemaVersion == 1 }
            .map { migrationDirectory(bindingId, it.id).name }.toSet()''', '''        val retained = readPackages(bindingId).filter { it.packageSchemaVersion == 1 }
            .map { migrationDirectory(bindingId, it.id).name }.toMutableSet()
        readTransfers(bindingId).filter { it.state !is ReadingTransferState.Failed }.forEach {
            retained += stagingArchive(bindingId, it.stagingName).name
            retained += stagingVerified(bindingId, it.stagingName).name
        }''')
    return s
edit(main + 'OfflineReadingStore.kt', store)

def service(s):
    s = replace(s, 'OfflineReadingScheduler.runnerCheckpoint(store, deferredPreparations) {\n                                jobFinished(params, deferredPreparations.isNotEmpty() && store.hasQueuedWork())',
        'OfflineReadingScheduler.runnerCheckpoint(store, deferredPreparations) { reschedule ->\n                                jobFinished(params, reschedule)')
    s = replace(s, '''        } catch (_: OfflineReadingCapacityRefusedException) {
            // The origin admitted no work, so the transfer is still runnable and its
            // staged bytes stay. JobScheduler's exponential backoff owns the next
            // attempt, the same delayed retry a locked binding key gets.
            mutateIfCurrent(fence) {
                store.updateTransferState(
                    transfer.id,
                    transfer.stagingName,
                    ReadingTransferState.Queued(ReadingQueueReason.ServerCapacity),
                )
            }
            return TransferStep.DeferUntilUnlocked''', '''        } catch (refusal: OfflineReadingCapacityRefusedException) {
            // Persist the server floor before releasing this attempt. The existing OS
            // backoff may wake earlier; the durable claim gate will defer it again.
            mutateIfCurrent(fence) {
                store.deferForServerCapacity(
                    transfer.id,
                    transfer.stagingName,
                    refusal.retryNotBefore,
                )
            }
            return TransferStep.DeferUntilUnlocked''')
    return s
edit(main + 'OfflineReadingTransferJobService.kt', service)
def scheduler(s):
    s = replace(s, '            finishJob: () -> Unit,', '            finishJob: (reschedule: Boolean) -> Unit,')
    s = replace(s, '                if (store.hasQueuedWork(deferred)) return true',
        '                if (store.nextRunnableTransfer(deferred) != null) return true')
    return replace(s, '                finishJob()', '''                // A future server floor leaves durable demand but no eligible request.
                // Keep the existing OS backoff owner; no delayed user-initiated job is built.
                finishJob(store.hasQueuedWork())''')
edit(main + 'OfflineReadingScheduler.kt', scheduler)

for path, (old, new) in changes.items():
    dest = out / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(new)
(out / 'product.patch').write_text(''.join(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='a/'+path, tofile='b/'+path)) for path, (old,new) in changes.items()))
(out / 'inventory.json').write_text(json.dumps([{ 'path': p, 'preimage_sha256': hashlib.sha256(a.encode()).hexdigest(), 'candidate_sha256': hashlib.sha256(b.encode()).hexdigest()} for p,(a,b) in changes.items()], indent=2)+'\n')
