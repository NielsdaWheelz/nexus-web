from pathlib import Path
import subprocess, json, hashlib
root=Path('/home/niels/src/personal/nexus-web-bounded-workspace')
review=Path('/tmp/publication-merge-review'); review.mkdir(exist_ok=True)
refs={'ours':'8c0ab400','base':'7fa89b88c8','rollback':'01b5b6d5db','pre':'01b5b6d5db^','upstream':'daa92259b4'}
def git(*args): return subprocess.check_output(['git',*args],cwd=root)
def tree(ref):
    result={}
    for line in git('ls-tree','-r','-z',ref).split(b'\0'):
        if line:
            head,path=line.split(b'\t'); mode,kind,oid=head.split()
            result[path.decode()]=(mode.decode(),oid.decode())
    return result
maps={name:tree(ref) for name,ref in refs.items()}
excluded={'python/nexus/config.py','python/tests/kernel/test_application_settings.py','python/tests/testkit/unreachable_state.py','python/tests/testkit/host_release.py','python/tests/testkit/production_deploy.py','python/tests/testkit/release_bundle.py','python/tests/testkit/host_oracle_reconcile.py'}
def owned(path):
    if path in excluded: return False
    if path.startswith('python/nexus/'): return True
    if path.startswith(('node/','python/scripts/')): return True
    if path.startswith('python/tests/'):
        if '/nexus_test_control/' in path or '/release' in path or '/capacity/' in path: return False
        if path.startswith('python/tests/kernel/') and any(x in path for x in ('production_', 'backend_artifact', 'ci_', 'worker_runtime_health')): return False
        return True
    return False
paths=sorted(path for path in set().union(*(set(value) for value in maps.values())) if owned(path))
cache={}
def data(kind,path):
    row=maps[kind].get(path)
    if row is None: return None
    oid=row[1]
    if oid not in cache: cache[oid]=git('cat-file','blob',oid)
    return cache[oid]
def combine(path,label,a,b,c):
    if a==b: return c,False
    if c==b or a==c: return a,False
    folder=review/path; folder.parent.mkdir(parents=True,exist_ok=True)
    names=[]
    for suffix,value in [('current',a),('base',b),('incoming',c)]:
        filename=folder.with_name(folder.name+'.'+label+'.'+suffix)
        filename.write_bytes(value or b''); names.append(filename)
    if any(value is not None and b'\0' in value for value in (a,b,c)):
        return a,True
    proc=subprocess.run(['git','merge-file','-p','--diff3','-L',label+' current','-L',label+' base','-L',label+' incoming',*map(str,names)],capture_output=True,cwd=root)
    if proc.returncode not in (0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20):
        raise RuntimeError((path,proc.returncode,proc.stderr))
    merged=proc.stdout
    folder.with_name(folder.name+'.'+label+'.merged').write_bytes(merged)
    return merged,proc.returncode!=0
rows=[]
for path in paths:
    virtual,c1=combine(path,'rollback-removal',data('upstream',path),data('rollback',path),data('pre',path))
    if c1:
        rows.append({'path':path,'status':'virtual-conflict'}); continue
    merged,c2=combine(path,'delivery-merge',data('ours',path),data('base',path),virtual)
    target=root/path
    before=target.read_bytes() if target.exists() else None
    if merged is None:
        if target.exists(): target.unlink()
    else:
        target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(merged)
        mode=next(maps[kind][path][0] for kind in ('ours','upstream','pre','base') if path in maps[kind]);target.chmod(0o755 if mode=='100755' else 0o644)
    if before!=merged or c2:
        rows.append({'path':path,'status':'conflict' if c2 else 'clean','sha256':hashlib.sha256(merged).hexdigest() if merged is not None else None})
(review/'inventory.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'owned_paths':len(paths),'changed':len(rows),'conflicts':[r for r in rows if r['status']!='clean']},indent=2))
