package dev.tonholo.kss.lexer.css.token.consumer

import dev.tonholo.kss.lexer.Token
import dev.tonholo.kss.lexer.TokenIterator
import dev.tonholo.kss.lexer.css.CssTokenKind

class CommentTokenConsumer(
    iterator: TokenIterator<CssTokenKind>,
) : TokenConsumer(iterator) {
    override val supportedTokenKinds: Set<CssTokenKind> =
        setOf(
            CssTokenKind.CDO,
            CssTokenKind.CDC,
            CssTokenKind.Comment
        )

    override fun consume(kind: CssTokenKind): List<Token<out CssTokenKind>> =
        listOf(
            when (kind) {
                CssTokenKind.CDO -> consumeHtmlComment()
                CssTokenKind.Comment -> consumeCssComment()
                else -> error("Unsupported token kind: $kind")
            }
        )

    private fun consumeHtmlComment(): Token<CssTokenKind> {
        val start = iterator.offset
        iterator.nextOffset(steps = 3) // skips '<' and '!'
        while (iterator.hasNext()) {
            val char = iterator.next()
            if (char == '-' && isHtmlCommentEnd()) {
                iterator.nextOffset(steps = 4) // skips '-', '!' and '>'
                break
            }
        }

        return Token(CssTokenKind.Comment, start, iterator.offset)
    }

    private fun isHtmlCommentEnd(): Boolean =
        iterator.peek(1) == '-' && iterator.peek(2) == '!' && iterator.peek(offset = 3) == '>'

    private fun consumeCssComment(): Token<CssTokenKind> {
        val start = iterator.offset
        iterator.nextOffset() // skips '/' and '*'
        while (iterator.hasNext()) {
            val char = iterator.next()
            if (char == '*' && iterator.peek(1) == '/') {
                iterator.nextOffset(steps = 2) // skips '/'
                break
            }
        }

        return Token(CssTokenKind.Comment, start, iterator.offset)
    }
}
