/*
 * Copyright (c) 2019-2026 Ronald Brill.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.htmlunit.cssparser.parser;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * Implementation of {@link LexicalUnit}.
 *
 * @author Ronald Brill
 */
public class LexicalUnitImpl extends AbstractLocatable implements LexicalUnit, Serializable {

    /** The lexical unit type. */
    private final LexicalUnitType lexicalUnitType_;

    /** The next lexical unit. */
    private LexicalUnit nextLexicalUnit_;

    /** The previous lexical unit. */
    private LexicalUnit previousLexicalUnit_;

    /** The double value. */
    private double doubleValue_;

    /** The dimension string. */
    private String dimension_;

    /** The function name. */
    private String functionName_;

    /** The parameter lexical unit. */
    private LexicalUnit parameters_;

    /** The string value. */
    private String stringValue_;

    /** The cached string representation. */
    private transient String toString_;

    /**
     * Sets the next lexical unit.
     *
     * @param next next LexicalUnit
     */
    public void setNextLexicalUnit(final LexicalUnit next) {
        nextLexicalUnit_ = next;
    }

    /**
     * Sets the previous lexical unit.
     *
     * @param prev previous LexicalUnit
     */
    public void setPreviousLexicalUnit(final LexicalUnit prev) {
        previousLexicalUnit_ = prev;
    }

    /**
     * Sets the double value.
     *
     * @param doubleVal the double value
     */
    public void setDoubleValue(final double doubleVal) {
        doubleValue_ = doubleVal;
        toString_ = null;
    }

    /**
     * Returns the dimension.
     *
     * @return the dimension
     */
    public String getDimension() {
        return dimension_;
    }

    /**
     * Sets the dimension.
     *
     * @param dimension the new dimension
     */
    public void setDimension(final String dimension) {
        dimension_ = dimension;
        toString_ = null;
    }

    /**
     * Sets the function name.
     *
     * @param function the function name
     */
    public void setFunctionName(final String function) {
        functionName_ = function;
        toString_ = null;
    }

    /**
     * Sets the parameter lexical unit.
     *
     * @param params the parameter LexicalUnit
     */
    public void setParameters(final LexicalUnit params) {
        parameters_ = params;
        toString_ = null;
    }

    /**
     * Sets the string value.
     *
     * @param stringVal the string value
     */
    public void setStringValue(final String stringVal) {
        stringValue_ = stringVal;
        toString_ = null;
    }

    /**
     * Constructs a new LexicalUnitImpl.
     *
     * @param previous the previous LexicalUnit
     * @param type the LexicalUnitType
     */
    public LexicalUnitImpl(final LexicalUnit previous, final LexicalUnitType type) {
        lexicalUnitType_ = type;
        previousLexicalUnit_ = previous;
        if (previousLexicalUnit_ != null) {
            ((LexicalUnitImpl) previousLexicalUnit_).nextLexicalUnit_ = this;
        }
    }

    /**
     * Constructs a new integer LexicalUnitImpl.
     *
     * @param previous the previous LexicalUnit
     * @param value the int value
     */
    protected LexicalUnitImpl(final LexicalUnit previous, final int value) {
        this(previous, LexicalUnitType.INTEGER);
        doubleValue_ = value;
    }

    /**
     * Constructs a new dimension LexicalUnitImpl.
     *
     * @param previous the previous LexicalUnit
     * @param type the LexicalUnitType
     * @param value the double value
     */
    protected LexicalUnitImpl(final LexicalUnit previous, final LexicalUnitType type, final double value) {
        this(previous, type);
        doubleValue_ = value;
    }

    /**
     * Constructs a new unknown dimension LexicalUnitImpl.
     *
     * @param previous the previous LexicalUnit
     * @param type the LexicalUnitType
     * @param dimension the dimension
     * @param value the double value
     */
    protected LexicalUnitImpl(
            final LexicalUnit previous,
            final LexicalUnitType type,
            final String dimension,
            final double value) {
        this(previous, type);
        dimension_ = dimension;
        doubleValue_ = value;
    }

    /**
     * Constructs a new string LexicalUnitImpl.
     *
     * @param previous the previous LexicalUnit
     * @param type the LexicalUnitType
     * @param value the string value
     */
    public LexicalUnitImpl(final LexicalUnit previous, final LexicalUnitType type, final String value) {
        this(previous, type);
        stringValue_ = value;
    }

    /**
     * Constructs a new function LexicalUnitImpl.
     *
     * @param previous the previous LexicalUnit
     * @param type the LexicalUnitType
     * @param name the name
     * @param params the parameter LexicalUnit
     */
    protected LexicalUnitImpl(
            final LexicalUnit previous,
            final LexicalUnitType type,
            final String name,
            final LexicalUnit params) {
        this(previous, type);
        functionName_ = name;
        parameters_ = params;
    }

    /**
     * Constructs a new function LexicalUnitImpl.
     *
     * @param previous the previous LexicalUnit
     * @param type the LexicalUnitType
     * @param name the name
     * @param stringValue the string value
     */
    protected LexicalUnitImpl(final LexicalUnit previous, final LexicalUnitType type, final String name,
            final String stringValue) {
        this(previous, type);
        functionName_ = name;
        stringValue_ = stringValue;
    }

    /** {@inheritDoc} */
    @Override
    public LexicalUnitType getLexicalUnitType() {
        return lexicalUnitType_;
    }

    /** {@inheritDoc} */
    @Override
    public LexicalUnit getNextLexicalUnit() {
        return nextLexicalUnit_;
    }

    /** {@inheritDoc} */
    @Override
    public LexicalUnit getPreviousLexicalUnit() {
        return previousLexicalUnit_;
    }

    /** {@inheritDoc} */
    @Override
    public int getIntegerValue() {
        return (int) doubleValue_;
    }

    /** {@inheritDoc} */
    @Override
    public double getDoubleValue() {
        return doubleValue_;
    }

    /** {@inheritDoc} */
    @Override
    public String getDimensionUnitText() {
        return switch (lexicalUnitType_) {
            case EM -> "em";
            case REM -> "rem";
            case EX -> "ex";
            case CH -> "ch";
            case VW -> "vw";
            case VH -> "vh";
            case VMIN -> "vmin";
            case VMAX -> "vmax";
            case DVW -> "dvw";
            case DVH -> "dvh";
            case DVMIN -> "dvmin";
            case DVMAX -> "dvmax";
            case LVW -> "lvw";
            case LVH -> "lvh";
            case LVMIN -> "lvmin";
            case LVMAX -> "lvmax";
            case SVW -> "svw";
            case SVH -> "svh";
            case SVMIN -> "svmin";
            case SVMAX -> "svmax";
            case PIXEL -> "px";
            case INCH -> "in";
            case CENTIMETER -> "cm";
            case MILLIMETER -> "mm";
            case POINT -> "pt";
            case PICA -> "pc";
            case QUARTER -> "Q";
            case PERCENTAGE -> "%";
            case DEGREE -> "deg";
            case GRADIAN -> "grad";
            case RADIAN -> "rad";
            case TURN -> "turn";
            case MILLISECOND -> "ms";
            case SECOND -> "s";
            case HERTZ -> "Hz";
            case KILOHERTZ -> "kHz";
            case DIMENSION -> dimension_;
            default -> "";
        };
    }

    /** {@inheritDoc} */
    @Override
    public String getFunctionName() {
        return functionName_;
    }

    /** {@inheritDoc} */
    @Override
    public LexicalUnit getParameters() {
        return parameters_;
    }

    /** {@inheritDoc} */
    @Override
    public String getStringValue() {
        return stringValue_;
    }

    /** {@inheritDoc} */
    @Override
    public LexicalUnit getSubValues() {
        return parameters_;
    }

    /**
     * Returns the current CSS text.
     *
     * @return the current css text
     */
    public String getCssText() {
        if (null != toString_) {
            return toString_;
        }

        final StringBuilder sb = new StringBuilder();
        switch (lexicalUnitType_) {
            case OPERATOR_COMMA:
                sb.append(",");
                break;
            case OPERATOR_PLUS:
                sb.append("+");
                break;
            case OPERATOR_MINUS:
                sb.append("-");
                break;
            case OPERATOR_MULTIPLY:
                sb.append("*");
                break;
            case OPERATOR_SLASH:
                sb.append("/");
                break;
            case OPERATOR_MOD:
                sb.append("%");
                break;
            case OPERATOR_EXP:
                sb.append("^");
                break;
            case OPERATOR_LT:
                sb.append("<");
                break;
            case OPERATOR_GT:
                sb.append(">");
                break;
            case OPERATOR_LE:
                sb.append("<=");
                break;
            case OPERATOR_GE:
                sb.append(">=");
                break;
            case OPERATOR_TILDE:
                sb.append("~");
                break;
            case INHERIT:
                sb.append("inherit");
                break;
            case INTEGER:
                sb.append(String.valueOf(getIntegerValue()));
                break;
            case REAL:
                sb.append(getTrimedDoubleValue());
                break;
            case EM:
            case REM:
            case EX:
            case CH:
            case VW:
            case VH:
            case VMIN:
            case VMAX:
            case DVW:
            case DVH:
            case DVMIN:
            case DVMAX:
            case LVW:
            case LVH:
            case LVMIN:
            case LVMAX:
            case SVW:
            case SVH:
            case SVMIN:
            case SVMAX:
            case PIXEL:
            case INCH:
            case CENTIMETER:
            case MILLIMETER:
            case POINT:
            case PICA:
            case QUARTER:
            case PERCENTAGE:
            case DEGREE:
            case GRADIAN:
            case RADIAN:
            case TURN:
            case MILLISECOND:
            case SECOND:
            case HERTZ:
            case KILOHERTZ:
            case DIMENSION:
                sb.append(getTrimedDoubleValue());
                final String dimUnitText = getDimensionUnitText();
                if (null != dimUnitText) {
                    sb.append(dimUnitText);
                }
                break;
            case URI:
                sb.append("url(\"").append(getStringValue()).append("\")");
                break;
            case COUNTER_FUNCTION:
                sb.append("counter(");
                appendParams(sb);
                sb.append(")");
                break;
            case COUNTERS_FUNCTION:
                sb.append("counters(");
                appendParams(sb);
                sb.append(")");
                break;
            case RGBCOLOR:
                sb.append("rgb(");
                appendParams(sb);
                sb.append(")");
                break;
            case HSLCOLOR:
                sb.append("hsl(");
                appendParams(sb);
                sb.append(")");
                break;
            case HWBCOLOR:
                sb.append("hwb(");
                appendParams(sb);
                sb.append(")");
                break;
            case LABCOLOR:
                sb.append("lab(");
                appendParams(sb);
                sb.append(")");
                break;
            case LCHCOLOR:
                sb.append("lch(");
                appendParams(sb);
                sb.append(")");
                break;
            case NONE:
                sb.append("none");
                break;
            case FROM:
                sb.append("from");
                break;
            case IDENT:
                sb.append(getStringValue());
                break;
            case STRING_VALUE:
                sb.append("\"");

                String value = getStringValue();
                // replace line breaks
                value = value.replace("\n", "\\A ").replace("\r", "\\D ");
                sb.append(value);

                sb.append("\"");
                break;
            case ATTR:
                sb.append("attr(")
                    .append(getStringValue())
                    .append(")");
                break;
            case RECT_FUNCTION:
                sb.append("rect(");
                appendParams(sb);
                sb.append(")");
                break;
            case UNICODERANGE:
                final String range = getStringValue();
                if (null != range) {
                    sb.append(range);
                }
                break;
            case FUNCTION:
            case FUNCTION_CALC:
                final String functName = getFunctionName();
                if (null != functName) {
                    sb.append(functName);
                }
                sb.append('(');
                appendParams(sb);
                sb.append(")");
                break;
            default:
                break;
        }
        toString_ = sb.toString();
        return toString_;
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return getCssText();
    }

    /**
     * Returns a string representation to help with debugging.
     *
     * @return a string helping to debug
     */
    public String toDebugString() {
        final StringBuilder sb = new StringBuilder();
        switch (lexicalUnitType_) {
            case OPERATOR_COMMA:
                sb.append("OPERATOR_COMMA");
                break;
            case OPERATOR_PLUS:
                sb.append("OPERATOR_PLUS");
                break;
            case OPERATOR_MINUS:
                sb.append("OPERATOR_MINUS");
                break;
            case OPERATOR_MULTIPLY:
                sb.append("OPERATOR_MULTIPLY");
                break;
            case OPERATOR_SLASH:
                sb.append("OPERATOR_SLASH");
                break;
            case OPERATOR_MOD:
                sb.append("OPERATOR_MOD");
                break;
            case OPERATOR_EXP:
                sb.append("OPERATOR_EXP");
                break;
            case OPERATOR_LT:
                sb.append("OPERATOR_LT");
                break;
            case OPERATOR_GT:
                sb.append("OPERATOR_GT");
                break;
            case OPERATOR_LE:
                sb.append("OPERATOR_LE");
                break;
            case OPERATOR_GE:
                sb.append("OPERATOR_GE");
                break;
            case OPERATOR_TILDE:
                sb.append("OPERATOR_TILDE");
                break;
            case INHERIT:
                sb.append("INHERIT");
                break;
            case INTEGER:
                sb.append("INTEGER(")
                    .append(String.valueOf(getIntegerValue()))
                    .append(")");
                break;
            case REAL:
                sb.append("REAL(")
                    .append(getTrimedDoubleValue())
                    .append(")");
                break;
            case EM:
                sb.append("EM(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case REM:
                sb.append("REM(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case EX:
                sb.append("EX(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case CH:
                sb.append("CH(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case VW:
                sb.append("VW(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case VH:
                sb.append("VH(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case VMIN:
                sb.append("VMIN(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case VMAX:
                sb.append("VMAX(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case DVW:
                sb.append("DVW(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case DVH:
                sb.append("DVH(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case DVMIN:
                sb.append("DVMIN(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case DVMAX:
                sb.append("DVMAX(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case LVW:
                sb.append("LVW(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case LVH:
                sb.append("LVH(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case LVMIN:
                sb.append("LVMIN(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case LVMAX:
                sb.append("LVMAX(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case SVW:
                sb.append("SVW(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case SVH:
                sb.append("SVH(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case SVMIN:
                sb.append("SVMIN(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case SVMAX:
                sb.append("SVMAX(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case PIXEL:
                sb.append("PIXEL(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case INCH:
                sb.append("INCH(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case CENTIMETER:
                sb.append("CENTIMETER(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case MILLIMETER:
                sb.append("MILLIMETER(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case POINT:
                sb.append("POINT(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case PICA:
                sb.append("PICA(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case QUARTER:
                sb.append("QUARTER(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case PERCENTAGE:
                sb.append("PERCENTAGE(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case DEGREE:
                sb.append("DEGREE(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case GRADIAN:
                sb.append("GRADIAN(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case RADIAN:
                sb.append("RADIAN(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case TURN:
                sb.append("TURN(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case MILLISECOND:
                sb.append("MILLISECOND(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case SECOND:
                sb.append("SECOND(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case HERTZ:
                sb.append("HERTZ(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case KILOHERTZ:
                sb.append("KILOHERTZ(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case DIMENSION:
                sb.append("DIMENSION(")
                    .append(getTrimedDoubleValue())
                    .append(getDimensionUnitText())
                    .append(")");
                break;
            case URI:
                sb.append("URI(url(")
                    .append(getStringValue())
                    .append("))");
                break;
            case COUNTER_FUNCTION:
                sb.append("COUNTER_FUNCTION(counter(");
                appendParams(sb);
                sb.append("))");
                break;
            case COUNTERS_FUNCTION:
                sb.append("COUNTERS_FUNCTION(counters(");
                appendParams(sb);
                sb.append("))");
                break;
            case RGBCOLOR:
                sb.append("RGBCOLOR(rgb(");
                appendParams(sb);
                sb.append("))");
                break;
            case HSLCOLOR:
                sb.append("HSLCOLOR(hsl(");
                appendParams(sb);
                sb.append("))");
                break;
            case HWBCOLOR:
                sb.append("HWBCOLOR(hwb(");
                appendParams(sb);
                sb.append("))");
                break;
            case LABCOLOR:
                sb.append("LABCOLOR(lab(");
                appendParams(sb);
                sb.append("))");
                break;
            case LCHCOLOR:
                sb.append("LCHCOLOR(lch(");
                appendParams(sb);
                sb.append("))");
                break;

            case IDENT:
                sb.append("IDENT(")
                    .append(getStringValue())
                    .append(")");
                break;
            case STRING_VALUE:
                sb.append("STRING_VALUE(\"")
                    .append(getStringValue())
                    .append("\")");
                break;
            case ATTR:
                sb.append("ATTR(attr(")
                    .append(getStringValue())
                    .append("))");
                break;
            case RECT_FUNCTION:
                sb.append("RECT_FUNCTION(rect(");
                appendParams(sb);
                sb.append("))");
                break;
            case UNICODERANGE:
                sb.append("UNICODERANGE(")
                    .append(getStringValue())
                    .append(")");
                break;
            case FUNCTION:
            case FUNCTION_CALC:
                sb.append("FUNCTION(")
                    .append(getFunctionName())
                    .append("(");
                LexicalUnit l = parameters_;
                while (l != null) {
                    sb.append(l);
                    l = l.getNextLexicalUnit();
                }
                sb.append("))");
                break;
            default:
                break;
        }
        return sb.toString();
    }

    /**
     * Appends parameter lexical units to the string builder.
     *
     * @param sb the string builder
     */
    private void appendParams(final StringBuilder sb) {
        LexicalUnit l = parameters_;
        if (l != null) {
            sb.append(l);

            LexicalUnit last = l;
            l = l.getNextLexicalUnit();
            while (l != null) {
                if (l.getLexicalUnitType() != LexicalUnitType.OPERATOR_COMMA
                        && !"=".equals(l.toString())
                        && !"=".equals(last.toString())) {
                    sb.append(" ");
                }
                sb.append(l);

                last = l;
                l = l.getNextLexicalUnit();
            }
        }
    }

    /**
     * Returns the trimmed double value formatted as a string.
     *
     * @return the trimmed double value string
     */
    private String getTrimedDoubleValue() {
        final double d = getDoubleValue();
        final int i = (int) d;

        if (d - i == 0) {
            return Integer.toString(i);
        }

        // i know this is uggly - suggestions are welcome
        final String str = Double.toString(d);
        if (str.contains("E")) {
            final DecimalFormat decimalFormat =
                    new DecimalFormat("0", DecimalFormatSymbols.getInstance(Locale.ENGLISH));
            decimalFormat.setGroupingUsed(false);
            decimalFormat.setMaximumFractionDigits(7);
            return decimalFormat.format(d);
        }
        return str;
    }

    /**
     * Creates a lexical unit with type integer.
     *
     * @param prev the previous LexicalUnit
     * @param i the integer value
     * @return lexical unit with type integer
     */
    public static LexicalUnit createNumber(final LexicalUnit prev, final int i) {
        return new LexicalUnitImpl(prev, LexicalUnitType.INTEGER, i);
    }

    /**
     * Creates a lexical unit with type real.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type real
     */
    public static LexicalUnit createNumber(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.REAL, d);
    }

    /**
     * Creates a lexical unit with type percentage.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type percent
     */
    public static LexicalUnit createPercentage(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.PERCENTAGE, d);
    }

    /**
     * Creates a lexical unit with type pixel.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type pixel
     */
    public static LexicalUnit createPixel(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.PIXEL, d);
    }

    /**
     * Creates a lexical unit with type centimeter.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type centimeter
     */
    public static LexicalUnit createCentimeter(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.CENTIMETER, d);
    }

    /**
     * Creates a lexical unit with type millimeter.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type millimeter
     */
    public static LexicalUnit createMillimeter(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.MILLIMETER, d);
    }

    /**
     * Creates a lexical unit with type inch.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type inch
     */
    public static LexicalUnit createInch(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.INCH, d);
    }

    /**
     * Creates a lexical unit with type point.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type point
     */
    public static LexicalUnit createPoint(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.POINT, d);
    }

    /**
     * Creates a lexical unit with type pica.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type pica
     */
    public static LexicalUnit createPica(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.PICA, d);
    }

    /**
     * Creates a lexical unit with type quarter.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type quarter
     */
    public static LexicalUnit createQuarter(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.QUARTER, d);
    }

    /**
     * Creates a lexical unit with type em.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type em
     */
    public static LexicalUnit createEm(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.EM, d);
    }

    /**
     * Creates a lexical unit with type rem.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type rem
     */
    public static LexicalUnit createRem(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.REM, d);
    }

    /**
     * Creates a lexical unit with type ex.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type ex
     */
    public static LexicalUnit createEx(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.EX, d);
    }

    /**
     * Creates a lexical unit with type ch.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type ch
     */
    public static LexicalUnit createCh(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.CH, d);
    }

    /**
     * Creates a lexical unit with type vw.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type vw
     */
    public static LexicalUnit createVw(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.VW, d);
    }

    /**
     * Creates a lexical unit with type vh.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type vh
     */
    public static LexicalUnit createVh(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.VH, d);
    }

    /**
     * Creates a lexical unit with type vmin.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type vmin
     */
    public static LexicalUnit createVMin(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.VMIN, d);
    }

    /**
     * Creates a lexical unit with type vmax.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type vmax
     */
    public static LexicalUnit createVMax(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.VMAX, d);
    }

    /**
     * Creates a lexical unit with type dvw.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type dvw
     */
    public static LexicalUnit createDvw(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.DVW, d);
    }

    /**
     * Creates a lexical unit with type dvh.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type dvh
     */
    public static LexicalUnit createDvh(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.DVH, d);
    }

    /**
     * Creates a lexical unit with type dvmin.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type dvmin
     */
    public static LexicalUnit createDvMin(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.DVMIN, d);
    }

    /**
     * Creates a lexical unit with type dvmax.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type dvmax
     */
    public static LexicalUnit createDvMax(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.DVMAX, d);
    }

    /**
     * Creates a lexical unit with type lvw.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type lvw
     */
    public static LexicalUnit createLvw(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.LVW, d);
    }

    /**
     * Creates a lexical unit with type lvh.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type lvh
     */
    public static LexicalUnit createLvh(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.LVH, d);
    }

    /**
     * Creates a lexical unit with type lvmin.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type lvmin
     */
    public static LexicalUnit createLvMin(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.LVMIN, d);
    }

    /**
     * Creates a lexical unit with type lvmax.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type lvmax
     */
    public static LexicalUnit createLvMax(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.LVMAX, d);
    }

    /**
     * Creates a lexical unit with type svw.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type svw
     */
    public static LexicalUnit createSvw(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.SVW, d);
    }

    /**
     * Creates a lexical unit with type svh.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type svh
     */
    public static LexicalUnit createSvh(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.SVH, d);
    }

    /**
     * Creates a lexical unit with type svmin.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type svmin
     */
    public static LexicalUnit createSvMin(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.SVMIN, d);
    }

    /**
     * Creates a lexical unit with type svmax.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type svmax
     */
    public static LexicalUnit createSvMax(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.SVMAX, d);
    }

    /**
     * Creates a lexical unit with type degree.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type degree
     */
    public static LexicalUnit createDegree(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.DEGREE, d);
    }

    /**
     * Creates a lexical unit with type radian.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type radian
     */
    public static LexicalUnit createRadian(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.RADIAN, d);
    }

    /**
     * Creates a lexical unit with type gradian.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type gradian
     */
    public static LexicalUnit createGradian(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.GRADIAN, d);
    }

    /**
     * Creates a lexical unit with type turn.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type turn
     */
    public static LexicalUnit createTurn(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.TURN, d);
    }

    /**
     * Creates a lexical unit with type millisecond.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type millisecond
     */
    public static LexicalUnit createMillisecond(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.MILLISECOND, d);
    }

    /**
     * Creates a lexical unit with type second.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type second
     */
    public static LexicalUnit createSecond(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.SECOND, d);
    }

    /**
     * Creates a lexical unit with type hertz.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type hertz
     */
    public static LexicalUnit createHertz(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.HERTZ, d);
    }

    /**
     * Creates a lexical unit with type dimension.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @param dim the dimension
     * @return lexical unit with type dimension
     */
    public static LexicalUnit createDimension(final LexicalUnit prev, final double d, final String dim) {
        return new LexicalUnitImpl(prev, LexicalUnitType.DIMENSION, dim, d);
    }

    /**
     * Creates a lexical unit with type kilohertz.
     *
     * @param prev the previous LexicalUnit
     * @param d the double value
     * @return lexical unit with type kilohertz
     */
    public static LexicalUnit createKiloHertz(final LexicalUnit prev, final double d) {
        return new LexicalUnitImpl(prev, LexicalUnitType.KILOHERTZ, d);
    }

    /**
     * Creates a lexical unit with type counter function.
     *
     * @param prev the previous LexicalUnit
     * @param params the params
     * @return lexical unit with type counter
     */
    public static LexicalUnit createCounter(final LexicalUnit prev, final LexicalUnit params) {
        return new LexicalUnitImpl(prev, LexicalUnitType.COUNTER_FUNCTION, "counter", params);
    }

    /**
     * Creates a lexical unit with type counters function.
     *
     * @param prev the previous LexicalUnit
     * @param params the params
     * @return lexical unit with type counters
     */
    public static LexicalUnit createCounters(final LexicalUnit prev, final LexicalUnit params) {
        return new LexicalUnitImpl(prev, LexicalUnitType.COUNTERS_FUNCTION, "counters", params);
    }

    /**
     * Creates a lexical unit with type attr.
     *
     * @param prev the previous LexicalUnit
     * @param value the value
     * @return lexical unit with type attr
     */
    public static LexicalUnit createAttr(final LexicalUnit prev, final String value) {
        // according to LexicalUnit.ATTR, LexicalUnit.getStringValue(), not
        // LexicalUnit.getParameters() is applicable
        return new LexicalUnitImpl(prev, LexicalUnitType.ATTR, "name", value);
    }

    /**
     * Creates a lexical unit with type rect function.
     *
     * @param prev the previous LexicalUnit
     * @param params the params
     * @return lexical unit with type rect
     */
    public static LexicalUnit createRect(final LexicalUnit prev, final LexicalUnit params) {
        return new LexicalUnitImpl(prev, LexicalUnitType.RECT_FUNCTION, "rect", params);
    }

    /**
     * Creates a lexical unit with type rgb color.
     *
     * @param prev the previous LexicalUnit
     * @param funct the name rgb or rgba
     * @param params the params
     * @return lexical unit with type rgb color
     */
    public static LexicalUnit createRgbColor(final LexicalUnit prev, final String funct, final LexicalUnit params) {
        return new LexicalUnitImpl(prev, LexicalUnitType.RGBCOLOR, funct, params);
    }

    /**
     * Creates a lexical unit with type hsl color.
     *
     * @param prev the previous LexicalUnit
     * @param funct the name hsl or hsla
     * @param params the params
     * @return lexical unit with type hsl color
     */
    public static LexicalUnit createHslColor(final LexicalUnit prev, final String funct, final LexicalUnit params) {
        return new LexicalUnitImpl(prev, LexicalUnitType.HSLCOLOR, funct, params);
    }

    /**
     * Creates a lexical unit with type hwb color.
     *
     * @param prev the previous LexicalUnit
     * @param funct the name hwb
     * @param params the params
     * @return lexical unit with type hwb color
     */
    public static LexicalUnit createHwbColor(final LexicalUnit prev, final String funct, final LexicalUnit params) {
        return new LexicalUnitImpl(prev, LexicalUnitType.HWBCOLOR, funct, params);
    }

    /**
     * Creates a lexical unit with type lab color.
     *
     * @param prev the previous LexicalUnit
     * @param funct the name lab
     * @param params the params
     * @return lexical unit with type lab color
     */
    public static LexicalUnit createLabColor(final LexicalUnit prev, final String funct, final LexicalUnit params) {
        return new LexicalUnitImpl(prev, LexicalUnitType.LABCOLOR, funct, params);
    }

    /**
     * Creates a lexical unit with type lch color.
     *
     * @param prev the previous LexicalUnit
     * @param funct the name lch
     * @param params the params
     * @return lexical unit with type lch color
     */
    public static LexicalUnit createLchColor(final LexicalUnit prev, final String funct, final LexicalUnit params) {
        return new LexicalUnitImpl(prev, LexicalUnitType.LCHCOLOR, funct, params);
    }

    /**
     * Creates a lexical unit with type none.
     *
     * @param prev the previous LexicalUnit
     * @return lexical unit with type rgb color
     */
    public static LexicalUnit createNone(final LexicalUnit prev) {
        return new LexicalUnitImpl(prev, LexicalUnitType.NONE);
    }

    /**
     * Creates a lexical unit with type from.
     *
     * @param prev the previous LexicalUnit
     * @return lexical unit with type rgb color
     */
    public static LexicalUnit createFrom(final LexicalUnit prev) {
        return new LexicalUnitImpl(prev, LexicalUnitType.FROM);
    }

    /**
     * Creates a lexical unit with type calc function.
     *
     * @param prev the previous LexicalUnit
     * @param params the params
     * @return lexical unit with type calc
     */
    public static LexicalUnit createCalc(final LexicalUnit prev, final LexicalUnit params) {
        return new LexicalUnitImpl(prev, LexicalUnitType.FUNCTION_CALC, "calc", params);
    }

    /**
     * Creates a lexical unit with type function.
     *
     * @param prev the previous LexicalUnit
     * @param name the name
     * @param params the params
     * @return lexical unit with type function
     */
    public static LexicalUnit createFunction(final LexicalUnit prev, final String name, final LexicalUnit params) {
        return new LexicalUnitImpl(prev, LexicalUnitType.FUNCTION, name, params);
    }

    /**
     * Creates a lexical unit with type string.
     *
     * @param prev the previous LexicalUnit
     * @param value the value
     * @return lexical unit with type string
     */
    public static LexicalUnit createString(final LexicalUnit prev, final String value) {
        return new LexicalUnitImpl(prev, LexicalUnitType.STRING_VALUE, value);
    }

    /**
     * Creates a lexical unit with type ident.
     *
     * @param prev the previous LexicalUnit
     * @param value the value
     * @return lexical unit with type ident
     */
    public static LexicalUnit createIdent(final LexicalUnit prev, final String value) {
        return new LexicalUnitImpl(prev, LexicalUnitType.IDENT, value);
    }

    /**
     * Creates a lexical unit with type uri.
     *
     * @param prev the previous LexicalUnit
     * @param value the value
     * @return lexical unit with type uri
     */
    public static LexicalUnit createURI(final LexicalUnit prev, final String value) {
        return new LexicalUnitImpl(prev, LexicalUnitType.URI, value);
    }

    /**
     * Creates a lexical unit with type comma.
     *
     * @param prev the previous LexicalUnit
     * @return lexical unit with type comma
     */
    public static LexicalUnit createComma(final LexicalUnit prev) {
        return new LexicalUnitImpl(prev, LexicalUnitType.OPERATOR_COMMA);
    }

    /**
     * Creates a lexical unit with type inherit.
     *
     * @param prev the previous LexicalUnit
     * @return lexical unit with type comma
     */
    public static LexicalUnit createInherit(final LexicalUnit prev) {
        return new LexicalUnitImpl(prev, LexicalUnitType.INHERIT);
    }

    /**
     * Creates a lexical unit with type slash.
     *
     * @param prev the previous LexicalUnit
     * @return lexical unit with type slash
     */
    public static LexicalUnit createSlash(final LexicalUnit prev) {
        return new LexicalUnitImpl(prev, LexicalUnitType.OPERATOR_SLASH);
    }

    /**
     * Creates a lexical unit with type plus.
     *
     * @param prev the previous LexicalUnit
     * @return lexical unit with type plus
     */
    public static LexicalUnit createPlus(final LexicalUnit prev) {
        return new LexicalUnitImpl(prev, LexicalUnitType.OPERATOR_PLUS);
    }

    /**
     * Creates a lexical unit with type minus.
     *
     * @param prev the previous LexicalUnit
     * @return lexical unit with type minus
     */
    public static LexicalUnit createMinus(final LexicalUnit prev) {
        return new LexicalUnitImpl(prev, LexicalUnitType.OPERATOR_MINUS);
    }

    /**
     * Creates a lexical unit with type multiply.
     *
     * @param prev the previous LexicalUnit
     * @return lexical unit with type multiply
     */
    public static LexicalUnit createMultiply(final LexicalUnit prev) {
        return new LexicalUnitImpl(prev, LexicalUnitType.OPERATOR_MULTIPLY);
    }

    /**
     * Creates a lexical unit with type divide.
     *
     * @param prev the previous LexicalUnit
     * @return lexical unit with type slash
     */
    public static LexicalUnit createDivide(final LexicalUnit prev) {
        return new LexicalUnitImpl(prev, LexicalUnitType.OPERATOR_SLASH);
    }
}
