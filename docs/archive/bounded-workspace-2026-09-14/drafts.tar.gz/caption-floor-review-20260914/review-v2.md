# caption and priority floor source review

status: reviewed draft; no main edits or tests
origin: 2026-09-14, merged delivery dd21213, policy failure 6dded3c49238634a
area: proof ownership and registry consolidation

## caption

- the pinned owner 79df181bebc3335b9ce6b5dbf90fecf258ae8eba46b3a54f9954fe9bac85b463 exists in d455fe544cd3db9d253693a374128187560adf43 and earlier snapshots; its complete file sha256 is cea493108564618c2a146cf709636013431be45e3c9748097c36b05c1d7c2818.
- current owner 3a193352cb5f38a85241d1d6e5bb6f297a753326546bc0497fe2cbf1c7a3fbf6 first appears in the reviewed spool candidate 964da5aec22ccc97343107ce3e08e827602fa4f9. delivery HEAD retains that exact source, complete file sha256 7b61ded7407dca6fdb9492ca9b1094285515ccd7853616654bc04df574bff5a1.
- this is more than an import-only change: the proof enters the production parser_attempt_directory, passes it into build_epub_extraction_plan, and reads the first staged fragment through read_epub_fragment before publishing inside the same attempt scope. the earlier plan.fragment_specs in-memory interface no longer exists. the current public read returns exact UTF-8 with newline preservation.
- all independent expected source literals, publication limits, member byte/hash assertions, caption range (4,16), authored anchor offset 4, unit/fragment identity, rendered caption element, original source bytes, and cleanup are unchanged. no fake, relaxed assertion, substituted source, or new claim was introduced.
- the original caption defect red 58f65f6f1291df22 and ordinary green 940b798f8a9a3b7a precede the spool interface. the eight-file spool candidate ordinary command b62b8c26fe4e0c77 is historical supporting execution. it does not substitute for current caption canonical sensitivity.
- recommend the exact one-row caption pin update, preserving the caption-removal mutation and fingerprint `epub sanitizer discarded the authored table caption`. then run the existing canonical proof/fault through scripts/test. no source correction is required by this review.

## ownership floor

- pinned add57541fb7791ac5f4556c8a8d44eb4e0debb63005663c460d07e3fee26ee00 exactly matches delivery checkpoint 8c0ab40084e518f507fabe6b63d29d66f7284b05, also fe6e19db5e4593525719a53a770ed78fa045046d and three retained earlier checkpoints. the baseline is recovered from git, not reconstructed from the current map.
- compare every priority risk's sorted source_globs, proofs and capabilities using the current owner serialization. current 9cd05ed8302bfcb9bee5acb7f666d95707b469d71d7eef0e5c1367eeafd2aa0c adds 14 source entries, 11 proofs and one capability across six existing risks. no risk, source entry, proof, or capability is removed. no existing canonical identity changes; the structural-anchor proof only changes ordering in JSON. all added physical proof paths and exact Python nodes exist; no new proof is assigned to two risks.
- upstream consolidation 9a1ee26352 contributes compatible reader source routing, article extraction/citation ownership, linked-runtime isolation and codex import lifetime coverage. 318747fb5c adds the actual pytest reporter proof. a5c84ebc3d adds the six separately reviewed client proofs and their three missing source owners. these expand the original coverage; they do not delete the superseded-cutover acceptance gates.
- the sole capability addition, ingest-node under citation-provenance-identity, is backed by the registered real node article-extraction owner. remaining additions use capabilities the corresponding risks already declare.
- floor-delta-v1.json contains every exact addition/removal by risk and field. recommend the one-line model floor update only after parent review of that inventory. a floor pin attests registry ownership, not successful execution or current source qualification; outstanding client/caption sensitivities remain open.

## other global blockers

- the merged manifest retains both llm-tools-legacy-browse-owner-bypass (row 52) and browse-provider-query-round-trip-bypass (row 230) on the same canonical pinned-tools proof. this independently emits fault-proof-owner in addition to the browse patch applicability failure. only one fault can remain on that owner; runtime/parent owns that arbitration.
- the seventh finding is the new bounded-dossier-receipt-reference-bypass fault targeting python/nexus_test_control/policy.py. _is_product_path only admits six named controller runtime files and excludes policy.py, so fault_manifest_violations emits fault-product-only. the registry review missed this exact product-path admission requirement. raw SQL, caption drift, two fault applicability failures, duplicate fault owner, floor mismatch and this exclusion account for all seven. generation eval provider corpus pins are separately ticketed and are not one of these seven policy violations.
- policy.py is the actual executable controller validation owner. any correction should add only that concrete product owner to the existing controller product allowlist, subject to independent review and actual policy sensitivity, while retaining rejection of tests, fixture and oracle paths. no fault or checker weakening is proposed.
