# truncated pytest summary privacy correction

status: draft only; no tests or main edits
origin: c7f4c2b64f39176f and independent parameter-node review
area: controller retained failure artifacts

actual c7 evidence remains in observed-canary.json. pytest terminal summary truncates the message before the parent sees it; exact secret replacement cannot match the surviving prefix. the structured record and classified detail were already safe.

the revised artifact correction discards the entire recognized truncated failed/error line, retaining its status and ellipsis. a parameterized node may itself contain ` - `, so retaining any guessed node prefix is unsafe. exact node/message ownership stays with the existing redacted structured record. no capture bound, secret environment, exception classification or incomplete-record rule changes.

the appended actual fixed-child case has an artificial parent-only secret `local- - secret-canary` in its parameter id and an ordinary long failure message. it uses pytest's public --force-short-summary option to exercise the same real terminal formatting under ci. the child explicitly proves api_token was withheld and derives its fake id from hex source bytes. the proof requires exact redacted node, phase, type, message, untruncated record and no retained secret prefix. all original 13 cases are unchanged. this catches the rejected partition draft because its first delimiter occurs inside the otherwise-complete node secret.

pending: source review and actual paved reporter replay. neither draft inspection nor c7 establishes candidate green.
