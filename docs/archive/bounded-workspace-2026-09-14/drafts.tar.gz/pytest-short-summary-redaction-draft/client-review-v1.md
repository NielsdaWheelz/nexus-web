# short-summary redaction review

status: source-only review; no tests or main edits
origin: actual c7f4c2b64f39176f at 0d3b2164aea65bf06f5948b31ecb1e59e58e1f11
reviewed draft sha256: 899cdd43fcf8a7f6a7695c0e508160e604f7b8294edeebf1359168e578e2c8da

## choice

keep the correction in _failure_artifacts, but dispose of the whole recognized truncated FAILED/ERROR summary line, retaining only its status and ellipsis. do not retain a guessed node prefix from line.partition(" - "). the complete structured record already supplies node, phase, exception type, message and frame; absent/truncated/malformed structured records still fail classification closed. this affects retained duplicate human text only, not the actual exception or assertion outcome.

## observed cause

the actual owned-0 canary failure already has a correctly redacted structured message and parent detail. its retained log alone contains the terminal-width prefix local- followed by a cut quote-containing token. installed terminal.py1494-1550 trims only the reprcrash message; its node id remains whole. exact raw/JSON secret replacement after this transformation cannot recover the omitted suffix. the draft addresses this observed loss of redaction input.

## one required correction

pytest node ids may contain parameter strings with the literal delimiter ` - `. _get_node_id_with_markup retains the whole node; the draft's first partition would truncate inside such a node before the parent redactor sees it. if that parameter contains a parent-only secret with the delimiter, the new log transform itself destroys its complete spelling and preserves a partial prefix. using the last delimiter is also ambiguous when the failure message contains one. retaining no node from this already-truncated duplicate is simpler and correct. structured node redaction/bounding is unchanged.

## rejected alternatives

- redact report.longrepr or reprcrash before terminal rendering: an owned child can know its own environment secrets, but the existing fixed child deliberately does not receive caller API_TOKEN. its actual test constructs the artificial value without changing that isolation. report mutation cannot redact an unknown parent secret and is therefore insufficient for the required fixed case.
- supply parent secret material to the reporter: changes the existing child environment isolation contract solely to repair logging.
- increase terminal width, enable verbose output or change the structured field limit: changes output cost and does not establish a bound that preserves every full value.
- guess secret prefixes: admits false redactions and still cannot identify arbitrary cuts honestly.

pytest assertion representations may already contain formatted text before the hook. no claim about every possible rewritten representation follows from this observed terminal-summary fix. the existing source proof covers actual AssertionError/pytest.fail classification and owned/fixed environments; no evidence here requires mutating their reports or broadening the redaction architecture.

replay the unchanged reporter owner and focused enclosing owners through scripts/test after the correction. c7 is the existing pre-fix witness; no candidate green is claimed.
