# pytest terminal truncation redaction

status: source-only draft; no main edits or tests.
origin: actual privacy failure c7f4c2b64f39176f at0d3b2164, owned-0 case.

## exact cause

retained child service-1.pytest.json already contains only the correctly
redacted message. parent classified detail also has the correct redaction.
the child service-1.log alone retains this artificial canary prefix:

`FAILED test_owned.py::test_owned - Failed: owned primary invariant local-"sec...`

pytest terminal.py:_format_trimmed truncates the first line to terminal width
before writing this duplicate summary. it destroys the full secret spelling;
our raw/JSON exact replacements cannot recover the omitted suffix. this is not
another JSON escaping defect. observed-canary.json preserves only the declared
artificial input, exact observed line and original artifact hashes.

## narrow owner repair

only _failure_artifacts changes. for pytest stdout, when a FAILED/ERROR short
summary has its message delimiter and ends in pytest's three-dot truncation,
retain status/node and the existing ellipsis, removing the incomplete message.
then run the existing raw/JSON secret redaction unchanged. each affected line
can only shrink; no raw capture or record bound is increased. complete summaries,
custom terminal output, ordinary stdout/stderr, structured failures and exact
classification remain at their existing owners. non-pytest logs are unchanged.

a partial terminal message cannot be a trustworthy secret-redaction input. the
separate bounded failure record already owns phase/type/full message/frame;
missing/truncated records remain fail-closed. this does not guess secret prefix
lengths, parse arbitrary representations, suppress pytest hooks, change report
verbosity, expose parent-only secrets to a child, or weaken the source oracle.

## pending evidence

all13 existing reporter cases remain byte-identical, including owned/fixed child
environments, both padding values, missing/malformed/truncated classifications,
phase/type/frame checks, primary message assertions and raw-log length bound.
no new tests or fault owner are needed for this witnessed defect. replay the
whole existing reporter file after review, then the pending combined owners:

```sh
./scripts/test changed pytest:python/tests/kernel/nexus_test_control/test_pytest_report.py
```

receipt c7 proves the old owned-0 failure. policy10.188s and static-python4.572s
passed in that run; other zero-duration static entries were unselected. kernel
failed after23.257s. no remaining reporter case or candidate green is claimed.
