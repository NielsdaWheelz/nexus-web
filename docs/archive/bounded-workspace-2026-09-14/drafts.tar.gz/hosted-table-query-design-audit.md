# hosted selected-cell query audit

status: source/design review only, 2026-09-14; no source edits, tests, wire or limits.

there is no complete accepted hosted query yet. explicit and group-only reads
can use ordinary immutable keysets. automatic association has a concrete event
reduction candidate below with a source-derived bound, but its maximum working
set is unqualified, and stateless continuation recomputes the selected query.
that does not meet the earlier no-prefix-rescan proposal. no existing client
lease can be relabelled as a server cursor owner to conceal this difference.

## current contract and actual owners

- `bounded-workspace-implementation.md:157-216` owns the ready publication
  fence, immutable selected generations, bounded query responses and retained
  backfill. no second readiness row or current pointer is permitted.
- `reader_publication_table_source.py:33-173` already emits source-order Table,
  Cell, ColumnGroup and deduplicated ExplicitHeader records; it does not emit
  automatic pairs. `reader_publication_tables.py:82-136` already owns effective
  header kind, empty-cell semantics and first-id explicit resolution.
- `reader_publication_artifacts.py:333,395,969` stages bounded metadata members
  and atomically installs generation projections. there is still no PostgreSQL
  table/cell projection. native `OfflineReadingTableIndex.kt:131-186` does have
  source tables, scalar cells, source ranges, explicit edges and column groups;
  incoming preparation is activated, but the query reducer is under `src/test`.
- the existing web capability is now `ReaderDocumentSource.overlays`, not the
  proposed `view` name. `DocumentReaderSession` owns charged response leases
  and cancellation; these leases hold client results, not server scratch across
  HTTP requests. full authored header/caption disclosure still needs addressed
  unit pages. navigation/pulse alone does not implement that disclosure.

source identity remains `(media, generation, fragment, table ordinal, row,
column)`. preserve metadata source ordinal separately: footer geometry can
move authored rows. full source ranges retain the start unit and exact end,
including opening-only units and later continued cells. a null metadata ref
means no excerpt metadata; required rows missing from a referenced publication
are a defect, not a new reader-visible preparation status.

## simple paths that already have a concrete query

principal lookup uses the exact original coordinate. an explicit attribute,
including an empty/invalid one, suppresses all automatic/group fallback. join
its published target edges to the same table, remove self/empty targets and
page by target ordinal. explicit td targets remain valid.

for automatic principal P=[r,re)×[c,ce), horizontal candidates satisfy
`column_start<c and row_start<re and row_end>r`; vertical candidates satisfy
`row_start<r and column_start<ce and column_end>c`. once an axis has an eligible
nonempty matching header, every intersecting cell kind participates, including
empty/data/none/wrong-scope cells. filtering those out changes opacity.

rowgroup and colgroup append phases query source ordinal directly, with the
native same-row-group/containing-column-group predicates and
`row_start<re and column_start<ce`. effective header kinds are exclusive, so
these two phases are disjoint from each other and the automatic row/column
results. no global seen set is needed for group paging. SQL keysets bound
returned rows, not physically scanned filtered rows; plans must measure that.

## why the native reduction cannot be copied as the hosted implementation

`OfflineReadingTableHeaders.kt:282-285` completes automatic reduction during
construction. `page():505` seeks private result rows; it does not resume a
stateless source query. its scratch includes source events, a coverage tree,
first-header state per exact span, latest data and last-unique partitions.

`header():477-492` walks every overlapping first-header/data state piece even
when that header already has a result. the shared-span fragmentation source
makes each farther header revisit the same alternating partition. the local
3×4→6×8 source characterization actually observed 35→108 candidate checks and
70→216 endpoint checks, receipt `7dcdc43092c83664`; no maximum was run. native
receipt `8403e63be75bbca7` reports 3.742s first page for 8,000 overlap rows and
96.7ms for 262,144 late irrelevant cells. neither qualifies a hosted maximum.

persisting every principal/header pair is rejected by output size, independent
of algorithm: m adjacent row or rowgroup headers followed by n data cells
produce m×n relationships from O(m+n) markup. the existing small characterization
has literal 12/48 pairs and the retained 100,000-element construction yields
2,499,750,006 pairs. this rejects eager pairs, not all possible shared indexes.

## concrete automatic candidate: active-column events and monotone opacity

this is an implementable draft algorithm for review, not a proved production
reducer. it reuses source geometry/classification and preserves native ray
semantics. let N be table source cells and W the maximum column span already
allowed by the wire, W≤1000. no new source cap is proposed.

horizontal pass:

1. form the two clipped x endpoints of each horizontal candidate. sweep x
   from the principal edge leftward, applying an entire coordinate batch before
   visiting the following nonempty band. maintain only active rectangles.
2. for that band, sort active rectangles' clipped row endpoints and sweep them
   with count+xor identity. emit only maximal intervals covered by exactly one
   cell; gaps and overlaps produce no visit. source-row coordinates are never
   expanded into slots. sort only active rectangles, never all N per band.
3. keep the native last-unique partition so repeated exposure of the same cell
   does not reset ray state. use a single range-assignment tree for D(y), the
   most recently encountered unique data coordinate. initialize D to infinity.
   all later assignments decrease the coordinate. compress y by source endpoints;
   this tree has O(N) nodes and supports range maximum and first threshold hit.
4. for each original header span g, retain ordered disjoint unassigned intervals
   U_g and assigned-but-not-proven-opaque intervals E_g carrying F_g, the first
   unique header coordinate. their domain is g intersected with the principal.
   initialize the principal's span at the principal edge when P is not data,
   including empty/wrong-scope header principals. absent pieces outside U/E are
   already opaque. this requires ordered interval operations; no SQL call per node.
5. before assigning a new header's first-coordinate gaps, find the least outer
   point where this cell can improve its result. U_g is immediately eligible.
   for an E_g piece with constant F, query max D over the intersected portion.
   if max D<F, remove that portion permanently: D can only decrease, so it can
   never become eligible again. otherwise the data tree finds its first y with
   D(y)≥F and the search stops. retain that cell's least `(outer,-inner)` key.
   no later inner coordinate can improve an equal outer point, so restrict
   later searches to outer positions strictly below its current best.
6. independently fill every intersected U_g gap with the current coordinate,
   even for empty/nonmatching headers. this preserves their opacity effect.
   do not walk already assigned eligible pieces merely to emit a duplicate.
   data visits update D; they do not eagerly touch every header group.

this replaces the native repeated fragmented walk with lazy permanent opacity
removal and least-point queries. the core equivalence is native's exact test:
F absent or F≤D means eligible; once F>D, that portion stays opaque. wrong kinds
and empty headers still establish F. input and result ordering remain distinct;
retain each cell's minimum key and select the requested page only after the
horizontal pass. vertical headers are a separate effective kind.

vertical pass can use the simpler independent outer-band reducer: the
principal itself spans at most W integer columns, hence at most W relevant
outer bands. sort its row events once; each band visits its intersecting cells
and retains the usual block/opaque state for that ray. memory is O(N), work
O(WN+N log N). append group phases afterward. no implied row traversal occurs.

## bound and its material price

for the horizontal pass, let A_i count active rectangles in a distinct x band.
all endpoints are integers and each cell has width at most W, so one cell can
cross at most W positive-width bands. therefore sum A_i≤WN. a sweep of A_i row
intervals creates at most 2A_i unique stripes: R≤2WN for the entire pass.
this bound does not depend on rowspan or implied table height.

last-unique interval replacement removes intervening old pieces; their visits
are amortized against previous insertions/splits. first-coordinate gaps are
assigned once; proven-opaque portions never reenter U/E. map boundaries arise
from source group extents and processed stripe/search endpoints. thus total
live interval state and amortized interval insert/delete work are O(N+R).
each data range maximum/threshold lookup costs O(log N); active endpoint sorting
costs sum O(A_i log A_i)≤O(WN log N). the rigorous reduction accounting is
O(N+R) interval operations and O(N+R) scalar state. with logarithmic balanced
interval maps, that would give O(WN log(WN)) total work. this is a conditional
CPU bound, not a guarantee of the repository's existing SortedDict: its actual
SortedList updates split/delete Python list blocks and document logarithmic
cost as approximate. silently treating those updates as worst-case logarithmic
would be another unsupported algorithm claim.

a concrete fixed-coordinate tree implementation can avoid balancing: use the
same compressed y endpoints for each group's lazily allocated uniform
unassigned/first-coordinate/opaque nodes. prune assigned subtrees while filling
unassigned gaps, and prune opaque nodes during least-point search. at most
O(log N) paths are introduced per processed interval; this gives the more
conservative O(N+R log N) node bound and O(WN log²N) work. it is implementable
with integer node arrays and the existing endpoint-tree idea, but is extra
algorithm code whose memory price has not earned production adoption. neither
representation has passed independent semantic/operation-count proof. the
immediate draft may characterize interval operations; it may not report the
conditional logarithmic bound as the current Python implementation's runtime.

THIS IS NOT A FIXED SMALL HEAP CLAIM. W=1000 permits a large multiplier. the
100,000-element EPUB entry bound cannot be borrowed for web or historical
schema-one sources. Python map/object overhead, DB fetch batches and temporary
sorting coexist with the scalar input. numeric metadata models/bodies must not
be retained for all cells. measure interval counts and actual process/cgroup
peak; do not price an interval node as just its serialized integers.

source storage is O(N+E+C), where E is authored explicit targets and C column
groups, plus source ranges. E is charged to actual authored metadata bytes;
it is not assumed O(N) for arbitrarily long explicit attributes. one selected
result has at most N distinct cells. hydrate only a page plus one lookahead,
caption and principal. retain bounded response bytes under existing
`index_bytes` and existing client query/unit leases. do not serialize all
header ranges and truncate afterward. a trial 24-row page is not a new limit.

## pagination is still the unresolved acceptance choice

a fixed signed `(phase,outer,inner_order,source_ordinal)` key can page *computed
first-occurrence keys*. it cannot skip earlier automatic reduction by itself.
a source header spanning multiple principal rows can have appeared on an
earlier ray; resuming at the next ray with only the last id duplicates earlier
headers. keeping one last id does not represent the emitted prefix.

with the candidate above, stateless paging recomputes the selected reduction,
then finds the least page-size-plus-one keys after the cursor. source reads are
O(N) per automatic request, plus bounded range joins; CPU is as above every
page. complete drain of H headers costs up to ceil(H/L) reductions. neither
native private results nor a browser lease supplies reusable server state.

recomputation is correct but fails the earlier no-prefix-rescan proposal unless
that price is explicitly accepted and qualified at every supported maximum,
including complete drain and repeated selection. no such acceptance/receipt
exists. alternatively, a source-sized immutable shared search representation
must prove direct first-occurrence membership/order. that algorithm is not yet
established. no impossibility theorem is claimed. a new per-query cache, opaque
source-sized cursor or quadratic pair table is not an approved substitute.

## narrow eventual patch sequence, conditional on that decision

1. one reviewed migration and `db/models.py`: four immutable relations under
   existing generation ownership: source tables/caption, source-order scalar
   cells/ranges, explicit target order, column groups. keys bind media/generation/
   fragment/table; cells additionally have original coordinate uniqueness and
   source ordinal. unit foreign keys preserve full source range provenance.
   no derived automatic pairs or second completion flag.
2. `reader_publication_artifacts.py` and `reader_publication_table_source.py`:
   stage these existing records alongside bounded metadata members and install
   atomically with the existing unit/search/target projections. copy them in the
   existing title-only generation path and delete them through current generation
   purge ownership. use bounded batches, not a corpus ORM list.
3. existing `tasks/prepare_reader_publication.py` and backfill/preflight owners:
   current code rejects noncurrent generations and returns on descriptor presence.
   extend the existing job identity and retained-member preparation contract;
   read digest-bound retained metadata, never current fragments. install only
   after exact retained descriptor and claim checks, without advancing current.
   verify all retained generations before enabling a required query projection.
4. one `services/reader_publication_table_headers.py` selected-query owner,
   schemas and the existing admitted reader publication router. fetch scalar
   source rows in bounded server-cursor batches; no per-step SQL or body reads.
   preserve the existing repeatable-read/auth lifetime. measure its held DB
   snapshot and worker CPU price. reuse `_query_response` and signed cursors.
5. existing web overlay/session query owner and bounded addressed-unit disclosure;
   parent/client owns this integration. hold only charged returned page/range
   units and retire them through existing leases.

before source activation: run the 22 current normative cases plus 40 native
literal-slot differential cases, explicit td/empty/wrong-scope/first-id,
malformed overlap, deferred footer order, multirow first-occurrence dedup,
phase-crossing pages and late caption ranges. add the fragmentation source as
an operation-count witness for eliminating repeated state scans, then real
maximum source geometry, process memory, SQL buffers, first/page/drain latency
and foreground overlap. do not run the old known-quadratic maximum reducer.
