# retry-after job-service composition boundary

status: source-reviewed; composed runtime proof unexecuted under the session's
physical-handset waiver. this is the remaining oi-204 scope, not a new gate.
origin: 2026-09-14; e094c28d product / b58c9ee5 proof draft and runtime peer review.

`OfflineReadingTransferJobService.kt:386–398` catches the actual capacity exception
and forwards its retryNotBefore through the current run/staging fence to the store.
that forwarding is correct by source review. the available host proofs exercise
real http parsing and real sqlite/store/scheduler eligibility separately. replacing
the forwarded instant with null inside this catch would evade them. do not claim
composed http → job-service catch → durable floor sensitivity from those receipts.

existing instrumentation seam:
`apps/android/app/src/androidTest/java/app/nexus/android/offline/reading/OfflineReadingSignedPhysicalPromotionTest.kt:42`
(`acquiresAllFormatsAndPersistsPendingProgress`) drives a pre-authenticated,
dedicated fixture account through the real production webview bridge.
`PromotionBrowser.enqueue` at line 439 sends the real enqueue command; the native
store schedules the actual user-initiated job. `awaitSnapshot` at line 651 observes
its public durable state. this is already the full job/direct-origin acquisition
path; it does not currently arrange a capacity refusal.

if the waived device scenario is later commissioned, use that existing acquisition
seam with an explicitly controlled refusal at its owned origin. observe the real
capacity outcome and exact persisted selected-account/generation/transfer floor,
retain the staged bytes, recreate the process, and establish that an os-delivered
early wake makes no request before the floor. after eligibility, observe the same
transfer resume. a temporary fault dropping only the instant in the real catch
must fail the durable-floor assertion. actual eventual os delivery remains a
different assertion from the existing host checkpoint's reschedule=true result.

no new peer, controller capability, platform fake, product accessor, constructor
seam, job class or scheduler abstraction is proposed or implemented. no tests ran.
root retains the required available host origin/store/migration cases and the four
auxiliary parsing/eligibility/idle-retry/migration faults. the job-service runtime
limit remains explicit in oi-204 and current progress documentation until actual
composed evidence exists; the handset waiver does not turn it into a passing proof.
