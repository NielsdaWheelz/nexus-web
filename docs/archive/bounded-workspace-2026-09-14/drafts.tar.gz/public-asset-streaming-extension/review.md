# public asset streaming and public storage lifetime draft

status: draft only; no main edits or executed checks.

## composition

`product.patch` applies after the reviewed public pdf patch 8349ebf6 and shared
storage patch 21faec41. it changes only the public asset result and route: the
existing token, source-revision handle, epub kind, allowed content type and
25 mib persisted-size checks remain. `chunks()` lazily delegates to the existing
checked generator, preserving masked storage errors and explicit yield-from
close propagation. the route uses the existing image pool and storage response;
public bootstrap and other public endpoints keep their current membership.

initial missing/short corruption can still return masked 404 before headers.
late source errors interrupt the already-started representation. the existing
public response policy still supplies every security/no-store header, including
capacity refusal before token validation. no private path/id or alternate
storage-error response is exposed. no new object digest authority is claimed.

one get, 64 kib source chunks, up to two source chunks for full-read lookahead;
actual sdk/framework allocations, accepted 25 mib image overlap and throughput
remain unqualified. no image decode is performed by these transport proofs. the
existing public projection still reads all sections while validating shape and
computing handle revision; the separate draft ticket records that independent
cost. streaming this body cannot establish a bounded complete public request.

## exact proof owners

`proof.patch` extends runtime's reviewed public proof 34fc2554. its existing raw
caller cancellation case and original token/PDF authority matrix remain. shared
new support contains one small postgres/minio epub source fixture, real public
navigation/section handle discovery, and one local actual-sdk lifetime observer.
that observer does not replace a route, service, response, admission owner or
storage client. it shares the repeated ASGI scheduling/drain mechanics only.

- `test_public_asset_stream_preserves_bytes_and_masks_private_sources`: public
  navigation emits the actual asset handle; cross-token, absent/invalid token,
  invalid handle, unsupported type/size and revoked token open no source get.
  successful transfer reconstructs the exact selected object and begins after
  two 64 kib reads, before complete materialization. real missing and initial
  short minio objects remain masked 404; real later excess yields an incomplete
  exact source prefix and no terminal success body. the installed started-
  response RuntimeError must have the direct masked NotFoundError cause and
  exact excess-size StorageError as that cause's preserved cause. Starlette's
  ASGI 2.3 collapsing task group promotes the original context explicitly; no
  generic exception traversal or alternative failure is accepted. public
  headers and one physical close remain observed.
- `test_public_asset_retains_image_capacity_through_sdk_read_and_close`: actual
  public asset, image pool, third sdk read, sdk close, deadline/disconnect and
  later exact body; two saved ownership observations precede any later timeout.
- `test_public_file_retains_transfer_capacity_through_sdk_read_and_close`: same
  real peer boundary with separate PDF owner and full/ranged parameters; exact
  byte interval, length, 200/206, content-range and public headers remain in the
  owner. both source forms retain their permit through held read and close.

production ASGI 2.3 is explicit. only external sdk read/close is held; actual
minio and authorization run. the helper preserves both phase observations,
release/drain cleanup, one GET and exact body identity. later complete reads
must work; busy work returns existing 503/retry-after while bootstrap succeeds.

## sensitivity and limits

the new source/privacy owner imports only pre-existing product interfaces and
can observe the old eager body through its named first-transfer assertion.
removing the asset route's image admission is the minimal candidate-only pool
fault; its ordinary third-read/close owner must observe the live second read
being admitted before any later cleanup timeout. the reviewed shared omitted
response-close and EOF faults remain separate owners, never committed product
mutations. no green or sensitivity claim is made before actual execution.

new helper imports affect the existing public proof source digest; no manifest
or pin has been edited. root owns exact review and registration before replay.
