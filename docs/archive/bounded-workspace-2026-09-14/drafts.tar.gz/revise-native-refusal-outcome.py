from pathlib import Path
import json,difflib,hashlib,shutil
root=Path('/home/niels/src/personal/nexus-web-bounded-native-proof');out=Path('/tmp/native-conversion-refusal-draft')
old=Path('/tmp/native-conversion-refusal-draft-v2')
if not old.exists():shutil.copytree(out,old)
p=out/'inventory.json';d=json.loads(p.read_text())
def edit(name,fn):
 src=root/name;f=out/name;s=f.read_text();t=fn(s);assert s!=t,name;f.write_text(t);d['files'][name]['draft_sha256']=hashlib.sha256(f.read_bytes()).hexdigest();(out/(src.name+'.diff')).write_text(''.join(difflib.unified_diff(src.read_text().splitlines(True),t.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
base='apps/android/app/src/main/java/app/nexus/android/'
def store(s):
 s=s.replace('''internal sealed interface OfflineReadingReconciliationOutcome {
    val snapshot: ReadingStoreSnapshot

    data class Ready(override val snapshot: ReadingStoreSnapshot)''','''internal sealed interface OfflineReadingReconciliationOutcome {
    data class Ready(val snapshot: ReadingStoreSnapshot)''',1).replace('data class Deferred(override val snapshot: ReadingStoreSnapshot)','data class Deferred(val snapshot: ReadingStoreSnapshot)',1).replace('data class Failed(override val snapshot: ReadingStoreSnapshot, val cause: Exception)','data class Failed(val cause: Exception)',1)
 a='''            notifySnapshotChanged()
            val snapshot = snapshot()
            val outcome = if (failure != null) {
                OfflineReadingReconciliationOutcome.Failed(snapshot, failure)
            } else if (synchronized(this) {
                    reconciliationComplete &&
                        !bindingLocked &&
                        readAccountTransition() == null
                }
            ) {
                OfflineReadingReconciliationOutcome.Ready(snapshot)
            } else {
                OfflineReadingReconciliationOutcome.Deferred(snapshot)
            }
            callbacks.forEach { callback -> callback(outcome) }'''
 b='''            val outcome = if (failure != null) {
                // Reporting a failed store must not require another successful
                // SQLite read merely to manufacture a snapshot.
                OfflineReadingReconciliationOutcome.Failed(failure)
            } else try {
                notifySnapshotChanged()
                val snapshot = snapshot()
                if (synchronized(this) {
                        reconciliationComplete && !bindingLocked && readAccountTransition() == null
                    }
                ) OfflineReadingReconciliationOutcome.Ready(snapshot)
                else OfflineReadingReconciliationOutcome.Deferred(snapshot)
            } catch (error: Exception) {
                synchronized(this) {
                    if (epoch == reconciliationEpoch) {
                        bindingLocked = true
                        reconciliationComplete = false
                        verifiedPackages.clear()
                    }
                }
                android.util.Log.e("OfflineReading", "reconciliation completion failed", error)
                OfflineReadingReconciliationOutcome.Failed(error)
            }
            callbacks.forEach { callback -> callback(outcome) }'''
 assert s.count(a)==1;s=s.replace(a,b,1)
 return s
edit(base+'offline/reading/OfflineReadingStore.kt',store)
def web(s):
 a='''                if (outcome is OfflineReadingReconciliationOutcome.Failed || !hostedReconciledSnapshotAccepted(outcome.snapshot, accountId)) {'''
 b='''                val snapshot = when (outcome) {
                    is OfflineReadingReconciliationOutcome.Ready -> outcome.snapshot
                    is OfflineReadingReconciliationOutcome.Deferred -> outcome.snapshot
                    is OfflineReadingReconciliationOutcome.Failed -> {
                        failHostedConnect(message, requestId, "Failed")
                        return@reconcileAsync
                    }
                }
                if (!hostedReconciledSnapshotAccepted(snapshot, accountId)) {'''
 assert s.count(a)==1;s=s.replace(a,b,1).replace('reply(message.replyProxy, requestId, connected(outcome.snapshot))','reply(message.replyProxy, requestId, connected(snapshot))',1)
 s=s.replace('''                    if (outcome is OfflineReadingReconciliationOutcome.Failed) {
                        failConnect(message, requestId, "Failed")
                    } else finishOfflineConnect(message, requestId, outcome.snapshot)''','''                    when (outcome) {
                        is OfflineReadingReconciliationOutcome.Ready -> finishOfflineConnect(message, requestId, outcome.snapshot)
                        is OfflineReadingReconciliationOutcome.Deferred -> finishOfflineConnect(message, requestId, outcome.snapshot)
                        is OfflineReadingReconciliationOutcome.Failed -> failConnect(message, requestId, "Failed")
                    }''',1)
 return s
edit(base+'offline/readingweb/OfflineReadingWebCapability.kt',web)
def lifecycle(s):
 return s.replace('reopened.reconcileAsync { unlockedSnapshot = it.snapshot }','''reopened.reconcileAsync { outcome ->
            unlockedSnapshot = when (outcome) {
                is OfflineReadingReconciliationOutcome.Ready -> outcome.snapshot
                is OfflineReadingReconciliationOutcome.Deferred -> outcome.snapshot
                is OfflineReadingReconciliationOutcome.Failed -> throw AssertionError("unlock reconciliation failed", outcome.cause)
            }
        }''',1)
edit('apps/android/app/src/test/java/app/nexus/android/offline/reading/OfflineReadingStoreLifecycleTest.kt',lifecycle)
def activation(s):
 s=s.replace('import java.util.concurrent.Executor\n','import java.util.concurrent.Executor\nimport java.util.concurrent.Executors\nimport java.util.concurrent.CountDownLatch\nimport java.util.concurrent.TimeUnit\n',1)
 s=s.replace('''            assertThrows(IllegalArgumentException::class.java) {
                OfflineReadingStore(fixture.context, database = fixture.database, seal = fixture.seal,
                    rootDirectory = fixture.root, durability = HostReadingFilesystemDurability,
                    integrityExecutor = Executor(Runnable::run))
            }
            assertEquals(original, row(fixture.database.readableDatabase, "offline_reader_packages"))''','''            val executor = Executors.newSingleThreadExecutor()
            try {
                val completed = CountDownLatch(1)
                var result: OfflineReadingReconciliationOutcome? = null
                val store = OfflineReadingStore(fixture.context, database = fixture.database, seal = fixture.seal,
                    rootDirectory = fixture.root, durability = HostReadingFilesystemDurability,
                    integrityExecutor = executor, reconcileOnInit = false)
                store.reconcileAsync { result = it; completed.countDown() }
                assertTrue("converter defect did not complete its existing async owner", completed.await(10, TimeUnit.SECONDS))
                val failed = result as? OfflineReadingReconciliationOutcome.Failed
                assertTrue("converter defect was relabeled as readiness or resource deferral", failed != null)
                assertTrue("mapping failure lost its original cause", failed!!.cause is IllegalArgumentException)
                assertThrows(IllegalStateException::class.java) { store.open(fixture.media) }
            } finally { executor.shutdownNow() }
            assertEquals(original, row(fixture.database.readableDatabase, "offline_reader_packages"))''',1)
 return s
edit('apps/android/app/src/test/java/app/nexus/android/offline/reading/OfflineReadingLegacyActivationTest.kt',activation)
p.write_text(json.dumps(d,indent=2)+'\n')
print(d['files'][base+'offline/reading/OfflineReadingStore.kt']['draft_sha256'])
