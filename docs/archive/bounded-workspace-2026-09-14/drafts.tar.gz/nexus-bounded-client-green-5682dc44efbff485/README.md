# payload retirement integration

status: client raw-payload owner green; main reconciliation draft requires review and replay.
origin: client proof worktree, 2026-09-14.

`5682dc44efbff485` is a complete ordinary green for
`ReaderUnitPayloadRetirement.browser.test.tsx`. the actual pre-fix red is
`8802ec32ae19c7cc`: “released reader handles retained a source after its payload
charge retired”. exact receipts are under `receipts/`.

this proof crosses the real resource cache, hosted source decoder and two reader
sessions. one lease may retire and the cache may clear while the other reader
keeps the same source and charge. the final lease returns exact prior occupancy;
the raw source then collects while the retired result/lease wrappers remain.
it does not exercise the body/window getter propagation, repeated slice cost,
maximum composition, or decoded-source retention by every existing consumer.

`inventory.json` contains exact source hashes. `client-before/` is reconstructed
by inversely applying the two exact reviewed patches to the held client source.
these are patch preimage hashes, not a claim that the old git commit alone
attests the dirty source at test execution. `client-after/` retains the exact
current source. the body/window getter deltas are reviewed required propagation;
the full body replay after those deltas is still pending.

`reviewed-patches/reader-unit-payload-retirement-review.patch` is the original
approved source delta. `publication-cache-current-borrow-proof.patch` captures
its existing sharing promise before release, preserving the sharing oracle.
`reader-unit-borrow-contract.patch` is approved documentation but was NOT applied
in the held client source; an earlier work-in-progress inventory mislabeled it.

`main-observed/` is a double-read-verified snapshot of only these six paths.
`main-to-client-review-only.diff` exposes incoming differences and MUST NOT be
applied: main has the reviewer's tagged Unit/Capacity settlement, named factors,
separate content/query limits, and unrelated source/API changes.

`main-reconciliation-draft.patch` preserves those main changes and applies only
the clearable payload handles, getter propagation, documentation, and sharing
proof adaptation. the new raw-payload proof uses main's existing tagged Capacity
discrimination; its ownership/collection assertions are unchanged. this draft
has not run and must not inherit the old client's receipt as combined-source
evidence. no main files were written. no share/pdf candidate is included.

other complete owners observed inside commands that failed elsewhere:

- `37d5484723bad8d2`: the one-case actual body pending Ask DOM retirement owner,
  the three-case acknowledgment outcome owner, four original navigation cases,
  four retained-selection cases, and two native shelf cases all pass. the
  command fails later at the apparatus fixture retirement precondition. these
  receipts predate the current payload getter delta; they are not a current
  enclosing green.
- `3ed208243dd68fb1`: the complete three-case text selection owner passes,
  including ordinary/duplicate acknowledgment and same-coordinate replacement.
  the command fails later in Share. it supplies no Share acceptance.

those older source slices require their own selective reconciliation and final
coupled replay; this bundle deliberately contains only the current payload
slice and explicitly necessary consumer/proof adaptations. no coherent owner
pin or fault metadata is changed.

root integrated the reviewed slice and the hosted-source proof call correction.
combined focused replay `e7dfd613c31bfce0` at `86c0986` passes all five selected
cache/session/window/body/pdf owners and selected web static. receipt retained.
this supersedes the pending combined-replay note above; maximum composition and
canonical sensitivity remain separate.
