# generation corpus dependency identity review

status: reviewed draft; not applied or executed.
origin: 2026-09-14, policy-blocked controller run 6dded3c49238634a at dd21213.

## minimal correction

`corpus.patch` changes only the provider-runtime revision in the two existing
corpora, from 8fde23ac56571a63c65cfcff55c73a0976f83eb4 to
9abaf6b7a1f907fcf1bdbfa33dd7b343e42ffbdb. json comparison after restoring
that one value proves every other field is identical. no corpus version,
rubric, source case, policy fingerprint, authority revision, plan revision,
model, effort, refusal baseline, mutation limit, or hosted-call budget changes.

## source evidence

pyproject, uv.lock and installed direct_url.json agree on provider-runtime9ab,
llm-tools9e6d155, and llm-agent-kernelfd2d71. the sdk remains0.144.4 and mcp2.1.0.
the local provider repository contains both exact revisions. their entire diff
is one commit and one file: runtime.py defers importing and constructing each
provider-http execution adapter until its existing dispatch boundary; the
embedding import also moves to its call boundary. injected engine selection,
credential/intent checks, retries, and sdk client ownership remain unchanged.

all agent_runtime and tool_adapter source is unchanged between these revisions.
source inventory additionally binds the installed bytes of model_catalog.py,
agent_runtime/runtime.py, types.py, policy.py, and tool_adapter.py to the new
commit. the exact agent model contract remains
provider-runtime.agent-model-catalog.v1. every reviewed generation corpus
selection uses CodexPersonal. no change in these corpora is justified by the
provider-http loading change beyond declaring the actual consumer revision.
this is static compatibility evidence, not execution or live quality evidence.

current generation policy, profile definitions and authority declarations retain
the original corpus facts. the product composition diff since corpus creation
adds a non-dispatching projection entrypoint and extracts the existing common
composition; the product entrypoint still requires available nexus bindings,
then executes the same catalog/profile/plan construction. freeze encoding is
unchanged. its exact current plan hashes remain independent replay assertions;
they must not be recomputed merely to pass.

## metadata and pending proof

neither corpus is a checksum entry in testdata/manifest.json. existing source
routing already names both. no registry, fault patch, expected fingerprint, or
coherent owner digest needs changing for these two json values. the canonical
llm-generation-tool-scope-bypass fault remains unchanged, including DID NOT
RAISE and owner65e3d3fa813679344a2455582f98009b526e4f7791f3221656f3ca62d96b6e4c.

once the independently owned raw-sql policy blockers are fixed, replay:

```sh
./scripts/test changed \
  pytest:python/tests/evals/test_generation_plan_eval.py::test_reviewed_generation_plan_corpus_replays_the_shipped_policy_without_a_live_model \
  pytest:python/tests/evals/test_tool_safety_eval.py::test_generation_tool_plans_refuse_untrusted_escalation \
  pytest:python/tests/llm_tools_contract/test_pinned_llm_tools.py::test_exact_pins_round_trip_one_canonical_native_tool
./scripts/test prove \
  --proof pytest:python/tests/evals/test_tool_safety_eval.py::test_generation_tool_plans_refuse_untrusted_escalation \
  --against fault:llm-generation-tool-scope-bypass
```

the first owner checks the complete14-operation policy and four tool plans; the
second checks actual server refusal and zero durable/domain mutations for both
poisoned cases; the third binds installed dependency identity to actual canonical
tool lowering. sensitivity must still observe the named bypass failure and
corrected candidate. any new actual plan mismatch needs its own semantic review.
keep the existing provider-pin ticket open until that evidence exists. neither
the blocked controller run nor this pin correction qualifies runtime behavior.
