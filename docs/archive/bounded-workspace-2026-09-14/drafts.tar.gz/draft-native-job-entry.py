from pathlib import Path
import difflib,hashlib,json
base=Path('/tmp/native-conversion-refusal-draft')
out=Path('/tmp/native-reconcile-job-entry-draft');out.mkdir(exist_ok=True)
p='apps/android/app/src/main/java/app/nexus/android/offline/reading/OfflineReadingStore.kt'
s=(base/p).read_text();assert hashlib.sha256(s.encode()).hexdigest()=='c2d5cb81c83ebcb42d65cc4063dc7071f3d3be3dbc11415dea16089286fddaa6'
a=s.index('        val ready = synchronized(this) {',s.index('    internal fun reconcileForJob('))
b=s.index('\n    /**',a)
replacement='''        synchronized(this) {
            if (reconciliationRunning) {
                reconciliationClaimedByJob = true
                reconciliationCallbacks += callback
                return
            }
        }
        integrityExecutor.execute {
            val outcome = try {
                val ready = synchronized(this) {
                    // A run may have been claimed after this inspection was queued.
                    if (reconciliationRunning) {
                        reconciliationClaimedByJob = true
                        reconciliationCallbacks += callback
                        return@execute
                    }
                    if (reconciliationComplete && !bindingLocked && readAccountTransition() == null) {
                        OfflineReadingReconciliationOutcome.Ready(snapshot())
                    } else {
                        reconciliationClaimedByJob = true
                        null
                    }
                }
                if (ready == null) {
                    requestReconciliation(callback)
                    return@execute
                }
                ready
            } catch (error: Exception) {
                synchronized(this) {
                    bindingLocked = true
                    reconciliationComplete = false
                    verifiedPackages.clear()
                }
                android.util.Log.e("OfflineReading", "job reconciliation inspection failed", error)
                OfflineReadingReconciliationOutcome.Failed(error)
            }
            try {
                callback(outcome)
            } catch (error: Exception) {
                android.util.Log.e("OfflineReading", "reconciliation callback failed", error)
            }
        }
    }
'''
changes={p:(s,s[:a]+replacement+s[b:])}
p='apps/android/app/src/test/java/app/nexus/android/offline/reading/OfflineReadingLegacyActivationTest.kt'
s=(base/p).read_text();assert hashlib.sha256(s.encode()).hexdigest()=='6e48068331142a6a577e58e98cad1d0b518efceb02db26835a35114c303322e4'
a=s.index('    private fun row(database: SQLiteDatabase')
proof='''    @Test
    fun `ready job inspection reports unavailable store then recovers exact installed state`() {
        val fixture = InstalledLegacyReadingFixture(temporary.newFolder())
        val executor = Executors.newSingleThreadExecutor()
        val databaseFile = fixture.context.getDatabasePath(fixture.databaseName)
        try {
            val store = OfflineReadingStore(fixture.context, database = fixture.database, seal = fixture.seal,
                rootDirectory = fixture.root, durability = HostReadingFilesystemDurability,
                integrityExecutor = executor, reconcileOnInit = false)
            val prepared = CountDownLatch(1)
            var preparation: OfflineReadingReconciliationOutcome? = null
            store.reconcileAsync { preparation = it; prepared.countDown() }
            assertTrue("initial real package preparation did not complete", prepared.await(10, TimeUnit.SECONDS))
            assertTrue(preparation is OfflineReadingReconciliationOutcome.Ready)
            val installed = row(fixture.database.readableDatabase, "offline_reader_packages")
            val pending = row(fixture.database.readableDatabase, "offline_reader_progress_pending")
            val baseline = row(fixture.database.readableDatabase, "offline_reader_progress_baselines")
            val installedDirectory = File(fixture.root, "${fixture.binding}/${installed.getValue("id")}")
            val manifest = File(installedDirectory, "manifest.json").readBytes()
            fixture.database.close()
            assertTrue(databaseFile.setReadable(false, false))
            assertFalse("controlled prepared store remains readable", databaseFile.canRead())
            val inspected = CountDownLatch(1)
            var inspection: OfflineReadingReconciliationOutcome? = null
            var synchronousFailure: Exception? = null
            try {
                store.reconcileForJob { inspection = it; inspected.countDown() }
            } catch (error: Exception) {
                synchronousFailure = error
            }
            assertNull("ready job inspection escaped before its owned executor boundary", synchronousFailure)
            assertTrue("ready job inspection stranded its completion", inspected.await(10, TimeUnit.SECONDS))
            assertTrue("unavailable prepared store became a ready job", inspection is OfflineReadingReconciliationOutcome.Failed)
            assertTrue("job inspection lost the original SQLite cause",
                (inspection as OfflineReadingReconciliationOutcome.Failed).cause is android.database.sqlite.SQLiteException)
            assertTrue(manifest.contentEquals(File(installedDirectory, "manifest.json").readBytes()))
            assertTrue(databaseFile.setReadable(true, true))
            assertTrue(databaseFile.canRead())
            assertEquals(installed, row(fixture.database.readableDatabase, "offline_reader_packages"))
            assertThrows(IllegalStateException::class.java) { store.open(fixture.media) }
            val recovered = CountDownLatch(1)
            var recovery: OfflineReadingReconciliationOutcome? = null
            store.reconcileForJob { recovery = it; recovered.countDown() }
            assertTrue("recovered job inspection stranded reconciliation", recovered.await(10, TimeUnit.SECONDS))
            assertTrue("recovered job did not regain prepared readiness", recovery is OfflineReadingReconciliationOutcome.Ready)
            assertTrue((recovery as OfflineReadingReconciliationOutcome.Ready).snapshot.items.single().availability is OfflineReadingAvailability.Ready)
            assertEquals(installed, row(fixture.database.readableDatabase, "offline_reader_packages"))
            assertEquals(pending, row(fixture.database.readableDatabase, "offline_reader_progress_pending"))
            assertEquals(baseline, row(fixture.database.readableDatabase, "offline_reader_progress_baselines"))
        } finally {
            assertTrue(databaseFile.setReadable(true, true))
            executor.shutdownNow()
            assertTrue(executor.awaitTermination(10, TimeUnit.SECONDS))
            fixture.close()
        }
    }

'''
changes[p]=(s,s[:a]+proof+s[a:])
inv={}
for p,(before,after) in changes.items():
 dest=out/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(after)
 diff='diff --git a/'+p+' b/'+p+'\n'+''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 (out/(Path(p).name+'.diff')).write_text(diff)
 inv[p]={'base_sha256':hashlib.sha256(before.encode()).hexdigest(),'draft_sha256':hashlib.sha256(after.encode()).hexdigest()}
(out/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
print(json.dumps(inv,indent=2))
