from pathlib import Path
import hashlib,json,difflib
root=Path('/home/niels/src/personal/nexus-web-bounded-native-proof');out=Path('/tmp/native-conversion-refusal-draft');p=out/'inventory.json';d=json.loads(p.read_text())
def edit(name,fn):
 src=root/name;s=src.read_text();t=fn(s);assert s!=t;dst=out/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(t);d['files'][name]={'base_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'draft_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()};(out/(src.name+'.diff')).write_text(''.join(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
base='apps/android/app/src/test/java/app/nexus/android/offline/reading/'
edit(base+'OfflineReadingLegacyActivationTest.kt',lambda s:s.replace('    private fun row(database:',Path('/tmp/native-refusal-proof-cases.kt').read_text()+'    private fun row(database:',1))
edit(base+'OfflineReadingDatabaseTest.kt',lambda s:s.replace('                db.execSQL("ALTER TABLE offline_reader_packages DROP COLUMN table_index_sha256")','                db.execSQL("ALTER TABLE offline_reader_packages DROP COLUMN table_index_sha256")\n                db.execSQL("ALTER TABLE offline_reader_packages DROP COLUMN conversion_refusal")',1).replace('key != "table_index_sha256"','key != "table_index_sha256" && key != "conversion_refusal"',1).replace('                db.rawQuery("PRAGMA table_info','                assertNull("upgrade invented a converter refusal", row(db, "offline_reader_packages").getValue("conversion_refusal"))\n                db.rawQuery("PRAGMA table_info',1))
edit(base+'OfflineReadingStoreLifecycleTest.kt',lambda s:s.replace('''"conversion below the preflight estimate must stay locally retryable",
                OfflineReadingAvailability.UpgradeRequired,''','''"conversion below the preflight estimate must stay locally retryable",
                OfflineReadingAvailability.UpgradeBlockedByStorage,''',1))
p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d['files'],indent=2))
