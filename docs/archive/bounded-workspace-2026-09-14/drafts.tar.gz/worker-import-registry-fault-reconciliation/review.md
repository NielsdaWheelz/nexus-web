# worker fault allowed production owner

status: draft only; no main edit, active injected source, or tests.
origin: policy failure cf021cc79090a962 at b6928c60.

my previous entrypoint placement was wrong: apps/worker/main.py is not in
_PRODUCT_SOURCE_ROOTS or _PRODUCT_SOURCE_FILES, and is not a listed test-runtime
product exception. git apply --check could not establish policy admissibility.
keep that allowlist unchanged.

move the same one-line `from provider_runtime.runtime import ProviderRuntime`
fault to python/nexus/jobs/registry.py's module imports. apps/worker/main.py:41
imports this actual production metadata owner directly. its normal code imports
handler implementations only inside resolve_job_handler. the fault therefore
makes idle worker metadata eagerly load execution code, the same counterfactual
as the original profile-module mutation. it is not a new loader or product fix.

policy.py:136 permits .py sources under python/nexus; registry.py matches this
root, is not a test/spec basename, and needs no policy exception. the unchanged
canonical child imports apps.worker.main and explicitly searches sys.modules
for provider_runtime.runtime (test_worker_runtime_health.py:63–98). even with
provider9ab's lazy vendor engines, this exact root must appear under the fault.
the existing named parent assertion still owns the red; it has not executed.

reviewed all changed fault paths since dd21213, not merely their patch context:
the current worker candidate is allowed; the deleted browse auxiliary's actual
brave.py target is allowed but remains unregistered under /tmp; the deleted
bounded-dossier policy.py target is not allowed and is not restored. no other
active fault source changed in that batch. inventory records these dispositions.

main.patch changes exactly the worker fault bytes and its one manifest sha.
proof, expected fingerprint, owner registration and policy bytes stay unchanged.
read-only applicability checks pass both the fault and its integration patch;
actual paved policy/canonical execution remains pending.
