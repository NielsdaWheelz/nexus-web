# existing runner ports fixture reference

status: draft only; no main edits or tests.
origin: static-python F821 in local receipt38cef9311cf1e910 at a25ab33c.

line4786 belongs to test_exact_deterministic_llm_eval_does_not_start_an_unowned_external_protocol,
not the release-image proof at1465. the proof was added by1140eb2545 against the
compatibility tree's _ReadyExternalPorts. the retained generation hard cut
0977dfe3e1 had renamed/extended that shared fixture to _ReadyProtocolPorts,
including the exact provider-peer boundary. the merge restored the new helper
while retaining this one old reference.

replace only that subclass name with the existing _ReadyProtocolPorts. the
local start_python_process override still records every requested role before
calling super. the unchanged proof still requires no process roles, a passing
routing result, and exactly one cleanup. accepting either external/provider role
in the common helper cannot hide a started listener: either would populate the
same independently asserted empty list. no helper, fake behavior, expected
result, cleanup, package/image ownership, product source or registry changes.

the separate release-image proof is untouched: it still binds the actual owned
candidate image instead of ambient input, exact build/test commands and image
removal. no whole-file source pin refresh is justified by this correction alone.

read-only patch applicability passes. after review, replay through the existing
paved owner and static-python gate; no result is claimed here:

```sh
./scripts/test changed pytest:python/tests/kernel/nexus_test_control/test_runner.py::test_exact_deterministic_llm_eval_does_not_start_an_unowned_external_protocol
```
