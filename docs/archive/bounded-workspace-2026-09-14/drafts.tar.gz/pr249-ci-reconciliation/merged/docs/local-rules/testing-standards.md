# Nexus Testing Standards

This is the permanent, authoritative, repository-local testing contract for
Nexus. It applies to every new or modified test, fixture, helper, test
dependency, CI gate, evaluation, synthetic, and release check.

This document is intentionally Nexus-specific and self-contained. It belongs in
`docs/local-rules/`; it MUST NOT be moved into or replaced by the shared
`docs/rules/` subtree. Shared testing doctrine may complement this document, but
this document owns Nexus commands, fixtures, runtimes, risk priorities, current
exceptions, and migration policy. If generic doctrine conflicts with a
Nexus-specific rule here, this document controls Nexus.

Existing tests are legacy evidence, not precedent. Existing harness behavior is
authoritative only where this document explicitly records it as the current
executable contract.

**MUST** and **MUST NOT** are requirements. **SHOULD** and **SHOULD NOT** require
a concrete reason to override.

## 1. Definitions

- A **proof** is executable or static evidence for a named risk, invariant,
  regression, or production contract.
- A **scenario** is one executable proof of one coherent risk or invariant,
  regardless of how many assertions, parameters, or generated examples it has.
- An **oracle** is the independent source that decides what correct behavior is.
- **Sensitivity** means the proof has been observed failing when the claimed
  fault is present.
- A **kernel proof** exercises pure or tightly bounded semantic behavior.
- A **service/component proof** exercises multiple real owned collaborators
  through a public boundary. It may run in one process.
- A **journey** exercises production-shaped wiring across browser, process, auth,
  database, worker, or storage boundaries.
- A **fake** is an owned working implementation of an external boundary.
- A **stub** supplies a narrow predetermined response.
- A **mock** verifies interactions such as calls, arguments, count, or order.
- **Priority-risk proof** protects data integrity, privacy/auth, money,
  destructive effects, provenance, or durable-work correctness.
- **Real-stack** means the applicable production implementation runs with real
  Nexus processes and real local infrastructure. It does not imply hosted
  providers, deployment, a physical device, or production.

## 2. Objective and philosophy

Optimize for confidence per developer minute, machine GB-minute, and maintenance
hour. Never optimize for test count, coverage percentage, snapshot volume,
assertion count, or the appearance of exhaustiveness.

For each material failure mode, use the smallest deterministic proof whose
boundary and oracle can genuinely observe it. Add broader proof only where a
narrower proof cannot preserve the database, browser, process, provider,
deployment, or production behavior at risk.

Nexus is outcome-heavy, not E2E-heavy:

1. comprehensive static and preventive proof;
2. a small kernel of pure and property proof;
3. a dominant middle of service and browser-component proof using real Nexus
   code, real PostgreSQL, and real Chromium semantics;
4. very few complete journeys;
5. scheduled provider, device, property/random-order audit, and semantic
   evaluation;
6. explicit deployment and production verification.

“Dominant middle” describes confidence and maintenance investment, not a
test-count quota. Pyramid, trophy, and honeycomb diagrams are heuristics, not
required ratios.

Prefer eliminating failure modes architecturally:

- types and exhaustive state handling;
- generated and validated boundary schemas;
- explicit state machines;
- idempotent operations;
- transactional ownership and durable checkpoints;
- narrow provider boundaries;
- reconciliation and observable invariants;
- fail-closed local-resource ownership and cleanup;
- deploy rollback owned by the deployment system.

Test what remains uncertain.

## 3. Agent-authored proof and falsifiability

Tests are part of the reward function for coding agents. A suite that can be made
green by weakening assertions, mocking the implementation, skipping work,
sleeping longer, copying current output, or deleting inconvenient proof rewards
incorrect behavior.

An agent MUST optimize for the product contract, not for a green command.

### Oracle independence

- Expected behavior MUST come from product requirements, architecture,
  user-visible behavior, independently reviewed fixtures, mathematical
  properties, protocol specifications, or known production facts.
- Do not derive expected output by running the current implementation and
  snapshotting or copying what it returns.
- The same implementation path MUST NOT serve as both producer and oracle.
- Generated-content evaluation MUST use a stored independently reviewed
  baseline or rubric, not self-comparison.
- When the same agent writes implementation and proof, sensitivity evidence is
  required at the level defined below.

### Sensitivity requirements

| Change | Required evidence |
|---|---|
| Defect fix | The regression proof fails against the unfixed defect, reverted fix, or equivalent injected fault, then passes with the fix |
| Replacement for priority-risk legacy proof | The replacement fails under a representative known or injected fault before the legacy proof may be deleted or made non-blocking |
| New critical behavior | Observe red before implementation when practical; otherwise demonstrate failure under a controlled wrong result or fault |
| Ordinary new behavior | Use an independent oracle and demonstrate sensitivity when the proof could plausibly pass vacuously |
| Critical pure kernel | Targeted changed-code mutation MAY audit oracle strength |

A test passing on its first authored run is not evidence of sensitivity.

Sensitivity evidence MAY be a captured pre-fix run, a run against the parent
revision, a temporary local fault that is removed before commit, a deterministic
fault injector, or a targeted mutant. Do not commit deliberate production
defects merely to preserve the demonstration.

PR sensitivity MUST NOT dispatch paid hosted providers or require a physical
device. The local executor/parser proof is sensitivity-gated in PR; the hosted
or device boundary runs only in its named protected capability.

Sensitivity resolves one owner deterministically, so the registry admits at most
one priority node per proof owner path, and `testdata/faults/manifest.json`
admits at most one fault per proof. A fault MUST name the registered canonical
node of its owner; a fault naming any other node of the same file can never be
resolved and is dead evidence. `policy` rejects all three shapes
(`proof-canonical-node`, `fault-proof-owner`, `fault-canonical-proof`) instead
of letting the workflow abort without a verdict.

For a changed proof file, PR uses BASE when the whole file owns the proof or the
selected exact module-level Python test plus its imports and non-test module
support differs from base. Sibling tests are separate owners: changing only a
sibling retains the selected owner's declared FAULT.

One exact module-level Python proof or canonical whole-file Vitest/Gradle/Node proof MAY opt into
`changed_owner_red: coherent-fault` on its single registered product fault when
an intentional hard-cut interface or a behavior-preserving proof-ownership
refactor prevents BASE from reaching or falsifying the retained behavioral
contract. Policy MUST require one canonical exact proof, one product-only
applicable patch, its SHA-256, and its expected assertion fingerprint. The
manifest MUST also pin the SHA-256 of version-stable source slices for the exact
Python test plus its imports and non-test module support, or the exact file bytes
for a Vitest/Gradle/Node owner. Interpreter-specific AST serialization is not a durable
encoding. Imported testkit and fixtures retain their normal source/input identities;
the owner digest does not attest their contents. Any owner drift is a policy failure
requiring explicit review and a new digest. The coherent-candidate fault proves
only that registered contract; every independent new behavior requires a
separate proof and sensitivity witness. The exception mechanism itself
MUST have a canonical BASE sensitivity owner. The work report MUST name why
BASE was inapplicable.
Whole-file Python owners, class-qualified nodes, non-Python exact nodes, unmarked
faults, absent owners, duplicate owners, parse failures, digest drift, and Git
read failures fail closed.

A Python BASE checkout MUST retain the baseline revision's dependency manifests
and locks. Candidate Python proof and shared test-support overlays MUST NOT
install a candidate dependency graph into the unfixed application. A proof for
behavior that requires a new dependency must reach its behavioral assertion
before it imports or initializes that dependency, or use a controlled FAULT
against the coherent candidate revision.

CI MUST bind `UV_CACHE_DIR` to an invocation-owned directory beneath
`RUNNER_TEMP` and retain downloaded wheels through proof completion. A shared
runner cache or a cache pruned before an offline sensitivity environment is
materialized is not a valid dependency boundary.

CI MUST recreate the ignored Python virtual environment from the lockfile for
each job. The setup path MUST be the validated, runner-owned repository root;
the deletion target MUST be the exact non-symlink, non-mount `python/.venv`
confirmed by Git's ignore contract. Privileged Python proof processes MUST
disable bytecode writes. Reusing a persistent environment across jobs permits a
root-owned proof descendant to make the next runner-owned sync irreparable.

CI MUST remove the ignored `apps/web/.next` tree before dependency setup and
storage admission, then remove it again after each terminal job path. Generated
frontend output belongs to one source SHA and MUST NOT consume the persistent
runner's idle reserve or become an input to another SHA. The entry cleanup owns
recovery when a killed runner cannot execute its terminal finalizer. Dependency
download caches remain separately keyed and may persist.

The final work report for a defect or replacement MUST state how sensitivity was
demonstrated. “Test passes” is insufficient.

### Reward-hacking prohibitions

An implementation task does not authorize an agent to:

- delete, skip, quarantine, weaken, or rewrite existing proof merely to become
  green;
- replace behavioral assertions with existence, status-only, or call-count
  assertions;
- mock the code responsible for the behavior under test;
- widen timeouts or add retries without proving a timing contract;
- update snapshots or golden artifacts without independently reviewing the
  semantic change;
- change fixtures so the failing case no longer occurs;
- claim a higher evidence level than was actually run.

Changing or deleting proof is allowed when the supported product contract
changes or replacement proof is stronger. The change MUST say which contract
changed or which demonstrated-sensitive proof supersedes it.

## 4. Nexus risk priorities

Nexus is a one-user product. Brief UI downtime is less consequential than
irreversible harm. Protect these first:

- data loss and corruption;
- privacy, authorization, token, share, credential, or secret leakage;
- destructive cleanup and irreversible side effects;
- migration failure and schema/data incompatibility;
- duplicate billing, provider dispatch, or other costly effects;
- lost or incorrectly persisted reading progress;
- broken citations, provenance, locators, or source identity;
- durable-job loss, duplication, stuck work, retry, cancellation, or replay
  failure;
- PostgreSQL/object-store divergence;
- tool-bearing LLM prompt injection or unauthorized side effects;
- signed native release and authentication handoff.

Every proof MUST name a current risk, invariant, regression, or production
contract. The mapping must be obvious from its name/module or one concise
adjacent comment. “Increases coverage” is not a reason.

For a changed behavior, assess:

- consequence: 0–4;
- runtime/provider/device boundaries crossed: 0–3;
- concurrency, replay, or irreversibility: 0–3;
- change frequency and escape history: 0–2.

Interpretation:

- **9–12, critical:** closest-seam proof, applicable real dependency,
  demonstrated fault sensitivity, enclosing journey where cross-boundary
  behavior matters, and release/production evidence;
- **6–8, high:** kernel/contract proof plus real database, process, or browser
  behavior;
- **3–5, medium:** service/component proof;
- **0–2, low:** static or pure proof.

Auth, secrets, money, destructive mutation, anonymous sharing, migration, and
signed releases are critical regardless of arithmetic.

## 5. Choose the proof boundary

| Behavior or failure | Primary proof |
|---|---|
| Type, import, registry, schema, config, or architecture rule | Type checker, linter, AST/schema check, or build |
| Pure deterministic rule | Focused example; property test when a general law exists |
| Retry, replay, cancellation, navigation, or lifecycle sequence | State-machine/model proof |
| Several in-process modules | Sociable component/service proof |
| SQL, transaction, lock, storage-shape constraint, migration, pgvector, query plan, or notification | Real PostgreSQL integration |
| Durable-job idempotency, claim, lease, or replay | Real PostgreSQL plus the real worker boundary; pure model proof may supplement |
| PostgreSQL/object-store ordering | Real PostgreSQL plus MinIO |
| UI layout, selection, focus, accessibility, PDF, editor, audio, browser storage, or SSE rendering | Real Chromium component proof |
| Independently released consumer/provider | Contract/conformance proof |
| Browser/server/auth/configuration/process wiring | Thin real-stack journey |
| Untrusted parser or grammar | Property proof and, where justified, fuzzing |
| Hosted credential, quota, routing, signing, or wire compatibility | Scheduled hosted canary |
| Generated-content quality | Versioned evaluation set and explicit rubric |
| Production configuration/dependency reality | Post-deploy synthetic and telemetry |

A broader proof MUST NOT repeat edge cases already proved at a narrower reliable
boundary. Journeys prove wiring and cross-boundary behavior; they do not
enumerate business logic.

## 6. Authoring rules

### Test behavior, not implementation

- Assert returned behavior, persisted state, durable work, emitted protocol, or
  user-visible output.
- Do not assert private methods, internal call choreography, CSS classes, hook
  implementation, or incidental framework structure.
- A behavior-preserving refactor SHOULD NOT require rewriting its proof.
- Prefer static proof to runtime tests when the property is mechanically
  decidable.
- Do not test language, framework, ORM, React, browser, or third-party-library
  behavior unless Nexus deliberately depends on an undocumented behavior being
  characterized.
- Remove completed-cutover source greps instead of preserving tombstone tests.

### Database rules

Use database constraints only for storage-owned shape:

- nullability;
- primary-key identity;
- foreign-key reachability;
- true schema-owned uniqueness;
- the narrow append-only event-type exception owned by
  `docs/rules/database.md`.

Business, permission, lifecycle, tagged-union, conditional-nullability, and
cross-column invariants remain in application code plus executable defects. Do
not introduce `CHECK`, exclusion, trigger, or other database business-invariant
machinery contrary to `docs/rules/database.md`.

Use a dedicated local PostgreSQL server matching production's version and
required extensions for transactions, isolation, locks, constraints, raw SQL,
pgvector, migrations, query plans, `LISTEN/NOTIFY`, and commit-time behavior.
SQLite, mocked SQLAlchemy sessions, and emulated dialect behavior are not
substitutes. The production server itself is forbidden by §11.

Test-data factories SHOULD construct ORM-backed application records or call the
owning service. Raw SQL is reserved for migration/schema proof, harness
baselines, raw-SQL-owned tables, or deliberately unreachable states.

### Test doubles

The policy is **no casual interaction mocks**, not “zero doubles.”

Use this preference order:

1. the real, fast, deterministic implementation;
2. an owner-maintained fake checked by the same conformance cases as the real
   adapter;
3. a narrow stub for an uncontrollable external response or failure;
4. an interaction mock only when call count, order, or absence is itself the
   product contract.

Do not mock:

- fast Nexus collaborators merely to isolate a class;
- SQLAlchemy sessions or PostgreSQL behavior;
- React hooks, state stores, route modules, or service modules into an imitation
  of Nexus;
- the exact implementation path whose behavior is being asserted.

Controlled clocks, randomness, UUIDs, network faults, provider responses, and
process failures are allowed when they make consequential behavior reproducible.

Deterministic provider/content behavior that must cross a process boundary MUST
run in a test-owned process behind the same configured HTTP client, gateway, or
proxy boundary used by production. Bind that process to an exact controller-owned
loopback port and serve protocol-valid success, stream, malformed, and failure
responses. Product code MUST NOT contain test-selected branches, fixture
environment flags, canned provider responses, or alternate fixture runtimes.
Static fixtures and test-only DNS may choose what the local server returns; they
never authorize a non-loopback connection. Hosted proof is the only exception
and uses its separately authorized capability.

### Browser components, the BFF, and SSE

A Vitest browser-component proof MAY stub the Nexus BFF at the `fetch`/HTTP
boundary when the declared system under test is the UI. This is a protocol stub,
not permission to mock owned UI behavior.

Requirements:

- Stub `fetch` or the network boundary, not an imported hook, store, route,
  service client, or component collaborator.
- Use schema-valid shared response fixtures with status, headers, and error
  shape where relevant.
- Assert UI behavior and resulting user-visible state, not fetch call count,
  unless duplicate/absent dispatch is the product contract.
- Prove the real endpoint independently through FastAPI/BFF service or process
  proof.
- Keep at least one real-stack journey for critical BFF/auth/configuration
  wiring.

For SSE component behavior, use real `ReadableStream`/decoder/event protocol
fixtures covering frames, disconnect, replay, malformed events, and terminal
state. Do not mock the consuming hook. At least one journey must prove the real
browser → BFF/direct-SSE → FastAPI → worker path where the product uses it.

No repository-wide fetch helper is a promised contract. Keep a minimal,
schema-valid fetch-boundary fixture beside its sole proof; once another proof
shares the same protocol contract, extract one small owned testkit helper.
Never copy a deleted legacy helper or generalize unrelated endpoint shapes.

### Isolation and fixture shape

- Reuse service processes only within one controller invocation; never retain
  them after that invocation, and never reuse writable test state.
- Proof MUST NOT depend on execution order or mutations left by another test.
- Isolate users, libraries, object prefixes, files, ports, queues, and browser
  state wherever writes can escape.
- Use small named fixtures and readable scenario data. Prefer DAMP setup over a
  helper DSL or giant mutable seed that hides behavior.
- Direct database construction is allowed for an immutable baseline or otherwise
  unreachable state; independently verify the builder against owner behavior.
- Randomize order periodically and repeat concurrency-sensitive proof under
  controlled scheduling where useful.
- Never use unbounded sleeps. Wait for an observable condition with a bounded
  deadline.
- A scenario may assert multiple steps of one invariant. Do not fragment a
  coherent workflow to increase test count.

### Names and assertion diagnostics

- Name the trigger, observable behavior, and material condition. Reject
  `test_works`, `handles_error`, numbered acceptance criteria without behavior,
  and names that merely repeat a function name.
- Parameter IDs MUST make a failing case identifiable.
- Keep the meaningful setup, action, and expected outcome visible in the test.
- Shared helpers may remove plumbing; they MUST NOT contain the scenario’s
  decision logic or oracle.
- For indirect service, worker, migration, browser, and journey failures,
  assertion output MUST include the relevant resource identity, input/case,
  expected state, actual or last observed state, and boundary being proved.
- A message that merely restates `expected true` is not diagnostic.

### Flakes

- Automatic retries are forbidden in every blocking workflow. A diagnostic
  rerun is a separate, explicitly requested run and never changes the first
  verdict. Use `./scripts/test diagnose --of <16-hex-run-id>` only for a failed
  v3 workflow summary at the same clean committed `HEAD` and exact recorded
  invocation inputs; the controller allows one formal replay, links separate
  evidence, keeps top-level `status: fail`, and exits nonzero. CI and Agency
  gates MUST NOT invoke it.
- Never use silent retry, indefinite skip, quarantine-to-green, or timeout
  inflation.
- Fix, replace, or delete a flake according to its unique risk signal.
- Temporary quarantine requires a reason, expiry, and replacement proof for any
  priority risk. Solo ownership is implicit.

## 7. Portfolio and budgets

Static proof is comprehensive. The behavioral center of gravity is real
PostgreSQL service proof and real-Chromium component proof. The kernel is small
and semantically dense. The browser portfolio has ten named journeys; adding
one requires deleting or justifying overlap. Test count and line coverage are
not targets.

A red or `not_run` result is decisive. The controller records later
capabilities as blocked and launches no further heavy work.

| Workflow | Cached target | Additional cold behavior |
|---|---:|---|
| exact proof / `changed` | under 10 seconds when no heavy boundary is selected | dependency, service, or first template/build cost is recorded, not hidden |
| `confidence` | 60–90 seconds | selected service/component setup may exceed the cached target |
| `pr` | 3–5 minutes locally | CI duration is measured before a p95 ratchet is adopted |
| `full` | measured; no fixed acceptance number | one current-revision build and one sequential heavy process |
| `nightly` / `release` | scheduled | device work remains fail-closed |

The controller records peak RSS for its process tree and the working set of
containers owned by the exact test compose project. CPU count never chooses
workers. Run one Next build, Chromium suite, or Gradle operation at a time; do
not overlap unrelated heavy lanes. Kotlin compilation runs inside the owned
single-use Gradle process; no Kotlin compiler daemon may outlive an Android
proof. Build a strict-CSP Next artifact at most once per distinct executable
source/environment fingerprint and reuse it.
Ordinary workflows therefore build the current revision once. Sensitivity MAY
build one additional artifact for each distinct faulted or base revision whose
production browser proof must execute that code; reusing the green artifact
there would make the red oracle vacuous. Never rebuild the same fingerprint in
one workflow. A sensitivity portfolio completes and retires every isolated red
revision runtime before it starts current-revision green attempts. Red and green
service stacks MUST NOT coexist; green attempts still reuse one
current-revision stack and build fingerprint.

Before any workload or recovery command, the controller acquires one
lineage-wide invocation lock and holds it through terminal runtime teardown.
Linked worktrees and independent complete-history clones derive the same lock
from their Git lineage. `list --json` alone bypasses the lock because it starts
no work or runtime. The historical single-heavy-operation lock path remains the
same so older controllers cannot overlap a heavy phase; nested heavy,
sensitivity, and visual boundaries reenter only beneath the explicit invocation
owner.

Before launching Node/browser/build/Gradle or other heavy proof under that
<<<<<<< /tmp/pr249-ci-reconciliation/ours/docs/local-rules/testing-standards.md
lease, the controller waits at most 30 seconds for kernel-reported available memory to reach 2,048 MiB: Linux `MemAvailable`, or
Darwin free plus file-backed pages while the kernel VM pressure state is normal.
The Darwin estimate does not add speculative pages because they are already
included in the file-backed owner, and excludes anonymous inactive, purgeable,
and compressed pages. This bounded admission wait only resamples host state; it
never launches or reruns proof and is not an automatic retry. Unknown memory or
non-normal Darwin pressure is immediately `not_run`; expiry below the floor is
`not_run` before launch and reports the latest observed value. This is a
conservative host-safety admission floor, not a proof-size or performance
target. Change it only from recorded memory evidence on the 8 GiB reference
host.
||||||| /tmp/pr249-ci-reconciliation/base/docs/local-rules/testing-standards.md
lease, the controller waits at most 30 seconds for kernel-reported
`MemAvailable` to reach 2,048 MiB. This bounded admission wait only resamples
host state; it never launches or reruns proof and is not an automatic retry.
Unknown memory is immediately `not_run`; expiry below the floor is `not_run`
before launch and reports the latest observed value. This is a conservative
host-safety admission floor, not a proof-size or performance target. Change it
only from recorded memory evidence on the 8 GiB reference host.
=======
lease, the controller waits at most 30 seconds for kernel-reported
`MemAvailable` to reach 3,584 MiB. This bounded admission wait only resamples
host state; it never launches or reruns proof and is not an automatic retry.
Unknown memory is immediately `not_run`; expiry below the floor is `not_run`
before launch and reports the latest observed value. This is a conservative
host-safety admission floor, not a proof-size or performance target. The floor
retains the recorded 2,293 MiB process-tree peak plus the reference host's
early-OOM reserve and operating margin. Change it only from recorded memory
evidence on the 8 GiB reference host.
>>>>>>> /tmp/pr249-ci-reconciliation/theirs/docs/local-rules/testing-standards.md

Under the same lock and immediately before launch, heavy proof also requires
8,192 MiB free across the checkout filesystem and, when the proof may use the
local container runtime, Docker's reported data-root filesystem. Unknown or
insufficient storage is immediately `not_run`; the controller does not start
the proof or poll a capacity condition that requires operator reclamation. The
floor retains roughly five percent of the 150 GiB reference host as an operator
safety reserve. It is not a predicted proof footprint. Change it only from
recorded disk evidence.

The typed root-ownership contract names the two kernel proof owners that create
and inspect genuinely root-owned release fixtures. Before any workflow
capability runs, the controller requires effective uid 0 or verifies
non-interactive `sudo`; `doctor` checks the same boundary. An unqualified host
returns `not_run` with captured command diagnostics. CI performs the identical
qualification before toolchain setup. Never replace the real uid, gid, or mode
oracle with user-owned fixtures.

## 8. Repository capability contract

`./scripts/test` is the sole public test and verification API. GitHub's
`pull_request` job runs `./scripts/test changed --base <base sha>`; the `main`
push runs `./scripts/test full`, which is the release proof. `scripts/test`
is a thin locked launcher; `scripts/agency_verify.sh` is a thin `confidence`
adapter. The Makefile deliberately has no test/check/verify aliases.

Manual CI recovery verifies the exact open PR head and base, then constructs
their synthetic merge. Its `proof` choice defaults to `changed`; select `pr`
to run the complete PR portfolio and same-run sensitivity on the Linux runner.
That manual `pr` job has a 480-minute limit; ordinary PR and manual `changed`
jobs have 120 minutes. Main run `34712797648` completed its job in 101m24s
(controller: 99m39.736s), giving 18m36s of observed headroom. This is a
provisional execution bound from one measured run, not a p95 target. Proof
selection and behavioral timeouts remain unchanged.

The controller gives real-stack browser capabilities one clean data epoch. It
recreates the exact run-owned application database from the immutable template
and empties the exact run-owned bucket under the run lifecycle lock before any
browser API or worker process starts. It refuses an absent/malformed resource
or an active database consumer. Committed service/evaluation proof state must
never become an implicit journey fixture; browser capabilities may share the
resulting epoch only after that explicit boundary.

On a persistent self-hosted runner, a workflow artifact MUST contain only the
single `test-results/runs/<run-id>` directory claimed by that workflow's test
invocation. The CI adapter snapshots existing run identities, creates a private
mode-600 claim file under the runner temporary root, and passes only its open
descriptor to `./scripts/test`. Immediately after claiming the top-level run
directory, the controller writes its exact 16-hex identity and relative path to
that descriptor, closes it, and removes it from every capability environment.
Nested capability proofs may create subordinate run directories, but namespace
timing cannot make one of them the workflow artifact. The adapter rejects an
absent, malformed, pre-existing, or noncanonical claim, plus symlinks, special
files, or foreign ownership, and stages only the claimed directory beneath the
runner-owned private temporary root. It never deletes local historical evidence
to manufacture isolation. The upload is mandatory whenever an exact directory
was claimed, including a failing or interrupted run, and the exact staging
directory is removed after the upload attempt. Because GitHub discards step
outputs from a failed step, the adapter returns success only after staging
validated evidence and publishes the canonical proof result as data. A final
always-run step enforces that result after upload and cleanup; an adapter,
upload, cleanup, `fail`, or `not_run` outcome still fails the job.
The adapter launches the controller in its own process group and forwards
HUP/INT/TERM as an owned TERM before staging interrupted evidence. Every command
spawned by the controller preserves the Actions runner's inherited process
tracking identity, without admitting a caller replacement, so the runner can
reap the complete proof tree even if cancellation escalates past cooperative
controller cleanup.

Every controller path that may create local runtime resources MUST acquire the
lineage-wide heavy-work lock before admission and hold it through exact run
cleanup. The lock is also the active owner's liveness lease: after acquiring it,
the next heavy admission MUST treat any run still named by that checkout's
mutable recovery ledger as abandoned, start or attest the checkout's local test
services, and replay exact ledger-driven cleanup before creating a new run. It
MUST fail closed and retain the outstanding ledger when service attestation or
any cleanup owner fails. Recovery MUST NOT scan for, infer, or delete foreign or
unrecorded processes, containers, databases, buckets, users, or checkouts.

| Command | Required meaning |
|---|---|
| `./scripts/test changed [--base REF] [PATH_OR_NODE ...]` | changed static paths plus selected affected proof |
| `./scripts/test confidence` | complete policy/static/kernel plus affected service/component proof |
| `./scripts/test pr` | deterministic blocking PR portfolio plus same-run sensitivity; the local pre-merge command |
| `./scripts/test full` | complete deterministic local portfolio |
| `./scripts/test nightly` | `full` plus randomized/property audit and Android device proof |
| `./scripts/test release` | `full` plus Android device proof, signed Android release proof, and exact staged artifacts |
| `./scripts/test doctor` | local tool, dependency, browser, SDK, service, port, and template readiness; protected-workflow inputs only when that lane is explicitly enabled |
| `./scripts/test android-visual --sha HEAD_SHA --path /OWNED_PATH [--device primary]` | explicit opt-in physical-device authenticated WebView visual check of the current non-`main` worktree; never included in `changed`/`confidence`/`pr`/`full`/`nightly`/`release` |
| `./scripts/test prove --proof PROOF --against base:REF\|fault:FAULT_ID` | exact demonstrated-red then green sensitivity evidence |
| `./scripts/test diagnose --of RUN_ID` | one separately recorded replay of the exact failed workflow; never a new verdict |
| `./scripts/test clean` | recover from an unhandled interruption by deleting exact ledger-owned runs, the recorded local workspace stack/volumes, and its runtime state |
| `./scripts/test list --json` | machine-readable registry from the same typed execution source |

The typed registry is the single execution and workflow-composition source.
The command table above, CI routes, and deferred-owner map are explicit,
policy-checked projections that MUST change with it; they are not generated
from the registry.

`api-capacity` runs the candidate proof nodes declared in the typed registry;
the PDF, sparse EPUB and dense-word EPUB worker-overlap nodes build API and
background-worker targets from one frozen source context. they upload actual
100 MiB / 10,000-page / 32 MiB extracted-text PDF or 64 MiB aggregate
sanitized-HTML-plus-canonical EPUB recipes. both cgroups, source publication,
selected-source queries and reader/image/progress/readiness outcomes are retained.
the same worker also overlaps the first and repeated history endpoint calls
against 100,000 retained usage rows and the complete 95-candidate request. all
five expensive reader/history/image calls must succeed and intersect the actual
source child; readiness and progress remain observable alongside them. history
means first endpoint use in a fresh API process with a warm fixture database,
not a cold-cache database measurement.
these are qualification profiles, not successful maximum-capacity claims.
the worker uses exact run-owned loopback infrastructure with host networking and
the existing external Codex and embedding peers outside its measured cgroup.
the inherited default-deny network guard remains active; only its public CA and
exact Codex socket enter the image. metadata and indexing follow-ups must reach
successful domain outcomes. this exercises actual worker/job code but does not
claim production network-latency equivalence.
the secret-free run-owned socket permits local connects with mode 0666 because
rootless Docker group ids do not equal host group ids. its host parent remains
private, its audit remains 0600, and only that socket is mounted read-only into
the unchanged uid-10001 worker. the receipt records the actual socket mode;
successful metadata execution, not file permissions alone, proves composition.
`list --json` exposes that complete set. Historical image qualification runs only
when its exact incident-baseline node is explicitly selected through `changed`.
An imports-only receipt proves no request/worker envelope; the final resource
qualification must include those workloads before production limits are adopted.

<!-- nexus-test-routing-sha256: 2dba3f9357262a22ddeab529ef1a4482a3579deeb1ff6ab17c2ab453afb0d16d -->

When changed-file routing names a capability later than the invoked workflow,
the controller MUST retain it in evidence with its exact `deferred_to` owner and
MUST NOT dispatch it early or reject the current gate. Deferral MUST NOT clear
declared priority-risk or fault sensitivity: only paid hosted-provider and
physical-device boundaries are excluded. The owning `full`, `nightly`, or
`release` workflow remains fail-closed.

### Proof owners

| Boundary | Owner |
|---|---|
| Python kernel/control plane | `python/tests/kernel/` |
| Shared local-real testkit | `python/tests/testkit/` and `python/tests/conftest.py` |
| Real PostgreSQL/API/service | `python/tests/service/` |
| Migration graph and convergence | `python/tests/migrations/` |
| Pinned portable LLM tools | `python/tests/llm_tools_contract/` |
| Node accepted-URL ingest egress | `node/ingest/test/*.test.mjs` |
| Release artifact/image binding | `python/tests/release_artifact/` |
| API image memory qualification | `python/tests/capacity/` |
| Deterministic LLM semantics | `python/tests/evals/` |
| Property/random-order audit | `python/tests/audit/` |
| Web pure kernel | `apps/web/src/**/*.unit.test.{ts,tsx}` |
| Chromium component | `apps/web/src/**/*.browser.test.{ts,tsx}` |
| Journeys, deployment smoke, extension | `apps/web/e2e/` under the sole Playwright config |
| Android host/device | `apps/android/app/src/test/` and `apps/android/app/src/androidTest/` |
| Corpus / risk registry | `testdata/manifest.json` / `testdata/proofs.json` |

Pytest markers do not route work. Typed capabilities and final-owner filename
conventions do. Ordinary Python proof is socket-denied, including spawned
Python workers through `sitecustomize`; only `tests/hosted/` with the
controller's explicit socket flag may contact external providers. Browser
component globals guard `fetch`, `EventSource`, and `WebSocket`; Playwright
allows only controller-recorded loopback origins. Node ingest proof runs through
the controller's `node-network-guard.mjs` and admits only loopback destinations.
The controller's canonical run environment is the single owner of deterministic
external-protocol loopback endpoints, proxies, static DNS, and fixture
credentials for in-process and spawned proof. Static DNS may expose the fixed
public documentation address required by production SSRF validation, including
through nested guards, but cannot authorize a non-loopback connect. No test may
supply product or production resource endpoints.

### Focused changed-proof commands

Use `./scripts/test changed <repository-relative path or exact
runner-qualified node>` for the supported inner loop. Direct pytest, Vitest,
Node, Playwright, or Gradle invocation is allowed for exact debugging (`--lf`,
watch, `--headed`, `--debug`) only; checked-in configuration and network policy
still apply. A direct invocation is not a workflow verdict.

## 9. Current fixture and corpus contract

### Local runtime and ownership

The controller may own one health-checked, workspace-local
PostgreSQL/MinIO/Supabase-test stack recorded in `.nexus-test/runtime.json` and
scoped to exactly one workload invocation. It clears stale recorded runtime
state before starting work, reuses service processes across capabilities in
that invocation, and tears down the exact stack, volumes, and runtime state
after every normal, failing, or handled-interrupt terminal path. Immutable
evidence under `test-results/` survives. `clean` remains the recovery owner for
an unhandled process death, and CI repeats cleanup in its always-run finalizer.
Before replacing a persistent runner checkout, CI invokes the prior controller's
public `./scripts/test clean` route. Recovery therefore acquires the same
lineage-wide lease as every workload before it tears down that checkout's exact
owned runtime. The incoming checkout cannot replace the runtime schema until
recovery succeeds.
Memory-heavy proof is serialized by one host lock for every independent clone
and linked worktree with the same complete Git lineage roots. Shallow history
fails closed because it cannot establish that stable identity; a synthetic
checkout without committed lineage falls back to its common Git directory.
This conservative lease prevents a local run and the self-hosted Actions runner
from producing nominally green but resource-contended evidence on the same
devbox.
Before `full` or a higher local workflow, `scripts/agency_setup.sh` hydrates the
exact pinned `provider-runtime`, `llm-tools` and `llm-agent-kernel` commits and
all of their locked artifacts. It requires adjacent `llm-calling`, `llm-tools`
and `llm-agent-kernel` Git checkouts, fetches only a missing pinned commit
object, and MUST NOT move any checkout's HEAD or refs or alter its index,
tracked files, or untracked files. The `llm-agent-kernel` checkout is also the
provider gate's and `doctor`'s prerequisite: both run `uv build --no-sources
--offline` in the hydrated kernel, so a kernel that cannot be packaged offline
fails the gate rather than being skipped. A missing adjacent checkout is a
fail-closed `_not_run`, never a pass. The test
controller then archives that immutable object into its owned checkout and
materializes the suite with network disabled. Android proof honors an explicit,
consistent `ANDROID_HOME` or `ANDROID_SDK_ROOT`; when both are absent, the
controller discovers only the conventional `$HOME/Android/Sdk` Linux install or
`$HOME/Library/Android/sdk` macOS install and publishes it to owned Android
children. An invalid, relative, or conflicting explicit SDK setting remains a
fail-closed prerequisite error and is never masked by discovery.
Initial allocation MUST exclude the host kernel's ephemeral client-port range;
when the kernel range interface is absent, the controller excludes ports
`32768–65535`; an unreadable or malformed present interface fails closed.
It provisions that stack and disposable writable resources lazily, only when a
selected proof crosses the database, object-storage, auth, or owned app-process
boundary. Static, kernel, Chromium-component, and Android-host-only workflows
MUST NOT start the service stack or run migrations. Every workflow receives a
run ID for ownership and evidence; a real-stack workflow additionally receives:

- a fingerprinted, migrated, non-connectable PostgreSQL template built from
  `template0`, then a clone named `nexus_run_<run-id>`;
- an empty `nexus_migration_<run-id>` database only when migration proof is
  selected;
- a MinIO bucket named `nexus-run-<run-id>`;
- scenario-local Supabase users named from the run and scenario IDs;
- processes, profiles, and other resources recorded in the mutable run recovery
  ledger before creation.

Before contacting a service, the controller MUST reject a non-test
`NEXUS_ENV`, caller-supplied resource configuration, public/non-loopback
endpoints, a repository mismatch, or a resource name outside the exact test
grammar. Cleanup walks the mutable recovery ledger in reverse dependency order
and deletes only resources both recorded there and still matching that grammar.
It removes an entry only after that exact resource is deleted and preserves
every failed or outstanding entry. Immutable run-context/resource-plan evidence
retains the complete audit record. Interrupted-run proof uses synthetic test
data and demonstrates that foreign or unrecorded resources survive.

### Python database and application fixtures

- `engine`: session-scoped engine for the controller-owned run clone.
- `db_session`: savepoint isolation inside that clone; default for service
  work.
- `test_user`: unique user/default library inside the rollback transaction.
- `authenticated_client`: the real FastAPI app and authorization stack paired
  with `db_session`; only external token verification is a controlled fake.

The offline-reading proxy seam additionally uses pinned Caddy `v2.11.4` and a
Uvicorn/FastAPI origin fixture as two recovery-ledger-owned processes. It loads
the production Caddyfile with only controller-owned loopback site/upstream
endpoints substituted and the local admin endpoint disabled; this is
process/config evidence, not a BFF-process claim.

Use ORM-backed factories or owner APIs so fixture shape follows production
models. Use a small local builder for unreachable states, and independently
verify it. Multi-connection visibility, worker claims, committed checkpoints,
pooling, and concurrency require an explicit process/service proof against the
disposable run database; do not add a convenience bypass fixture.

### Browser state and helpers

Chromium component proof uses the owner-local testkit and may stub only the
browser's external fetch/SSE boundary as defined in §6. It receives no run
database, bucket, Supabase user, or migrated template; needing one promotes the
proof to service or journey ownership. Every Playwright journey creates its own
local Supabase user and writable state, uses strict CSP, and runs in a fresh
context. `storageState`, setup projects, shared seed users, and shared mutable
JSON are forbidden. The sole Playwright configuration uses one worker and zero
retries.

Each journey declares its product-source owner globs in `testdata/proofs.json`.
Changing a declared source selects that exact journey. Lazy pane registry/body
ownership MUST use this route because static-import related-test discovery
cannot see dynamically registered panes.

Add a shared helper only when at least two proofs need the same stable plumbing.
Helpers expose product-shaped inputs/results and MUST NOT reproduce owner logic,
hide assertions, or contain the scenario's oracle.

### Canonical corpus

`testdata/manifest.json` is the machine owner for reusable cross-language
artifacts, including existing pane-find and consumption corpora and the selected
reader/real-media fixtures under `python/tests/fixtures/`. Reuse them across
Python and browser proof instead of creating divergent copies.

New captured or binary fixtures require:

- clear provenance and permission to retain;
- no secrets, tokens, or personal production data;
- the smallest useful artifact;
- an exact manifest entry naming provenance and represented behavior;
- a stable checksum;
- deliberate semantic review before replacing a golden artifact.

The policy capability validates every declared path, checksum, provenance
field, and undeclared corpus-file violation.

## 10. Specialized proof

### Durable jobs and multi-system operations

Durable-work proof names both state machines when they differ: the queue state
and the domain state.

Cover, according to risk:

- SERIALIZABLE retry;
- atomic enqueue/notify;
- claim and lease ownership;
- heartbeat and expiry;
- worker death after committed checkpoints;
- duplicate delivery and notification;
- cancellation races;
- dead-letter and finalizer behavior;
- domain failure represented as queue success where designed;
- storage success followed by database failure and the inverse;
- reconciliation convergence;
- SSE disconnect, replay, and terminal behavior.

Use real PostgreSQL and the real worker process boundary for idempotency,
visibility, and replay. A pure state-machine model supplements this; it does not
replace database/process proof.

### Migrations and deployment

Migration proof uses dedicated local PostgreSQL matching production's version
and extensions and covers:

- empty baseline → head;
- each explicitly supported production snapshot → head;
- the new migration’s semantic and data-loss behavior;
- raw-SQL-owned tables, constraints, indexes, and triggers;
- PostgreSQL/object consistency against synthetic local state where the
  migration crosses that boundary.

Do not preserve every historical migration permutation. Once all live databases
cross an agreed cutoff, create a new baseline and delete superseded migration
proof.

Nexus does not require rolling zero-downtime compatibility by default. For an
incompatible Vercel/Hetzner/schema cut, prefer an explicit maintenance window,
readiness check, migration, immutable artifact deployment, smoke, and rollback.
Test cross-version compatibility only when an owning product decision requires
zero downtime.

Downgrades are unsupported unless an owning architecture document explicitly
requires them. Prove forward migration and application-artifact rollback
instead.

### External providers

Ordinary PR proof makes no third-party calls. Use deterministic protocol
fixtures, `respx`, or a local boundary server for success, malformed payload,
timeout, rate limit, disconnection, and uncertain-dispatch behavior.

Run the same conformance cases against an owned fake and real adapter where drift
would be consequential. Scheduled/promotion canaries prove hosted credentials,
schemas, quotas, signing, redirects, webhooks, CORS/range/lifecycle, and
model/tool availability.

A missing secret is **not run**, never passing evidence. A promotion gate
designated fail-closed MUST fail when its required proof cannot execute.

### LLM evaluation and tool safety

Test deterministic orchestration, schemas, provenance, citations, accounting,
cancellation, retries, tool authorization, and side effects conventionally.

Semantic evaluation requires:

- a versioned, independently reviewed dataset;
- a stored baseline and explicit human-readable rubric;
- pinned model/provider/runtime versions in recorded evidence;
- deterministic graders where possible;
- repetitions and statistical thresholds only where variance matters;
- a declared per-run cost ceiling;
- preserved failing cases;
- explicit prompt-injection, untrusted-content, tool-escalation, and data-leakage
  cases for tool-bearing flows.

Never snapshot exact prose. Never let a model grade itself without independent
criteria and calibration.

### Browser behavior, accessibility, and visual quality

Browser proof uses user-visible roles, labels, text, keyboard actions, focus,
selection, and product identifiers. Avoid implementation selectors.

For relevant components and journeys:

- use semantic queries;
- exercise keyboard operation and visible focus;
- assert focus return after dialogs, sheets, previews, and navigation;
- automate basic accessibility checks where the harness supports them;
- conduct deliberate manual assistive-technology review for consequential
  interaction changes.

Broad pixel-by-pixel visual regression is out of scope. Use selected screenshots
or manual review for contracts that are genuinely visual—layout breakpoints,
overflow, PDF geometry, mobile chrome, and dense interaction states—and retain
only stable, reviewed baselines.

### Performance

The typed `bundle` capability owns the strict-CSP standalone build and its
current First Load JS budget.

Add a performance proof only with:

- a named user-visible or operational risk;
- representative data/workload;
- a stable measurement environment;
- an explicit percentile/budget and regression policy;
- evidence that functional proof cannot catch the failure.

Generic enterprise load and soak testing is out of scope. Targeted ingestion,
query-plan, memory, worker-throughput, or browser-startup proof is allowed when
the one-user workload or developer machine has a measured problem.

The `durable-ingest-reader-open` critical journey owns the bounded-media
lifecycle/availability seam: a manifest-owned 712-page PDF crosses public
upload, source extraction, Activity, complete content indexing, and concurrent
interactive `chat_run` work on the real local stack. It does not prove Caddy or
cgroup behavior; isolated parser RSS and the production Compose/release checks
own those layers.

### Android and extension

Chromium and Android WebView are the default supported matrix. Other browsers
are not implied by Chromium success.

Android instrumentation covers native ownership: App Links, auth handoff,
Credential Manager, WebView bridge, cookies, file chooser, share intents, Media
Session, background audio, offline behavior, signing, and measured
system-gesture inset geometry, arbitration preconditions, and WebView pointer
delivery at owned fixed-control geometry. That fixed-control instrumentation
owner records only measured OS/WebView preconditions, insets, and delivery. It
does not assert real SystemUI conflict arbitration; the physical-device operator
matrix owns Back/Home/quick-switch conflict acceptance. It never asserts
recognizer semantics, direction resolution, clamping, or click suppression;
the real-Chromium component proof owns those web behaviors. Do not duplicate web
behavior outside this enumerated native boundary.

For the mobile Nexus control, the same real-Chromium component owner also proves
cross-activation click provenance: a pointer-generated click retargeted into the
newly mounted Nexus task is rejected unless the matching pointerdown began
inside that already-active task. This guard remains local to `SwitchboardTask`;
the generic `MobileFullScreenTask`, document, window, and workspace owners gain
no handler or gesture state. Keyboard and assistive `detail === 0` activation
remains admitted.

The `android-device` capability accepts exactly one authorized `device` row
attested from `adb devices -l` — a locally started emulator, or a device
carrying adb's `usb:` topology fact — and binds Gradle to its serial. A wireless
adb transport cannot satisfy or coexist with that one-device boundary. Every
passing exact or complete instrumentation execution
MUST reference exactly one bounded, redacted
`test-results/runs/<run-id>/android-device-instrumentation.json` artifact from
its `CapabilityEvidence`. That artifact retains the exact candidate SHA,
selected inventory row, bound serial, exact proof/scope and command identity,
exit code, and successful instrumentation stdout/stderr; inability to retain it is
`not_run`, never pass. When the Nexus-control gesture owner is selected, its
successful test emits `NEXUS_CONTROL_GESTURE_DIAGNOSTICS:` through
`Instrumentation.REPORT_KEY_STREAMRESULT`; absence of that exact marker from
captured stdout or absence of exactly one fresh passing result for the named
Nexus method is also `not_run`. `nightly` uses the hosted emulator;
`release` runs on the protected USB runner and requires the wired handset
there. The debug sweep
excludes the signed-promotion annotation, whose scenarios only the signed lane
can stage. `android-release` is the signed physical-device lane: it builds the
candidate, refuses an emulated endpoint by reading the device's qemu build
properties back, tests the older signed baseline, and installs the candidate in
place on that same USB device. Missing physical-device/operator evidence is
`not_run` and blocks the fail-closed workflow; emulator instrumentation cannot
substitute for physical force-stop/reboot/offline evidence.

Signed-release evidence and its immutable artifact manifest retain the exact
direct API origin embedded in the APK. Physical offline-reading promotion must
compare that origin with the real mint response's `package_base_url` and fail
closed on drift; native exact-origin enforcement is not relaxed.

The signed physical promotion controller has two explicit device topologies.
The default, compatible topology acquires against the strictly older installed
baseline, owns and attests force-stop/reboot/first-unlock/airplane for its cold
offline phase, then installs the candidate in place for exact
reopen/progress/purge validation. An incompatible contract cut may instead use
`empty_baseline_hard_cut`, but only after production activates the candidate
contract: the controller first enables airplane mode and proves the complete
legacy shelf empty through a quiesced read-only file/database census that cannot
invoke cleanup, installs the candidate, disables airplane mode for
candidate acquisition, then force-stops/reboots and proves the candidate's
packages and progress offline before purge. This mode is not compatible with
`bootstrap_no_device`; it never guesses, migrates, or silently discards legacy
offline state. A missing executable staged owner is `not_run`; a controller
topology test is not physical promotion evidence. Retained release evidence
records the selected topology and only facts the controller read back from the
device — the qemu build properties and each phase's `airplane_mode_on` value —
never an assumed constant.

Extension proof covers MV3 runtime, permissions, bearer scope, content capture,
and handoff boundaries. Reuse the canonical content corpus.

## 11. Local test-runtime safety

This testing system may create and destroy only dedicated local test resources.
It MUST NOT contact, inspect, verify, mutate, restore, or clean up production
PostgreSQL, object storage, Supabase, or user data.

Before any resource contact or creation, the controller MUST:

- force `NEXUS_ENV=test` and reject any other product environment;
- reject caller-supplied database, storage, Supabase, or service resource
  configuration;
- pin Docker and Supabase CLI work to a verified local Unix-domain Docker
  socket; remote Docker hosts and contexts are forbidden;
- accept only controller-derived loopback endpoints and exact test-only names;
- persist the repository identity, run ID, resource kind, planned identity, and
  ownership state before creation.

Cleanup MUST read the run ledgers and validated workspace runtime record,
revalidate repository and resource-name ownership, delete exact run resources,
then stop and remove only the recorded local Supabase/Compose projects and
test-only volumes. It MUST preserve every foreign, unrecorded, public, or
ambiguously named resource. Synthetic interruption proof must cover crashes
between plan/create/record and idempotent repeated cleanup.

Immutable run-context/resource-plan evidence is the complete audit record, not
the cleanup oracle. The mutable recovery ledger is the cleanup authority.

Process identity uses the persisted run and random owner tokens, process-group
leader PID, and kernel start token. On Linux, each owner token also names one
transient user scope whose cgroup contains the complete descendant tree across
sessions and controller restarts. The planned command remains audit evidence,
not a live identity oracle: runtimes such as Next may legitimately rewrite
`argv`. Readiness MUST verify that a socket in the exact owned process group
owns the expected loopback listener; a healthy stale or foreign listener is a
failure, never readiness evidence.

Independent teardown owners are all attempted even when one fails. After each
exact successful deletion, cleanup removes only that recovery-ledger entry. Any
failure returns nonzero and preserves every failed or outstanding entry and its
exact recovery path; run ownership is released only when the ledger is empty.

A local synthetic restore scenario is allowed only when it proves a concrete
migration or PostgreSQL/object-consistency risk. It is not product disaster
recovery evidence.

Production backup, PITR, AWS recovery infrastructure, Cloudflare R2 recovery,
retention, RPO, RTO, and restore drills belong to a separate future operations
project. They are not a test workflow, release prerequisite, or acceptance
criterion in this repository contract.

### Deployment and production smoke

Use:

- a production-equivalent preview of the immutable release artifact;
- maintenance mode for incompatible hard cuts;
- safe post-deploy smoke;
- event-level data/job invariants;
- build-SHA-tagged logs, traces, and errors;
- known-good application rollback;
- explicit migration-forward handling where required.

Percentage canaries have little statistical value for one user. Use a dedicated
synthetic identity/tenant or read-only probes. Production writes must be
isolated, reversible, and explicitly authorized.

Sparse traffic makes aggregate error-rate dashboards insufficient. Monitor
critical events, stuck durable work, invariant violations, and user-visible
paths. Production smoke MUST remain read-only or use a dedicated reversible
synthetic identity and MUST NOT imply disaster-recovery proof.

## 12. Mechanical enforcement

The paved road enforces the mechanically decidable part of this contract:

| Contract | Enforcement owner |
|---|---|
| Sole command/routing/workflow/docs ownership | typed capability registry plus policy route-contract checks |
| Final-owner path and filename taxonomy | registry selection and policy AST/path checks |
| No owned-code mocks, sleeps, skips, or focused commits | Python AST policy plus test-scoped ESLint/Playwright policy |
| Ordinary Python network denial | in-process socket guard plus inherited `sitecustomize` worker guard |
| Browser network denial | component global guards and controller-recorded loopback Playwright allowlist |
| Local-resource isolation | pre-contact environment/endpoint/name validators and exact ownership ledger |
| No test-only product seams | product-source policy scan plus test-owned loopback protocol processes |
| Deterministic execution | zero automatic retries, one Playwright worker, fixed audit seeds, one lineage-wide invocation lock |
| Fixture provenance | `testdata/manifest.json` path, provenance, and SHA-256 validation |
| Priority-risk and journey routing | `testdata/proofs.json` schema, source owners, minimum risk IDs, exact journey selection, and sensitivity records |
| Falsifiability | `prove` red/green evidence plus PR policy for changed priority-risk and declared-fault proof |
| Evidence integrity | versioned run summary schema, `pass|fail|not_run`, fail-on-`not_run`, bounded artifacts |
| Corpus/policy self-protection | policy capability runs in every blocking workflow and has adversarial kernel proof |

Warnings configured as errors and broken normative links remain policy-owned.
`testdata/policy-exceptions.json` is the only mechanical exception surface; an
entry requires exact scope, rationale, expiry, and replacement disposition.

Do not mechanize semantic judgment merely to satisfy this table. Smallest
boundary, oracle independence, unique risk, assertion quality, and whether a
visual or accessibility contract was truly observed remain review decisions.

## 13. Adding or changing proof

Before adding or changing a proof, answer:

1. What risk, invariant, regression, or production contract does it prove?
2. What independent artifact supplies the oracle?
3. How was or will sensitivity be demonstrated?
4. What is the smallest boundary that can observe the failure?
5. Is the behavior already proved elsewhere or statically?
6. Which real dependency is essential?
7. What nondeterminism and writable state are controlled?
8. Will failure identify the input, state, identity, and responsible boundary?
9. Which focused command and public lane own it?
10. When can it be retired?

Reject proof that:

- lacks an independent oracle or named risk;
- has not met its required sensitivity level;
- asserts owned implementation choreography;
- mocks controllable Nexus behavior;
- duplicates existing proof without crossing a new boundary;
- relies on shared mutation or execution order;
- sleeps rather than observing state;
- silently contacts a provider;
- places a narrow edge case in a journey;
- adds material time or memory without an appropriate cadence;
- exists only for coverage or test-count growth.

When fixing a defect, add proof at the narrowest boundary that would have caught
it. Add broader proof only when wiring, configuration, deployment, or a
cross-boundary interaction caused the escape.

## 14. Legacy replacement and deletion

All new proof follows this policy immediately. When touching legacy proof, do
not expand its mocks, shared state, duplication, runtime, or fixture complexity.
Prefer clean replacement and deletion.

Priority-risk legacy proof remains blocking until its replacement:

1. names the same risk;
2. uses an independent oracle;
3. demonstrates sensitivity to a representative fault;
4. passes at the intended real boundary;
5. is faster or materially more diagnostic;
6. has run successfully in its intended gate.

Only redundant or low-priority legacy proof may move to non-blocking shadow
before replacement completes. Shadow is a comparison phase, not permission to
remove coverage.

Delete proof when:

- its risk no longer exists;
- stronger cheaper proof subsumes it;
- its supported compatibility window closes;
- a cutover is complete;
- its unique signal no longer justifies its resource/maintenance cost.

Do not preserve tests as historical documentation. Durable product and
architecture contracts belong in owner documentation.

The replacement order is:

1. cap resource use and stop repeated setup/build waste;
2. define critical risks and approximately ten product-existence journeys;
3. establish invocation-scoped services, per-run state, and the shared corpus;
4. build the compact kernel/service/component portfolio without translating old
   tests one-for-one;
5. replay known regressions and inject representative faults;
6. compare remaining legacy proof without weakening priority-risk gates;
7. delete mock-heavy, duplicate, source-grep, snapshot, historical migration,
   framework, and low-value flaky proof aggressively;
8. make affected proof the default and schedule full/provider/device work at
   its proper cadence.

Deleting 85–95% of legacy test count or source is plausible, not a quota.
Replacement is complete when current risks have stronger, sensitive, faster,
and more diagnosable proof.

## 15. The 80/20 paved road

Build these in order:

1. one repository-owned `changed`, `confidence`, `pr`, `full`, `nightly`,
   `release`, and `doctor` interface;
2. an explicit memory-admission floor, measured ratchets, no `-n auto`, and no
   overlapping heavy local gates;
3. one invocation-scoped Postgres/MinIO/Supabase stack;
4. one migrated seed database cloned per run;
5. one immutable canonical corpus plus per-run writable state;
6. default-deny network, owned-mock/sleep lint, E2E lint, and visible flakes;
7. one production build per executable fingerprint, reused by browser projects;
8. demonstrated-sensitive replacement proof and aggressive legacy deletion;
9. bounded release proof and safe post-deploy smoke.

Do not add Bazel, remote execution, per-test containers, Pact, ML selection, a
custom quarantine service, a large browser/device matrix, repository-wide
mutation testing, full distributed-system simulation, generic load/soak
infrastructure, broad pixel regression, or a commercial LLM-evaluation platform
without a measured problem that simpler tooling cannot solve.

The current audit owns targeted property proof and fixed-seed randomized order.
Targeted state-machine proof, fuzzing, changed-code mutation, deterministic job
simulation, and hosted conformance are allowed only when a named risk earns
their cost.

## 16. Evidence, metrics, and maintenance

Failure artifacts include, as applicable:

- build SHA and exact command;
- input/case identity and property seed;
- service/runtime image or version;
- relevant redacted logs and traces;
- browser trace, screenshot, and last visible state;
- database identity and migration head;
- last observed job/storage state;
- sensitivity method and result.


If capability admission, execution or cleanup raises, the summary retains completed
capability evidence and fails the active owner; pending capabilities remain
`not_run`. Cleanup failure replaces that owner's prior result while preserving
its duration, artifacts and any earlier failure detail. The normal workflow and
formal diagnostic replay use this same projection and existing secret redaction.

Formal diagnostic evidence names `command: diagnose`, the original failed run
and summary, and a nested `diagnostic_result`. Its top-level status remains
`fail` regardless of the replay result. The v3 run summary records UI mode, a
secret-safe fingerprint of outcome-affecting execution inputs, and the closed
typed Android visual inputs when that workflow owns them; replay rejects any
mismatch and reuses those recorded values. Its exclusive attempt record moves
durably from `started` to `terminal` only after the linked summary exists.
Direct runner debugging remains unlinked, non-gate evidence.

The v3 hard cut rejects older summary shapes. One sampler spans sensitivity
and ordinary capabilities; each red/green attempt records duration, owned
memory, and bounded retained artifacts. One compact run-context artifact owns
redacted fixed commands and observed runtime/template/build/browser identities.

The controller does not stream raw live child output. It captures bounded
output, waits for the child to exit, classifies the first decisive failure, then
reports that classified failure immediately.

Never capture secrets, auth tokens, provider credentials, or personal production
content.

Track only metrics that change decisions:

- p50/p95 first actionable failure and decisive result;
- peak memory and compute time for heavy lanes;
- escaped failures grouped by missing boundary/oracle;
- proof consuming maintenance without unique signal.

Do not use raw test count, line coverage, assertion count, or green retries as
quality indicators. Coverage is a searchlight for unvisited risk, not a
confidence score.

This document owns stable Nexus intent and the current executable routing table.
When Make targets, markers, fixtures, supported platforms, or paved-road
capabilities change, update this document in the same change. Agents MUST never
be instructed to use nonexistent infrastructure or to infer production proof
from a lower lane.

## Methodological basis

This policy follows the durable common ground in:

- Google’s guidance on test size, hermeticity, doubles, flakes, selective
  mutation, and the limits of large tests;
- Martin Fowler’s sociable tests and smallest-useful-boundary approach;
- Spotify’s service-level integration model;
- Playwright’s isolation and user-visible behavior guidance;
- property/state-machine testing for invariant-rich behavior;
- independent-oracle and demonstrated-sensitivity requirements for
  agent-authored proof;
- production monitoring and rollback.

External methodology is evidence, not authority. Nexus architecture, supported
behavior, consequences, feedback budgets, and recoverability determine the
portfolio.
