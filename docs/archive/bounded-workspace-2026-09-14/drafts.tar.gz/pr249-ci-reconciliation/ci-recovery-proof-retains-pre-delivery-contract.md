status: open; source-audited, not executed
origin: 2026-09-14 pr249 merge audit, frozen delivery 5d687cdc8a
area: ci workflow proof alignment

`python/tests/kernel/test_ci_pr_recovery.py:314–366` still requires unconditional
`clean: false`, direct pr/full commands and the old pr step name, and rejects
`--reinstall`. the safe-environment case at 409 also expects the old uv command.
`.github/workflows/ci.yml` now owns hosted-only checkout cleanup and the reviewed
`ci-proof-artifact.sh` changed/pr/full dispatch; setup-test hydrates its owned uv
cache with `--reinstall`. these mismatches predate pr249 and survive a clean
merge of that branch's added generated-build proofs.

preserve final workflow ownership and all original identity, runtime retirement,
cache and path checks. update only the obsolete source expectations, retaining
both exact dispatch branches. the isolated draft is fixture-alignment.patch;
no source was changed while the delivery check was frozen.

acceptance: independently review that delta, then run the entire existing
ci recovery kernel owner and current artifact-wrapper owner through scripts/test.
retain upstream generated-build cleanup cases; do not call this source audit a
runtime failure or green.
