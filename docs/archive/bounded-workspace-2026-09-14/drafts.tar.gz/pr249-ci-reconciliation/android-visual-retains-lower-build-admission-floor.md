status: open; source-audited, no execution
origin: 2026-09-14 upstream pr249 reconciliation into bounded delivery
area: android visual host memory admission

`python/nexus_test_control/android_visual.py:92` retains a 2048 mib floor; its
actual build admission at 500 accepts that value. `runner.py:401–426` does not
include android-visual in the outer memory-admitted capabilities, and its visual
adapter calls this module directly. therefore the public visual path can launch
a next build below upstream's raised 3584 mib host-safety floor. invocation-lock
ownership does not supply the missing memory threshold.

align the existing visual gate's local constant with the reviewed host floor;
no new state or scheduling owner. preserve its same physical available-memory
probe and fail-closed behavior. draft: android-visual-floor.patch. an alternative
shared-policy move needs independent review, not a broad admission refactor.

acceptance: reviewed source requires 3584 mib before visual build; execute the
existing visual/controller checks through scripts/test. the retained linux and
darwin parser cases continue asserting independently calculated bytes, even when
the calculated value is below the admission floor. no device or capacity claim.
