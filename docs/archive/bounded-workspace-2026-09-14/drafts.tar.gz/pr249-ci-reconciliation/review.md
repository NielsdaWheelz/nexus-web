# pr249 ci/build reconciliation

status: drafted only; no test execution or main/ref/index mutation
base: daa922; delivery: 5d687cdc8a9e1a9b2a0106d0e136df4537c281d7
known incoming: 5c043b17733b71ad59754015b17bc6acb19f4902

051a57b780 was absent during this audit. the draft therefore represents the
known six-commit branch delta, not an assertion about an uninspected merge tree.

resolution.patch contains only eight upstream-touched paths. generated web
cleanup is copied exactly from upstream: validated runner-owned checkout,
ignored exact .next, no symlink/mount target, and postcondition. setup invokes
it before dependency installation. both ci jobs retain existing runtime cleanup,
then generated-build cleanup, evidence staging cleanup, and result enforcement;
each independent finalizer retains always semantics. no cache pruning is added.

kotlin compilation moves into the owned gradle process. upstream's 3584 mib host
launch floor replaces 2048 mib, including its three literal fixture updates and
recorded memory rationale. darwin pressure/free-file-page semantics, the 8192 mib
storage floor, invocation ownership, source-scope/reader/worker profiles, reporter,
and all delivery tool/dependency setup are preserved. this is not a new reader
memory qualification.

three textual conflicts are explicitly resolved: ci terminal append order;
linux/darwin documentation plus new floor; and the new kotlin policy test beside
the current runner tests. no delivery test body is deleted by the resolution.
all python candidates parse; this is syntax inspection, not execution evidence.

fixture-alignment.patch is separate and requires independent review. the
existing ci recovery proof still described pre-delivery direct commands and
forbade --reinstall. it now asserts the exact current changed/pr branches,
evidence-wrapper full command, hosted-only checkout cleanup and locked cache
rehydration. original pull-request identity/merge, authority, prior/current runtime
retirement, safe paths and cache ownership assertions remain. upstream's new
generated-build cases remain byte-for-byte unchanged.

the register and fault manifest are untouched. the affected runner fault's exact
canonical case is unchanged; no coherent owner pin is proposed. after merge,
execute the existing ci recovery, artifact-wrapper and affected runner owners
through ./scripts/test, then the enclosing static gate. no upstream or local run
is inferred green from this read-only audit.
