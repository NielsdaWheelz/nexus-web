from pathlib import Path
import hashlib,json,difflib
root=Path('/home/niels/src/personal/nexus-web-bounded-workspace')
out=Path('/tmp/pytest-primary-evidence-draft')
changes={}
p='python/nexus_test_control/runner.py'
a=(root/p).read_text();b=a
b=b.replace('    redact_text,\n','    redact_json,\n    redact_text,\n',1)
b=b.replace('from nexus_test_control.process import run_command\n','from nexus_test_control.process import run_command\nfrom nexus_test_control.pytest_report import PYTEST_FAILURE_MARKER, read_pytest_failures\n',1)
b=b.replace('retain_stdout_markers=retained_stdout_markers,','retain_stdout_markers=(\n                    (*retained_stdout_markers, PYTEST_FAILURE_MARKER)\n                    if "pytest" in argv\n                    else retained_stdout_markers\n                ),',1)
b=b.replace('_command_result_detail(index, completed, interrupted_by),','_command_result_detail(\n                        index, completed, interrupted_by, pytest_command="pytest" in argv\n                    ),',1)
needle='''    interrupted_by: signal.Signals | None = None,
) -> str:
    stdout = _decisive_output'''
replacement='''    interrupted_by: signal.Signals | None = None,
    *,
    pytest_command: bool = False,
) -> str:
    if pytest_command and interrupted_by is None:
        try:
            failures = read_pytest_failures(completed.stdout or "")
        except ValueError as error:
            return (
                "proof_result=setup_or_execution_failure|"
                f"fixed command {index} exited {completed.returncode}: {error}"
            )
        behavioral = all(
            failure.phase == "call"
            and failure.assertion
            and not failure.truncated
            and not _is_timeout_failure(
                f"{failure.exception_type}: {failure.message}".casefold()
            )
            for failure in failures
        )
        kind = "behavioral_assertion_failure" if behavioral else "setup_or_execution_failure"
        observed = " | ".join(
            f"{failure.phase} {failure.exception_type}: {failure.message} "
            f"at {failure.frame}:{failure.line} ({failure.node})"
            + (" [truncated evidence]" if failure.truncated else "")
            for failure in failures
        )
        return (
            f"proof_result={kind}|fixed command {index} exited {completed.returncode}: {observed}"
        )
    stdout = _decisive_output'''
assert needle in b;b=b.replace(needle,replacement,1)
needle='''    artifacts = [relative.as_posix()]
    if capability in {'''
replacement='''    artifacts = [relative.as_posix()]
    if "pytest" in argv:
        try:
            failures = read_pytest_failures(completed.stdout or "")
        except ValueError:
            pass  # The bounded raw log retains malformed or absent evidence.
        else:
            report_relative = relative.with_suffix(".pytest.json")
            write_evidence_json(
                directory / report_relative.name,
                {
                    "failures": redact_json(
                        [failure.as_json() for failure in failures],
                        environment_secrets(environment),
                    )
                },
            )
            artifacts.append(report_relative.as_posix())
    if capability in {'''
assert needle in b;b=b.replace(needle,replacement,1);changes[p]=(a,b)
p='python/tests/conftest.py';a=(root/p).read_text();b=a.replace('\n\n@pytest.fixture(autouse=True)','\n\npytest_plugins = ("nexus_test_control.pytest_report",)\n\n\n@pytest.fixture(autouse=True)',1);changes[p]=(a,b)
p='python/nexus_test_control/sensitivity.py';a=(root/p).read_text();b=a.replace('"python/nexus_test_control/provider_api_contract.py",','"python/nexus_test_control/provider_api_contract.py",\n                "python/nexus_test_control/pytest_report.py",',1);changes[p]=(a,b)
p='python/nexus_test_control/pytest_report.py';changes[p]=('',(out/'pytest_report.py').read_text())
for p,(a,b) in changes.items():
 destination=out/p;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_text(b)
(out/'preimages.json').write_text(json.dumps({p:hashlib.sha256(a.encode()).hexdigest() for p,(a,b) in changes.items()},indent=2)+'\n')
(out/'product.patch').write_text(''.join(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p,(a,b) in changes.items()))
print(out/'product.patch')
