from pathlib import Path
import difflib, hashlib, json
r=Path('/home/niels/src/personal/nexus-web-bounded-workspace'); d=Path('/tmp/pytest-primary-evidence-draft')
(d/'pytest_report.py').write_text((d/'python/nexus_test_control/pytest_report.py').read_text())
(d/'python/tests/kernel/nexus_test_control/test_pytest_report.py').write_text((d/'test_pytest_report.py').read_text())
paths=['python/nexus_test_control/runner.py','python/nexus_test_control/sensitivity.py','python/tests/conftest.py','python/nexus_test_control/pytest_report.py','python/nexus_test_control/redaction.py','python/nexus_test_control/cli.py']
patch=''; inventory=[]
for p in paths:
 a=(r/p).read_text() if (r/p).exists() else ''
 b=(d/p).read_text()
 patch+=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 inventory.append({'path':p,'pre_sha256':hashlib.sha256(a.encode()).hexdigest(),'candidate_sha256':hashlib.sha256(b.encode()).hexdigest()})
(d/'product.patch').write_text(patch)
(d/'preimages.json').write_text(json.dumps(inventory,indent=2)+'\n')
s=(d/'test_pytest_report.py').read_text()
(d/'proof.patch').write_text(''.join(difflib.unified_diff([],s.splitlines(True),fromfile='/dev/null',tofile='b/python/tests/kernel/nexus_test_control/test_pytest_report.py')))
for path in ('product.patch','proof.patch'):
 print(path,hashlib.sha256((d/path).read_bytes()).hexdigest())
