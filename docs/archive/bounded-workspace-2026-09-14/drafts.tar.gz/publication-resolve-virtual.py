from pathlib import Path
import subprocess
root=Path('/home/niels/src/personal/nexus-web-bounded-workspace'); review=Path('/tmp/publication-merge-review')
def choose(text, selections):
    for side in selections:
        start=text.index('<<<<<<< '); a=text.index('\n',start)+1; b=text.index('||||||| ',a); c=text.index('=======\n',b)+8; d=text.index('>>>>>>> ',c); end=text.index('\n',d)+1
        text=text[:start]+(text[a:b] if side=='ours' else text[c:d])+text[end:]
    assert '<<<<<<< ' not in text
    return text
for path,selections in [('python/nexus/services/media.py',['theirs','ours']),('python/tests/service/test_bounded_media_extraction.py',['theirs'])]:
    base=review/path
    virtual=choose(base.with_name(base.name+'.rollback-removal.merged').read_text(),selections)
    base.with_name(base.name+'.virtual-resolved').write_text(virtual)
    files=[]
    for label,ref in [('head','8c0ab400'),('base','7fa89b88c8')]:
        dest=base.with_name(base.name+'.'+label)
        dest.write_bytes(subprocess.check_output(['git','show',f'{ref}:{path}'],cwd=root));files.append(dest)
    files.append(base.with_name(base.name+'.virtual-resolved'))
    result=subprocess.run(['git','merge-file','-p','--diff3','-L','delivery','-L','base','-L','reconstructed upstream',*map(str,files)],capture_output=True,cwd=root)
    (root/path).write_bytes(result.stdout)
    print(path,result.returncode)
