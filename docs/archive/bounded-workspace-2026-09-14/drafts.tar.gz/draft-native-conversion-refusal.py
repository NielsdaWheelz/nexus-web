from pathlib import Path
import difflib,hashlib,json
root=Path('/home/niels/src/personal/nexus-web-bounded-native-proof')
out=Path('/tmp/native-conversion-refusal-draft');out.mkdir(exist_ok=True)
files={}
def edit(name,fn):
 p=root/name;s=p.read_text();t=fn(s);assert t!=s,name;f=out/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(t);files[name]={'base_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'draft_sha256':hashlib.sha256(f.read_bytes()).hexdigest()};(out/(p.name+'.diff')).write_text(''.join(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
base='apps/android/app/src/main/java/app/nexus/android/offline/reading/'
edit(base+'OfflineReadingDatabase.kt',lambda s:s.replace('                table_index_sha256 TEXT,','                table_index_sha256 TEXT,\n                conversion_refusal TEXT,'))
def models(s):
 s=s.replace('internal data class OfflineReadingPackage(','internal enum class OfflineReadingConversionRefusal { GraphemeExceedsUnitCapacity }\n\ninternal data class OfflineReadingPackage(',1)
 s=s.replace('    val tableIndexSha256: String?,\n)','    val tableIndexSha256: String?,\n    val conversionRefusal: OfflineReadingConversionRefusal? = null,\n)',1)
 s=s.replace('    data object UpgradeRequired : OfflineReadingAvailability','''    data object UpgradeRequired : OfflineReadingAvailability

    data object UpgradeBlockedByStorage : OfflineReadingAvailability

    /** An established limitation of this converter, not a verdict that source bytes are invalid. */
    data object UpgradeFailed : OfflineReadingAvailability''',1)
 s=s.replace('availability is OfflineReadingAvailability.UpgradeRequired\n','availability is OfflineReadingAvailability.UpgradeRequired ||\n                    availability is OfflineReadingAvailability.UpgradeBlockedByStorage ||\n                    availability is OfflineReadingAvailability.UpgradeFailed\n',1)
 return s
edit(base+'OfflineReadingModels.kt',models)
def units(s):
 s=s.replace('/** Convert original fragments','''/** Only thrown after proving an original complete grapheme exceeds the full unit budget. */
internal class OfflineReadingGraphemeCapacityException : Exception("original grapheme exceeds the current publication unit capacity")

/** Convert original fragments''',1)
 a='''                            require(cut > sourcePosition && cut < chosen.crop.end) { "canonical grapheme exceeds publication capacity" }'''
 b='''                            if (cut <= sourcePosition || cut >= chosen.crop.end) {
                                // A failed source mapping alone is a defect. Prove the
                                // separate limitation against the original complete ICU
                                // grapheme and the FULL unit budget, not this crop's space.
                                val atomEnd = graphemes.following(boundary)
                                check(atomEnd > boundary)
                                var atomPosition = boundary
                                var atomCodePoints = 0
                                while (atomPosition < atomEnd && atomCodePoints <= OFFLINE_READING_MAX_UNIT_CODEPOINTS) {
                                    val first = text.characterAt(atomPosition++)
                                    if (first.isHighSurrogate() && atomPosition < atomEnd && text.characterAt(atomPosition).isLowSurrogate()) atomPosition += 1
                                    atomCodePoints += 1
                                }
                                if (atomCodePoints > OFFLINE_READING_MAX_UNIT_CODEPOINTS) throw OfflineReadingGraphemeCapacityException()
                            }
                            require(cut > sourcePosition && cut < chosen.crop.end) { "canonical grapheme exceeds publication capacity" }'''
 assert s.count(a)==1;return s.replace(a,b,1)
edit(base+'OfflineReadingLegacyUnits.kt',units)
def store(s):
 s=s.replace('import android.database.sqlite.SQLiteDatabase\n','import android.database.sqlite.SQLiteDatabase\nimport android.database.sqlite.SQLiteFullException\nimport android.database.sqlite.SQLiteDiskIOException\n')
 s=s.replace('    private data class ReconciledPackage(val installed: OfflineReadingPackage, val prepared: Boolean)','''    private sealed interface PackageReadiness {
        data object Prepared : PackageReadiness
        data object ConversionRequired : PackageReadiness
        data object StorageBlocked : PackageReadiness
        data class Limited(val refusal: OfflineReadingConversionRefusal) : PackageReadiness
    }
    private data class ReconciledPackage(val installed: OfflineReadingPackage, val readiness: PackageReadiness)''')
 s=s.replace('''            readPackage(binding.bindingId, mediaId)?.let { verifiedPackages[it.id]?.prepared != true } == true''','''            val installed = readPackage(binding.bindingId, mediaId)
            if (installed != null && verifiedPackages[installed.id]?.readiness != PackageReadiness.Prepared) {
                if (installed.conversionRefusal != null) {
                    val values = ContentValues().apply { putNull("conversion_refusal") }
                    check(database.writableDatabase.update("offline_reader_packages", values, "id = ?", arrayOf(installed.id.toString())) == 1)
                }
                true
            } else false''')
 s=s.replace('ReconciledPackage(installed, true)','ReconciledPackage(installed, PackageReadiness.Prepared)').replace('ReconciledPackage(activated, true)','ReconciledPackage(activated, PackageReadiness.Prepared)')
 s=s.replace('val ready = mutableSetOf<UUID>()','val readiness = mutableMapOf<UUID, PackageReadiness>()',1)
 s=s.replace('''                    if (!valid) continue
                    try {''','''                    if (!valid) continue
                    if (installed.conversionRefusal != null) {
                        readiness[installed.id] = PackageReadiness.Limited(installed.conversionRefusal)
                        continue
                    }
                    try {''',1)
 s=s.replace('ready += installed.id','readiness[installed.id] = PackageReadiness.Prepared',1)
 # The observed preflight is owned by the same local row result, never a second global set.
 s=s.replace('''                            android.util.Log.e(
                                "OfflineReading",
                                "insufficient storage''','''                            readiness[installed.id] = PackageReadiness.StorageBlocked
                            android.util.Log.e(
                                "OfflineReading",
                                "insufficient storage''',1)
 a='''                    } catch (error: Exception) {
                        // Conversion is retryable local work. It cannot revoke the
                        // attested original or acknowledge any pending progress.
                        android.util.Log.e("OfflineReading", "local package conversion failed", error)
                    }'''
 b='''                    } catch (_: OfflineReadingGraphemeCapacityException) {
                        readiness[installed.id] = PackageReadiness.Limited(OfflineReadingConversionRefusal.GraphemeExceedsUnitCapacity)
                    } catch (error: Exception) {
                        if (error !is IOException && error !is SQLiteFullException && error !is SQLiteDiskIOException) throw error
                        // Resource failures preserve source and progress; the next
                        // reconciliation may retry. Invariant/parser failures propagate.
                        android.util.Log.e("OfflineReading", "local package conversion could not access its storage", error)
                    }'''
 assert s.count(a)==1;s=s.replace(a,b)
 s=s.replace('ReconciledPackage(retained, prepared)','ReconciledPackage(retained, if (prepared) PackageReadiness.Prepared else PackageReadiness.ConversionRequired)')
 a='''                            } else verifiedPackages[installed.id] = ReconciledPackage(installed, installed.id in ready)'''
 b='''                            } else {
                                val result = readiness[installed.id] ?: PackageReadiness.ConversionRequired
                                val retained = if (result is PackageReadiness.Limited && installed.conversionRefusal != result.refusal) {
                                    val values = ContentValues().apply { put("conversion_refusal", result.refusal.name) }
                                    check(database.writableDatabase.update("offline_reader_packages", values, "id = ?", arrayOf(installed.id.toString())) == 1)
                                    installed.copy(conversionRefusal = result.refusal)
                                } else installed
                                verifiedPackages[installed.id] = ReconciledPackage(retained, result)
                            }'''
 assert s.count(a)==1;s=s.replace(a,b)
 s=s.replace('''        } catch (_: Exception) {
            // Fail closed. A later foreground/unlock reconciliation may safely retry.
        } finally {''','''        } catch (error: Exception) {
            if (error !is IOException && error !is SQLiteFullException && error !is SQLiteDiskIOException &&
                error !is OfflineReadingBindingSealLockedException) throw error
            // External resource deferral retains the existing closed exposure.
            android.util.Log.e("OfflineReading", "reconciliation could not access its storage", error)
        } finally {''',1)
 s=s.replace('''                put("table_index_sha256", prepared.tableIndexSha256)
            }
            check(update''','''                put("table_index_sha256", prepared.tableIndexSha256)
                putNull("conversion_refusal")
            }
            check(update''',1)
 s=s.replace('''                   package_schema_version, reader_contract_version, minimum_bundle_version, table_index_sha256
            FROM''','''                   package_schema_version, reader_contract_version, minimum_bundle_version, table_index_sha256, conversion_refusal
            FROM''',1)
 s=s.replace('''                    cursor.getString(cursor.getColumnIndexOrThrow("table_index_sha256")),
                )''','''                    cursor.getString(cursor.getColumnIndexOrThrow("table_index_sha256")),
                    cursor.getString(cursor.getColumnIndexOrThrow("conversion_refusal"))?.let(OfflineReadingConversionRefusal::valueOf),
                )''',1)
 s=s.replace('''                } else if (verifiedPackages[installed.id]?.prepared != true) {
                    OfflineReadingAvailability.UpgradeRequired''','''                } else if (installed.conversionRefusal != null) {
                    OfflineReadingAvailability.UpgradeFailed
                } else if (verifiedPackages[installed.id]?.readiness == PackageReadiness.StorageBlocked) {
                    OfflineReadingAvailability.UpgradeBlockedByStorage
                } else if (verifiedPackages[installed.id]?.readiness != PackageReadiness.Prepared) {
                    OfflineReadingAvailability.UpgradeRequired''',1)
 assert '.prepared' not in s
 return s
edit(base+'OfflineReadingStore.kt',store)
edit('apps/android/app/src/main/java/app/nexus/android/offline/readingweb/OfflineReadingWebCapability.kt',lambda s:s.replace('        OfflineReadingAvailability.UpgradeRequired -> outcome("UpgradeRequired")','        OfflineReadingAvailability.UpgradeRequired -> outcome("UpgradeRequired")\n        OfflineReadingAvailability.UpgradeBlockedByStorage -> outcome("UpgradeBlockedByStorage")\n        OfflineReadingAvailability.UpgradeFailed -> outcome("UpgradeFailed")',1))
# Existing original-source fixture gains independently supplied canonical text;
# the default and all previous source/pending cases stay byte-identical.
fixture='apps/android/app/src/test/java/app/nexus/android/offline/reading/InstalledLegacyReadingFixture.kt'
edit(fixture,lambda s:s.replace('html: String = "<p>reader text</p>")','html: String = "<p>reader text</p>", canonical: String = "reader text")',1).replace('.put("canonicalText", "reader text")','.put("canonicalText", canonical)',1).replace('?, ?, NULL)"','?, ?, NULL, NULL)"',1))
edit('apps/android/app/src/test/java/app/nexus/android/offline/reading/OfflineReadingTablePreparationTest.kt',lambda s:s.replace("'WebArticle', ?, 7, ?, 2, 1, 2, ?, ?, ?)\"","'WebArticle', ?, 7, ?, 2, 1, 2, ?, ?, ?, NULL)\"",1))
(out/'inventory.json').write_text(json.dumps({'base_commit':'06d85d87dd','files':files},indent=2)+'\n')
print(json.dumps(files,indent=2))
