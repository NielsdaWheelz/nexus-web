from pathlib import Path
import json,hashlib,difflib
base=Path('/tmp/native-conversion-refusal-draft');out=Path('/tmp/native-reconcile-job-entry-draft')
p='apps/android/app/src/main/java/app/nexus/android/offline/reading/OfflineReadingStore.kt'
s=(out/p).read_text()
a=s.index('        integrityExecutor.execute {',s.index('    internal fun reconcileForJob('))
b=s.index('\n    /**',a)
s=s[:a]+'''        integrityExecutor.execute {
            val outcome = synchronized(this) {
                // A run may have been claimed after this inspection was queued.
                if (reconciliationRunning) {
                    reconciliationClaimedByJob = true
                    reconciliationCallbacks += callback
                    return@execute
                }
                try {
                    if (reconciliationComplete && !bindingLocked && readAccountTransition() == null) {
                        OfflineReadingReconciliationOutcome.Ready(snapshot())
                    } else {
                        reconciliationClaimedByJob = true
                        null
                    }
                } catch (error: Exception) {
                    // Fail this inspection before another caller can claim a new run.
                    bindingLocked = true
                    reconciliationComplete = false
                    verifiedPackages.clear()
                    android.util.Log.e("OfflineReading", "job reconciliation inspection failed", error)
                    OfflineReadingReconciliationOutcome.Failed(error)
                }
            }
            if (outcome == null) {
                requestReconciliation(callback)
                return@execute
            }
            try {
                callback(outcome)
            } catch (error: Exception) {
                android.util.Log.e("OfflineReading", "reconciliation callback failed", error)
            }
        }
    }
'''+s[b:]
(out/p).write_text(s)
p='apps/android/app/src/test/java/app/nexus/android/offline/reading/OfflineReadingLegacyActivationTest.kt'
s=(out/p).read_text()
old='''            var failed: OfflineReadingReconciliationOutcome? = null
            store.reconcileAsync { failed = it }
            assertTrue("failed initial notification orphaned the reconciliation owner", failed is OfflineReadingReconciliationOutcome.Failed)
'''
new='''            var failed: OfflineReadingReconciliationOutcome? = null
            var synchronousFailure: Exception? = null
            try {
                store.reconcileAsync { failed = it }
            } catch (error: Exception) {
                synchronousFailure = error
            }
            assertNull("initial store read escaped its owned reconciliation boundary", synchronousFailure)
            assertTrue("failed initial notification orphaned the reconciliation owner", failed is OfflineReadingReconciliationOutcome.Failed)
'''
assert s.count(old)==1;s=s.replace(old,new);(out/p).write_text(s)
inv=json.loads((out/'inventory.json').read_text())
for p in inv:
 before=(base/p).read_text();after=(out/p).read_text()
 diff='diff --git a/'+p+' b/'+p+'\n'+''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 (out/(Path(p).name+'.diff')).write_text(diff)
 inv[p]['draft_sha256']=hashlib.sha256(after.encode()).hexdigest()
(out/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
print(json.dumps(inv,indent=2))
