import json,pathlib
D=json.load(open('/tmp/bounded-registry-merge-inputs.json'))
missing=object();conflicts=[]
def merge(a,b,c,path):
 if a==c:return a
 if a==b:return c
 if c==b:return a
 if all(isinstance(x,dict) for x in (a,b,c)):
  out={}
  for k in dict.fromkeys([*a,*c,*b]):
   value=merge(a.get(k,missing),b.get(k,missing),c.get(k,missing),path+'/'+k)
   if value is not missing:out[k]=value
  return out
 if all(isinstance(x,list) for x in (a,b,c)):
  if all(isinstance(x,str) for x in a+b+c):return [x for x in dict.fromkeys(a+c) if x not in b or (x in a and x in c)]
  key='id' if (a or c or b)[0].get('id') else 'path'
  A={x[key]:x for x in a};B={x[key]:x for x in b};C={x[key]:x for x in c}
  out=[]
  for k in dict.fromkeys([*A,*C,*B]):
   value=merge(A.get(k,missing),B.get(k,missing),C.get(k,missing),path+'/'+k)
   if value is not missing:out.append(value)
  return out
 conflicts.append(dict(path=path,left=None if a is missing else a,base=None if b is missing else b,right=None if c is missing else c))
 return a
out={}
for p,d in D.items():
 inverse=merge(d['prior'],d['rollback'],d['upstream'],p+':inverse')
 out[p]=merge(d['head'],d['base'],inverse,p+':delivery')
root=pathlib.Path('/tmp/bounded-registry-resolved-draft');root.mkdir(exist_ok=True)
for p,d in out.items():
 target=root/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(json.dumps(d,indent=2)+'\n')
(root/'conflicts.json').write_text(json.dumps(conflicts,indent=2)+'\n')
print('conflicts',json.dumps(conflicts,indent=2))
for p,d in out.items():
 for key in d:
  if key=='version':continue
  ident='path' if key=='artifacts' else 'id';before={x[ident] for x in D[p]['head'][key]};added=[x for x in d[key] if x[ident] not in before]
  print(p,key,'count',len(d[key]),'added',json.dumps(added,indent=2))
