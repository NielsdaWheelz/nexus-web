"""Cloudflare R2 storage client."""

import time
from abc import ABC, abstractmethod
from collections.abc import Generator
from dataclasses import dataclass
from datetime import datetime
from typing import BinaryIO

import boto3
from botocore.client import BaseClient, Config
from botocore.exceptions import BotoCoreError, ClientError

from nexus.config import get_settings


@dataclass(frozen=True)
class SignedUpload:
    """Signed direct-upload URL for a storage path."""

    path: str
    upload_url: str


@dataclass(frozen=True)
class ObjectMetadata:
    """Storage object metadata.

    Metadata is advisory. The reliable existence signal is None vs not-None
    from head_object().
    """

    content_type: str
    size_bytes: int


@dataclass(frozen=True)
class StorageObjectEntry:
    """One listed object: its path, last-modified time, and size."""

    path: str
    last_modified: datetime
    size_bytes: int


@dataclass(frozen=True)
class ObjectPage:
    """One page of a prefix listing plus the token to fetch the next page."""

    objects: tuple[StorageObjectEntry, ...]
    next_continuation_token: str | None


class StorageClientBase(ABC):
    """Storage operations used by services and tasks."""

    @abstractmethod
    def sign_upload(
        self,
        path: str,
        *,
        content_type: str,
        size_bytes: int,
        expires_in: int = 300,
    ) -> SignedUpload:
        """Create a signed URL for browser direct upload."""
        ...

    @abstractmethod
    def sign_download(
        self,
        path: str,
        *,
        expires_in: int = 300,
    ) -> str:
        """Create a signed URL for downloading an object."""
        ...

    @abstractmethod
    def head_object(self, path: str) -> ObjectMetadata | None:
        """Return object metadata, or None when the object is missing."""
        ...

    @abstractmethod
    def stream_object(
        self, path: str, *, chunk_bytes: int = 8 * 1024 * 1024
    ) -> Generator[bytes, None, None]:
        """Own one SDK body, yielding at most chunk_bytes until exhausted or closed."""
        ...

    @abstractmethod
    def stream_object_range(
        self,
        path: str,
        *,
        start: int,
        end_inclusive: int,
        chunk_bytes: int = 8 * 1024 * 1024,
    ) -> Generator[bytes, None, None]:
        """Own one SDK body for an inclusive range; close it on exhaustion or close()."""
        ...

    @abstractmethod
    def put_object(
        self,
        path: str,
        content: bytes,
        content_type: str = "application/octet-stream",
    ) -> None:
        """Upload bytes to an object path."""
        ...

    @abstractmethod
    def put_object_stream(
        self,
        path: str,
        content: BinaryIO,
        content_type: str = "application/octet-stream",
    ) -> None:
        """Upload streamed bytes to an object path."""
        ...

    @abstractmethod
    def copy_object(self, source_path: str, destination_path: str) -> None:
        """Copy one object to another path inside the same bucket."""
        ...

    @abstractmethod
    def delete_object(self, path: str) -> None:
        """Delete an object path."""
        ...

    @abstractmethod
    def list_objects(
        self,
        prefix: str,
        *,
        continuation_token: str | None = None,
    ) -> ObjectPage:
        """List one page of objects under a prefix, in listing order."""
        ...


_PUT_OBJECT_ATTEMPTS = 3


class StorageError(Exception):
    """Storage operation error."""

    def __init__(self, message: str, code: str = "E_STORAGE_ERROR"):
        super().__init__(message)
        self.message = message
        self.code = code


class StorageClient(StorageClientBase):
    """Cloudflare R2 client using the S3-compatible API."""

    def __init__(
        self,
        endpoint_url: str,
        access_key_id: str,
        secret_access_key: str,
        bucket: str,
        region: str = "auto",
        s3_client: BaseClient | None = None,
    ):
        self._bucket = bucket
        self._client = s3_client or boto3.client(
            "s3",
            endpoint_url=endpoint_url.rstrip("/"),
            aws_access_key_id=access_key_id,
            aws_secret_access_key=secret_access_key,
            region_name=region,
            config=Config(
                signature_version="s3v4",
                s3={"addressing_style": "path"},
                request_checksum_calculation="when_required",
                response_checksum_validation="when_required",
                connect_timeout=get_settings().r2_connect_timeout_seconds,
                read_timeout=get_settings().r2_read_timeout_seconds,
            ),
        )

    def sign_upload(
        self,
        path: str,
        *,
        content_type: str,
        size_bytes: int,
        expires_in: int = 300,
    ) -> SignedUpload:
        try:
            upload_url = self._client.generate_presigned_url(
                "put_object",
                Params={
                    "Bucket": self._bucket,
                    "Key": path,
                    "ContentType": content_type,
                    "ContentLength": int(size_bytes),
                },
                ExpiresIn=expires_in,
                HttpMethod="PUT",
            )
        except (BotoCoreError, ClientError) as exc:
            raise StorageError(f"Failed to sign upload for {path}") from exc
        return SignedUpload(path=path, upload_url=upload_url)

    def sign_download(
        self,
        path: str,
        *,
        expires_in: int = 300,
    ) -> str:
        try:
            return self._client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self._bucket, "Key": path},
                ExpiresIn=expires_in,
                HttpMethod="GET",
            )
        except (BotoCoreError, ClientError) as exc:
            raise StorageError(f"Failed to sign download for {path}") from exc

    def head_object(self, path: str) -> ObjectMetadata | None:
        try:
            response = self._client.head_object(Bucket=self._bucket, Key=path)
        except ClientError as exc:
            if _client_error_is_missing(exc):
                return None
            raise StorageError(f"Failed to read object metadata for {path}") from exc
        except BotoCoreError as exc:
            raise StorageError(f"Failed to read object metadata for {path}") from exc

        return ObjectMetadata(
            content_type=str(response.get("ContentType") or "application/octet-stream"),
            size_bytes=int(response.get("ContentLength") or 0),
        )

    def stream_object(
        self, path: str, *, chunk_bytes: int = 8 * 1024 * 1024
    ) -> Generator[bytes, None, None]:
        if chunk_bytes < 1:
            raise ValueError("storage chunk size must be positive")
        try:
            response = self._client.get_object(Bucket=self._bucket, Key=path)
        except ClientError as exc:
            if _client_error_is_missing(exc):
                raise StorageError(f"Object not found: {path}", code="E_STORAGE_MISSING") from exc
            raise StorageError(f"Failed to stream object {path}") from exc
        except BotoCoreError as exc:
            raise StorageError(f"Failed to stream object {path}") from exc

        body = response["Body"]
        try:
            try:
                while chunk := body.read(chunk_bytes):
                    yield chunk
            except (BotoCoreError, ClientError, OSError) as exc:
                raise StorageError(f"Failed to stream object {path}") from exc
        finally:
            close = getattr(body, "close", None)
            if close:
                close()

    def stream_object_range(
        self,
        path: str,
        *,
        start: int,
        end_inclusive: int,
        chunk_bytes: int = 8 * 1024 * 1024,
    ) -> Generator[bytes, None, None]:
        if chunk_bytes < 1:
            raise ValueError("storage chunk size must be positive")
        if start < 0 or end_inclusive < start:
            raise ValueError("invalid inclusive object range")
        try:
            response = self._client.get_object(
                Bucket=self._bucket,
                Key=path,
                Range=f"bytes={start}-{end_inclusive}",
            )
        except ClientError as exc:
            if _client_error_is_missing(exc):
                raise StorageError(f"Object not found: {path}", code="E_STORAGE_MISSING") from exc
            raise StorageError(f"Failed to stream object range {path}") from exc
        except BotoCoreError as exc:
            raise StorageError(f"Failed to stream object range {path}") from exc

        body = response["Body"]
        remaining = end_inclusive - start + 1
        try:
            try:
                while remaining > 0:
                    chunk = body.read(min(chunk_bytes, remaining))
                    if not chunk:
                        raise StorageError("Stored object range ended before persisted metadata")
                    remaining -= len(chunk)
                    yield chunk
            except (BotoCoreError, ClientError, OSError) as exc:
                raise StorageError(f"Failed to stream object range {path}") from exc
        finally:
            close = getattr(body, "close", None)
            if close:
                close()

    def put_object(
        self,
        path: str,
        content: bytes,
        content_type: str = "application/octet-stream",
    ) -> None:
        # A whole-bytes put is idempotent, and single-request transient
        # failures have been observed terminally failing captures (one of two
        # back-to-back puts dying instantly). Bounded retry, ~0.8s worst case.
        delay_seconds = 0.2
        for attempt in range(1, _PUT_OBJECT_ATTEMPTS + 1):
            try:
                self._client.put_object(
                    Bucket=self._bucket,
                    Key=path,
                    Body=content,
                    ContentType=content_type,
                )
                return
            except (BotoCoreError, ClientError) as exc:
                if attempt == _PUT_OBJECT_ATTEMPTS:
                    raise StorageError(f"Failed to upload object {path}: {exc}") from exc
                time.sleep(delay_seconds)
                delay_seconds *= 3

    def put_object_stream(
        self,
        path: str,
        content: BinaryIO,
        content_type: str = "application/octet-stream",
    ) -> None:
        # No retry: the stream body is not replayable after a partial send.
        try:
            self._client.put_object(
                Bucket=self._bucket,
                Key=path,
                Body=content,
                ContentType=content_type,
            )
        except (BotoCoreError, ClientError) as exc:
            raise StorageError(f"Failed to upload object {path}: {exc}") from exc

    def copy_object(self, source_path: str, destination_path: str) -> None:
        try:
            self._client.copy_object(
                Bucket=self._bucket,
                Key=destination_path,
                CopySource={"Bucket": self._bucket, "Key": source_path},
            )
        except (BotoCoreError, ClientError) as exc:
            raise StorageError(
                f"Failed to copy object {source_path} to {destination_path}"
            ) from exc

    def delete_object(self, path: str) -> None:
        try:
            self._client.delete_object(Bucket=self._bucket, Key=path)
        except (BotoCoreError, ClientError) as exc:
            raise StorageError(f"Failed to delete object {path}") from exc

    def list_objects(
        self,
        prefix: str,
        *,
        continuation_token: str | None = None,
    ) -> ObjectPage:
        params: dict[str, str] = {"Bucket": self._bucket, "Prefix": prefix}
        if continuation_token is not None:
            if (
                not isinstance(continuation_token, str)
                or not continuation_token
                or continuation_token != continuation_token.strip()
            ):
                raise StorageError("Storage list request has an invalid continuation token")
            params["ContinuationToken"] = continuation_token
        try:
            response = self._client.list_objects_v2(**params)
        except (BotoCoreError, ClientError) as exc:
            raise StorageError(f"Failed to list objects under {prefix}") from exc

        objects = tuple(
            StorageObjectEntry(
                path=str(item["Key"]),
                last_modified=item["LastModified"],
                size_bytes=int(item.get("Size", 0)),
            )
            for item in response.get("Contents", [])
        )
        is_truncated = bool(response.get("IsTruncated", False))
        next_token = None
        if is_truncated:
            candidate = response.get("NextContinuationToken")
            if not isinstance(candidate, str) or not candidate or candidate != candidate.strip():
                raise StorageError("Storage listing returned an invalid next continuation token")
            if candidate == continuation_token:
                raise StorageError(
                    "Storage listing returned a non-advancing next continuation token"
                )
            next_token = candidate
        return ObjectPage(objects=objects, next_continuation_token=next_token)


def get_storage_client() -> StorageClientBase:
    settings = get_settings()
    endpoint_url = settings.r2_s3_api_origin
    access_key_id = settings.r2_access_key_id
    secret_access_key = settings.r2_secret_access_key
    bucket = settings.r2_bucket
    region = settings.r2_region or "auto"

    resolved: dict[str, str] = {}
    missing: list[str] = []
    for key, value in (
        ("R2_S3_API_ORIGIN", endpoint_url),
        ("R2_ACCESS_KEY_ID", access_key_id),
        ("R2_SECRET_ACCESS_KEY", secret_access_key),
        ("R2_BUCKET", bucket),
    ):
        if value:
            resolved[key] = value
        else:
            missing.append(key)
    if missing:
        raise StorageError(f"Missing R2 storage settings: {', '.join(missing)}")

    return StorageClient(
        endpoint_url=resolved["R2_S3_API_ORIGIN"],
        access_key_id=resolved["R2_ACCESS_KEY_ID"],
        secret_access_key=resolved["R2_SECRET_ACCESS_KEY"],
        bucket=resolved["R2_BUCKET"],
        region=region,
    )


def _client_error_is_missing(exc: ClientError) -> bool:
    response = getattr(exc, "response", {})
    error_code = str(response.get("Error", {}).get("Code") or "")
    return error_code in {"404", "NoSuchKey", "NotFound"}
