from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path('/home/niels/src/personal/nexus-web-bounded-workspace')
DRAFT = Path('/tmp/publication-asset-streaming-draft')
sources = {}

def change(path, transform):
    before = (ROOT / path).read_text()
    after = transform(before)
    assert before != after, path
    sources[path] = (before, after)

def replace(source, before, after, count=1):
    assert source.count(before) == count, (before, source.count(before))
    return source.replace(before, after)

def client(source):
    source = replace(source, 'from collections.abc import Iterator', 'from collections.abc import Generator')
    source = source.replace(') -> Iterator[bytes]:', ') -> Generator[bytes, None, None]:')
    source = replace(source, 'def stream_object(self, path: str)', 'def stream_object(self, path: str, *, chunk_bytes: int = 8 * 1024 * 1024)', 2)
    source = replace(source, '        end_inclusive: int,\n', '        end_inclusive: int,\n        chunk_bytes: int = 8 * 1024 * 1024,\n', 2)
    source = replace(source, '"""Stream object bytes in chunks."""', '"""Own one SDK body, yielding at most chunk_bytes until exhausted or closed."""')
    source = replace(source, '"""Stream one validated inclusive object-byte range."""', '"""Own one SDK body for an inclusive range; close it on exhaustion or close()."""')
    source = replace(source, '    def stream_object(self, path: str, *, chunk_bytes: int = 8 * 1024 * 1024) -> Generator[bytes, None, None]:\n        try:', '    def stream_object(self, path: str, *, chunk_bytes: int = 8 * 1024 * 1024) -> Generator[bytes, None, None]:\n        if chunk_bytes < 1:\n            raise ValueError("storage chunk size must be positive")\n        try:')
    source = replace(source, 'while chunk := body.read(8 * 1024 * 1024):', 'while chunk := body.read(chunk_bytes):')
    source = replace(source, '        if start < 0 or end_inclusive < start:', '        if chunk_bytes < 1:\n            raise ValueError("storage chunk size must be positive")\n        if start < 0 or end_inclusive < start:')
    return replace(source, 'body.read(min(8 * 1024 * 1024, remaining))', 'body.read(min(chunk_bytes, remaining))')

change('python/nexus/storage/client.py', client)
change('python/nexus/storage/read.py', lambda _: '''"""Streaming object reads with persisted-size verification."""

from collections.abc import Generator

from nexus.storage.client import StorageClientBase, StorageError


def stream_object_checked(
    storage: StorageClientBase,
    storage_path: str,
    *,
    expected_size: int,
    chunk_bytes: int = 8 * 1024 * 1024,
) -> Generator[bytes, None, None]:
    """Withhold one chunk until the next read; release the last only at exact EOF.

    Short reads are data, not EOF. Later size or storage failures interrupt a
    partially sent body; they cannot recall already emitted bytes or headers.
    """
    chunks = storage.stream_object(storage_path, chunk_bytes=chunk_bytes)
    total = 0
    pending: bytes | None = None
    try:
        for chunk in chunks:
            total += len(chunk)
            if total > expected_size:
                raise StorageError("Stored object is larger than persisted metadata")
            if pending is not None:
                yield pending
            pending = chunk
        if total != expected_size:
            raise StorageError("Stored object integrity mismatch")
        if pending is not None:
            yield pending
    finally:
        chunks.close()


def read_object_checked(
    storage: StorageClientBase,
    storage_path: str,
    *,
    expected_size: int,
) -> bytes:
    """Read complete bytes for callers that require a materialized object."""
    return b"".join(stream_object_checked(storage, storage_path, expected_size=expected_size))
''')

sources['python/nexus/api/storage_response.py'] = ('', '''"""Storage response lifetime inside the existing admitted route owner."""

from collections.abc import Generator, Mapping

import anyio
from starlette.responses import StreamingResponse
from starlette.types import Receive, Scope, Send


class StorageResponse(StreamingResponse):
    """Acquire lazily, prefetch before headers, and physically close before return.

    Callers must use an admitted route: its outer task shield and inner AnyIO
    deadline scope keep synchronous next()/close() owned through cancellation.
    """

    def __init__(
        self,
        content: Generator[bytes, None, None],
        *,
        media_type: str,
        headers: Mapping[str, str],
        status_code: int = 200,
    ) -> None:
        self._stream = content
        super().__init__(content, status_code=status_code, media_type=media_type, headers=headers)

    async def stream_response(self, send: Send) -> None:
        iterator = aiter(self.body_iterator)
        chunk = await anext(iterator, None)
        await send({"type": "http.response.start", "status": self.status_code, "headers": self.raw_headers})
        while chunk is not None:
            await send({"type": "http.response.body", "body": chunk, "more_body": True})
            del chunk
            chunk = await anext(iterator, None)
        await send({"type": "http.response.body", "body": b"", "more_body": False})

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        try:
            await super().__call__(scope, receive, send)
        finally:
            # Enter the shield before run_sync's initial cancellation checkpoint.
            with anyio.CancelScope(shield=True):
                await anyio.to_thread.run_sync(self._stream.close)
''')

def epub(source):
    source = replace(source, 'from collections.abc import Callable', 'from collections.abc import Callable, Generator')
    source = replace(source, 'from nexus.storage.read import read_object_checked', 'from nexus.storage.read import stream_object_checked')
    source = replace(source, '    data: bytes\n', '    body: Generator[bytes, None, None]\n    size_bytes: int\n')
    start = source.index('    try:\n        data = read_object_checked(')
    end = source.index('    # SVG can carry script', start)
    source = source[:start] + '''    def body() -> Generator[bytes, None, None]:
        try:
            yield from stream_object_checked(
                storage_client or get_storage_client(),
                asset_metadata.storage_path,
                expected_size=asset_metadata.size_bytes,
                chunk_bytes=64 * 1024,
            )
        except StorageError as exc:
            raise ApiError(
                ApiErrorCode.E_STORAGE_ERROR,
                "Stored EPUB asset object is missing or unreadable",
            ) from exc

''' + source[end:]
    return replace(source, '        data=data,', '        body=body(),\n        size_bytes=asset_metadata.size_bytes,')

change('python/nexus/services/epub_assets.py', epub)

def oracle(source):
    source = replace(source, 'from collections.abc import Callable, Collection', 'from collections.abc import Callable, Collection, Generator')
    source = replace(source, 'from nexus.storage.read import read_object_checked', 'from nexus.storage.read import stream_object_checked')
    source = source.replace('OraclePlateBytes', 'OraclePlateStream').replace('get_oracle_plate_bytes', 'get_oracle_plate_stream').replace('read_oracle_plate_bytes', 'read_oracle_plate_stream')
    source = replace(source, '    data: bytes\n', '    body: Generator[bytes, None, None]\n')
    start = source.index('    sc = storage_client or get_storage_client()\n', source.index('def read_oracle_plate_stream'))
    end = source.index('    return OraclePlateStream(', start)
    source = source[:start] + '''    def body() -> Generator[bytes, None, None]:
        try:
            yield from stream_object_checked(
                storage_client or get_storage_client(),
                metadata.storage_key,
                expected_size=metadata.byte_size,
                chunk_bytes=64 * 1024,
            )
        except StorageError as exc:
            logger.error(
                "oracle_plate_storage_read_failed",
                image_id=str(metadata.image_id),
                storage_key=metadata.storage_key,
                expected_size=metadata.byte_size,
                error=str(exc),
            )
            raise ApiError(
                ApiErrorCode.E_STORAGE_ERROR, "Oracle plate object is missing or unreadable"
            ) from exc
''' + source[end:]
    return replace(source, '        data=data,\n        content_type=metadata.content_type,', '        body=body(),\n        content_type=metadata.content_type,')

change('python/nexus/services/oracle_plates.py', oracle)

def asset_route(source):
    source = replace(source, 'from nexus.api.read_admission import AdmittedImageRoute', 'from nexus.api.read_admission import AdmittedImageRoute\nfrom nexus.api.storage_response import StorageResponse')
    source = replace(source, '# Both routes materialize whole image bytes in the API process, so both draw on\n# the one qualified image budget, whether the bytes come from upstream or from\n# our own object store.', '# Both routes retain the existing qualified image budget through body transfer.')
    source = replace(source, 'str(len(result.data))', 'str(result.size_bytes)')
    return replace(source, 'return Response(content=result.data, media_type=result.content_type, headers=headers)', 'return StorageResponse(result.body, media_type=result.content_type, headers=headers)')

change('python/nexus/api/routes/media_assets.py', asset_route)

def oracle_route(source):
    source = replace(source, 'from nexus.api.read_admission import AdmittedImageRoute', 'from nexus.api.read_admission import AdmittedImageRoute\nfrom nexus.api.storage_response import StorageResponse')
    source = replace(source, '# Plate reads materialize whole image bytes in the API process exactly as the\n# media image routes do, so they draw on the same qualified image budget.', '# Plate transfers retain the existing qualified image budget through body close.')
    source = replace(source, 'read_oracle_plate_bytes(metadata)', 'read_oracle_plate_stream(metadata)')
    return replace(source, '    return Response(\n        content=plate.data,', '    return StorageResponse(\n        plate.body,')

change('python/nexus/api/routes/oracle.py', oracle_route)

def members(source):
    source = replace(source, 'from fastapi.responses import JSONResponse, Response, StreamingResponse', 'from fastapi.responses import JSONResponse, Response')
    source = replace(source, 'from nexus.api.read_admission import AdmittedReadRoute', 'from nexus.api.read_admission import AdmittedReadRoute\nfrom nexus.api.storage_response import StorageResponse')
    source = replace(source, 'from nexus.storage.client import get_storage_client', 'from nexus.storage.client import get_storage_client\nfrom nexus.storage.read import stream_object_checked')
    source = source.replace('return StreamingResponse(', 'return StorageResponse(')
    source = replace(source, '                source.storage_path, start=interval.start, end_inclusive=interval.end', '                source.storage_path, start=interval.start, end_inclusive=interval.end, chunk_bytes=64 * 1024')
    return replace(source, '        storage.stream_object(source.storage_path), media_type=source.media_type, headers=headers', '        stream_object_checked(storage, source.storage_path, expected_size=source.size_bytes, chunk_bytes=64 * 1024),\n        media_type=source.media_type,\n        headers=headers')

change('python/nexus/api/routes/reader_publications.py', members)

def offline(source):
    source = replace(source, 'from fastapi.responses import JSONResponse, StreamingResponse', 'from fastapi.responses import JSONResponse')
    source = replace(source, 'from nexus.api.read_admission import AdmittedPackageTransferRoute', 'from nexus.api.read_admission import AdmittedPackageTransferRoute\nfrom nexus.api.storage_response import StorageResponse')
    source = replace(source, 'from nexus.storage.client import get_storage_client', 'from nexus.storage.client import get_storage_client\nfrom nexus.storage.read import stream_object_checked')
    source = source.replace(') -> StreamingResponse:', ') -> StorageResponse:').replace('return StreamingResponse(', 'return StorageResponse(')
    return replace(source, '        get_storage_client().stream_object(storage_path), media_type=media_type, headers=headers', '        stream_object_checked(get_storage_client(), storage_path, expected_size=archive.size_bytes, chunk_bytes=64 * 1024),\n        media_type=media_type,\n        headers=headers')

change('python/nexus/api/routes/offline_reading.py', offline)

def public(source):
    source = replace(source, 'storage.stream_object(source.storage_path),', 'storage.stream_object(source.storage_path, chunk_bytes=64 * 1024),')
    return replace(source, '                end_inclusive=byte_range.end,', '                end_inclusive=byte_range.end,\n                chunk_bytes=64 * 1024,')

change('python/nexus/services/public_resource_sharing.py', public)

inventory = []
patches = []
for path, (before, after) in sources.items():
    target = DRAFT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(after)
    inventory.append({'path': path, 'preimage_sha256': hashlib.sha256(before.encode()).hexdigest() if before else None, 'candidate_sha256': hashlib.sha256(after.encode()).hexdigest()})
    patches.append(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='a/'+path if before else '/dev/null', tofile='b/'+path)))
(DRAFT / 'inventory.json').write_text(json.dumps(inventory, indent=2)+'\n')
(DRAFT / 'product.patch').write_text(''.join(patches))
