# stored asset transfer draft

status: source/proof draft only; no execution or main integration.

## candidate boundary

the response is used only by existing admitted epub, oracle, selected-generation
member and offline-package routes. public pdf retains its current response and
gets only the smaller storage chunk argument; its route admission/close work is
owned separately by runtime. no claim of a deployed public raw-cancellation leak
follows: uvicorn's current asgi 2.3 task group differs from the 2.4 direct branch.

one lazy get; no sdk body before response entry. services retain their exact
authorization/metadata and error mapping. full-object reads use one-chunk
lookahead; initial transfer costs two reads, at most two 64 kib source chunks
plus sdk/framework state. arbitrary short reads remain data. all prior chunks
may have escaped before later corruption is known, but the last declared-length
chunk cannot escape without exact eof. ranges retain the existing inclusive
requested-range contract, without inventing whole-object digest verification.

parser/source consumers retain the 8 mib default. the public download's signed
token, source generation, persisted digest headers, range/cache/csp/304 semantics
remain unchanged. smaller chunks trade up to 128 times as many read/send/thread
steps for smaller allocations, not additional object gets. actual throughput,
worker/API peaks and accepted maximum assets still require capacity evidence.

## drafted exact proofs

- service `test_stored_asset_sends_bounded_bytes_before_reading_the_complete_object`:
  actual committed media/resource or plate row, production app and auth, real
  storage client, only boto's external get/body controlled. first asgi body must
  arrive before the complete object has been read, with exactly two 64 kib
  reads; reconstruct every byte and verify one get/one close. oracle 304 opens
  no storage; svg csp, immutable/private caching, size and content type remain.
  the proof imports no new stream owner and can run against old 318747 source.
  its named old-source red is `stored asset was fully materialized before the
  first body transfer`, not an inferred memory measurement.
- kernel `test_storage_response_requires_exact_eof_before_completing_declared_body`:
  real storage client and response, controlled sdk body; independent arbitrary
  short reads, early short/excess, exact prefix plus later excess, late short,
  late sdk failure and empty-object expectations. no success completion after
  corruption; exact one-get/close and bounded read size. this is a protocol
  oracle, not a real network or maximum-memory proof.
- same kernel owns default 8 mib preservation and explicit inclusive range,
  plus send failure closing the actual same sdk body. no owned collaborator
  is replaced.

## drafted lifetime and mapping proof before integration

the same service file now contains two more actual-route owners. the shared
fixture only inserts the exact rows already required by the original case.
all fake raw streams are wrapped by botocore's actual `StreamingBody`; storage,
response, source metadata, API and admission run unchanged. no new route mocks.

1. `test_stored_asset_retains_admission_through_held_sdk_read_and_close` holds the
   third sdk read after initial body transfer, observes the actual one-second
   deadline without cancelling the request from the test's waiter; concurrent
   image still gets 503 and a lightweight route remains responsive. release
   that exact read; hold sdk close; capacity stays occupied until close returns.
   a second parameter delivers real `http.disconnect` through production asgi
   2.3's receive channel. both gates release in finally and ownership assertions
   run after cleanup, preserving the primary observation. the original owner
   must admit a complete later request after its physical close.
2. the direct asgi 2.4 send-error kernel is separate evidence from production
   2.3 disconnect/deadline. runtime's public-file draft separately owns public
   authorization, transfer-pool composition and raw caller cancellation.
3. `test_stored_asset_initial_storage_failure_keeps_its_preheader_error` runs both
   actual asset routes with SDK `NoSuchKey` and actual five-byte object against
   six-byte metadata; only error status 500 starts, exact existing storage error
   code/message remains. short object closes once; missing object never opens a
   body. same-length byte mutation is outside the legacy size-only guarantee.
4. existing generation/account/range package/member service owners still need
   execution with the shared response. no authorization/header oracle changes.

all are unexecuted drafts. runtime's admission prerequisite still requires its
own actual red/green; no source integration or capacity qualification follows.

## proposed sensitivities

ordinary original source is the smallest eager-materialization witness for the
service owner. candidate-only eof fault moves the pending yield before the next
source read, leaving counting and source authority untouched; exact-prefix-plus-
extra case then emits the entire declared body before learning it is invalid.
separate one-line omitted-close fault should be observed by send-failure and held
close owners. no blanket coherent exception or committed injected product fault.

## source adaptation scope

the only product storage implementation is `StorageClient`; its abstract return
type now states the existing concrete generator's close contract. existing
source-only doubles receive no new keyword through their current parser calls.
do not modify their corpus or exact owner pins preemptively. if an actual shared
caller reaches a double through the checked reader, adapt that external method
to the same chunk bound with its original fault/bytes preserved.
