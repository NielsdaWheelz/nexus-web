from pathlib import Path
root=Path('/home/niels/src/personal/nexus-web-bounded-workspace')
p=root/'python/nexus/services/web_article_ingest.py'
s=p.read_text().replace('    DocumentEmbedLockSetChanged,','    prepare_document_embed_sources,')
s=s.replace('from nexus.services.document_embeds import (','from nexus.schemas.media import DocumentEmbedSource\nfrom nexus.services.document_embeds import (',1)
a=s.index('    embed_urls = [',s.index('    author_observation ='))
b=s.index('    from nexus.services.reader_publication_web import (',a)
s=s[:a]+'''    prepared_fragment_id = new_uuid7()
    occurrences, planned_existing_media_ids = prepare_document_embed_sources(
        session_factory,
        media_id=media_id,
        owner_user_id=actor_user_id,
        fence=publication_fence,
        occurrences=document_embed_artifact_occurrences(
            fragment_id=prepared_fragment_id, document_embeds=prepared.document_embeds
        ) if extract_embeds else (),
        request_id=request_id,
    )
'''+s[b:]
s=s.replace('fragments=(WebReaderFragment(prepared_fragment_id, 0, prepared),),','''fragments=(WebReaderFragment(
            prepared_fragment_id, 0, prepared,
            tuple(DocumentEmbedSource.model_validate(item.model_dump(exclude={"fragment_id"}))
                  for item in occurrences),
        ),),''',1)
a=s.index('        for _lock_set_attempt in range(3):',s.index('    with prepare_web_reader_publication('))
b=s.index('            def replace_projection(',a)
c=s.index('            try:\n                fragment_id = run_source_publication_phase(',b)
body=s[b:c]
body='\n'.join(line[4:] if line.startswith('    ') else line for line in body.split('\n'))
body=body.replace('queued_children = replace_document_embed_artifact(', 'replace_document_embed_artifact(')
x=body.index('                    occurrences=document_embed_artifact_occurrences(')
y=body.index('                    extraction_error_code=',x)
body=body[:x]+'                    occurrences=occurrences,\n'+body[y:]
x=body.index('                from nexus.services.media_source_ingest import (\n                    enqueue_accepted_source_attempt_in_transaction,')
y=body.index('            if ingest_result.title:',x)
body=body[:x]+body[y:]
bound=s.index('\n    result: dict[str, object] = {',c)
s=s[:a]+body+'''        fragment_id = run_source_publication_phase(
            session_factory=session_factory,
            label="publish_web_article_artifacts",
            fence=publication_fence,
            media_ids=tuple({media_id, *planned_existing_media_ids}),
            mutate=publish_artifacts,
        )
'''+s[bound:]
p.write_text(s)
p=root/'python/nexus/services/media_source_ingest.py'
s=p.read_text().replace('    delete_document_embed_artifacts,\n    replace_document_embed_artifact,','    delete_document_embed_artifacts,\n    prepare_document_embed_sources,\n    DocumentEmbedArtifactOccurrence,\n    replace_document_embed_artifact,',1)
s=s.replace('from nexus.services.document_embeds import (','from nexus.schemas.media import DocumentEmbedSource\nfrom nexus.services.document_embeds import (',1)
a=s.index('    from nexus.services.document_embeds import DocumentEmbedLockSetChanged',s.index('def _'))
b=s.index('    from nexus.services.reader_publication_web import (',a)
s=s[:a]+s[b:]
a=s.index('    prepared_fragment_id = new_uuid7()',a)
b=s.index('    replacement_title =',a)
s=s[:b]+'''    if attempt.created_by_user_id is None:
        raise AssertionError("stored HTML source attempt has no owner")
    occurrences, planned_existing_media_ids = prepare_document_embed_sources(
        session_factory,
        media_id=media_id,
        owner_user_id=attempt.created_by_user_id,
        fence=fence,
        occurrences=document_embed_artifact_occurrences(
            fragment_id=prepared_fragment_id, document_embeds=prepared.document_embeds
        ) if extract_embeds else (),
        request_id=request_id,
    )
'''+s[b:]
s=s.replace('fragments=(WebReaderFragment(prepared_fragment_id, 0, prepared),),','''fragments=(WebReaderFragment(
            prepared_fragment_id, 0, prepared,
            tuple(DocumentEmbedSource.model_validate(item.model_dump(exclude={"fragment_id"}))
                  for item in occurrences),
        ),),''',1)
a=s.index('        planned_existing_media_ids: set[UUID] = set()',a)
b=s.index('            def publish_html_artifacts(',a)
c=s.index('            try:\n                return run_source_publication_phase(',b)
body=s[b:c]
body='\n'.join(line[4:] if line.startswith('    ') else line for line in body.split('\n'))
body=body.replace('                    extract_embeds=extract_embeds,','                    extract_embeds=extract_embeds,\n                    occurrences=occurrences,',1)
bound=s.index('\n\ndef _replace_stored_html_projection(',c)
s=s[:a]+body+'''        return run_source_publication_phase(
            session_factory=session_factory,
            label="publish_stored_html_artifacts",
            fence=fence,
            media_ids=tuple({media_id, *planned_existing_media_ids}),
            mutate=publish_html_artifacts,
        )
'''+s[bound:]
a=s.index('def _replace_stored_html_projection(')
b=s.index('\n    replace_media_apparatus(',a)
body=s[a:b].replace('    planned_existing_media_ids: set[UUID],','    planned_existing_media_ids: frozenset[UUID],\n    occurrences: tuple[DocumentEmbedArtifactOccurrence, ...],')
body=body.replace('queued_children = replace_document_embed_artifact(', 'replace_document_embed_artifact(')
x=body.index('            occurrences=document_embed_artifact_occurrences(')
y=body.index('            extraction_error_code=',x)
body=body[:x]+'            occurrences=occurrences,\n'+body[y:]
x=body.index('        for child_media_id, child_attempt_id in queued_children:')
body=body[:x]
s=s[:a]+body+s[b:]
p.write_text(s)
