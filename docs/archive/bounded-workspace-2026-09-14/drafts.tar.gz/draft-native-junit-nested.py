from pathlib import Path
import hashlib,difflib,json
base=Path.cwd();out=Path('/tmp/native-junit-nested-draft');out.mkdir(exist_ok=True)
changes={}
p='python/nexus_test_control/runner.py';s=(base/p).read_text()
old='''            } and (f"{class_name}." in stack)
'''
new='''            } and any(
                line.lstrip().startswith((f"at {class_name}.", f"at {class_name}$"))
                for line in stack.splitlines()
            )
'''
assert s.count(old)==1;changes[p]=(s,s.replace(old,new))
p='python/tests/kernel/nexus_test_control/test_runner.py';s=(base/p).read_text()
old='''@pytest.mark.parametrize("case", ["assertion", "array", "runtime", "foreign", "stale"])
'''
new='''@pytest.mark.parametrize(
    "case",
    [
        "assertion", "array", "nested", "runtime", "nested_runtime",
        "foreign", "lookalike", "foreign_nested", "message_only", "stale",
    ],
)
'''
assert s.count(old)==1;s=s.replace(old,new)
a=s.index('def test_exact_android_host_red_requires_fresh_owned_junit_assertion(')
b=s.index('\n\ndef test_android_host_does_not_mask',a)
body=s[a:b]
body=body.replace('''        "runtime": "java.lang.IllegalStateException",
''','''        "runtime": "java.lang.IllegalStateException",
        "nested_runtime": "java.lang.IllegalStateException",
''')
needle='''    owner = "app.nexus.ForeignTest" if case == "foreign" else "app.nexus.SampleTest"
'''
replacement=needle+'''    # Kotlin suspend assertions may retain only an owned compiled closure
    # frame across the coroutine boundary, as native receipt a0c1a26c63550a55 does.
    frame_owner = {
        "nested": "app.nexus.SampleTest$source is distinct$1$2",
        "nested_runtime": "app.nexus.SampleTest$source is distinct$1$2",
        "lookalike": "app.nexus.SampleTestOther$1",
        "foreign_nested": "foreign.app.nexus.SampleTest$1",
        "message_only": "app.nexus.ForeignTest",
    }.get(case, owner)
    diagnostic = (
        "diagnostic mentions at app.nexus.SampleTest.source and app.nexus.SampleTest$1\\n"
        if case == "message_only" else ""
    )
'''
assert body.count(needle)==1;body=body.replace(needle,replacement)
body=body.replace('''        f"at {owner}.source is distinct(SampleTest.kt:23)"
''','''        f"{diagnostic}\\tat {frame_owner}.source is distinct(SampleTest.kt:23)"
''')
body=body.replace('case in {"assertion", "array"}','case in {"assertion", "array", "nested"}')
s=s[:a]+body+s[b:]
changes[p]=((base/p).read_text(),s)
inv={}
for p,(before,after) in changes.items():
 dest=out/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(after)
 diff='diff --git a/'+p+' b/'+p+'\n'+''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 (out/(Path(p).name+'.diff')).write_text(diff)
 inv[p]={'base_sha256':hashlib.sha256(before.encode()).hexdigest(),'draft_sha256':hashlib.sha256(after.encode()).hexdigest()}
(out/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
print(json.dumps(inv,indent=2))
