# residency proof reconciliation

replace only the exact proof owner with the cleaned residency snapshot. no supporting source needs copying. the only direct fixture helper, pdfFixtures.ts, is byte-identical. globals and browser setup are compared in inventory. the proof uses the real ResourceCacheProvider with READER_CAPACITY.cache; it never calls createHostedReaderSource or encodes a read allocation factor. preserve main's current provider, object-shaped source factory, capacity facts and leaf implementation.

proof delta: trusted first horizontal wheel targets ordinary pane top chrome outside the independent contextual-row overflow; the existing public iframe coordinate transform is unchanged. temporary geometry/event payload diagnostics are removed; trusted wheel/press/move booleans and all actual hidden hydration, descriptor, binary, worker, focus, drag, selection, retirement and source identity assertions remain. no extra wait or production choreography change.

ordinary detailed proof passed 34bd5ca108fc9415 at d0c00e72. current cleanup and canonical replay b8c5156e0718a1d2 at bec78439 are pending. parent owns that run and must establish its fault red/candidate green before main integration. an enclosing combined main snapshot prove remains required. this is twelve-restored-visits component evidence, not maximum pinned binary capacity or a real-stack journey.
