"""Retained package preparation, one-use transfer, and current account authority."""

from __future__ import annotations

import base64
import hashlib
import io
import json
import zipfile
from dataclasses import dataclass
from pathlib import Path
from uuid import UUID, uuid4

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import Engine, text
from sqlalchemy.orm import Session

from nexus.app import add_request_id_middleware, create_app
from nexus.auth.middleware import AuthMiddleware
from nexus.config import clear_settings_cache, get_settings, require_reader_publication_limits
from nexus.db.models import Media, MediaKind, ProcessingStatus, ReaderPublication, ReaderPublicationArtifact
from nexus.db.session import create_session_factory
from nexus.jobs.registry import get_default_registry
from nexus.jobs.worker import JobWorker
from nexus.services.bootstrap import ensure_user_and_default_library
from nexus.services.library_entries import delete_entry, ensure_media_in_default_library, media_target
from nexus.services.offline_reading_packages import verify_offline_reading_zip
from nexus.services.offline_reading_preparation import ensure_offline_package_for_viewer
from nexus.services.stream_tokens import mint_offline_reading_package_token, verify_offline_reading_package_token
from nexus.storage.client import get_storage_client
from nexus.storage.paths import build_reader_publication_member_storage_path
from tests.testkit.auth import StaticTokenVerifier

_KIND = "prepare_offline_reading_package"
_FIXTURE = Path(__file__).parents[3] / "testdata/offline-reading/retained-unicode-schema-2.zip"


@dataclass(frozen=True, slots=True)
class _ReadyArticle:
    viewer_id: UUID
    email: str
    default_library_id: UUID
    media_id: UUID
    generation: int = 7


def _commit_ready_article(engine: Engine, *, title: str) -> _ReadyArticle:
    """Frozen generation seven coexists with a replacement currently extracting."""
    viewer_id, media_id = uuid4(), uuid4()
    email = f"offline-package-{viewer_id}@example.invalid"
    with Session(engine) as db:
        library_id = ensure_user_and_default_library(db, viewer_id, email)
        db.add(Media(id=media_id, kind=MediaKind.web_article.value, title=title,
                     processing_status=ProcessingStatus.extracting, created_by_user_id=viewer_id))
        db.flush()
        ensure_media_in_default_library(db, viewer_id, media_id)
        db.add(ReaderPublication(id=uuid4(), media_id=media_id, generation=8))
        db.commit()
    storage = get_storage_client()
    with zipfile.ZipFile(_FIXTURE) as archive, Session(engine) as db:
        for key in archive.namelist():
            if key == "manifest.json":
                continue
            body = archive.read(key)
            if key == "descriptor.json":
                descriptor = json.loads(body)
                descriptor["media_id"] = str(media_id)
                body = json.dumps(descriptor, ensure_ascii=False, separators=(",", ":")).encode()
                role = "descriptor"
            elif key.startswith("index/"):
                role = "index"
            elif key.startswith("units/"):
                role = "unit"
            else:
                role = "asset"
            digest = hashlib.sha256(body).hexdigest()
            storage_path = build_reader_publication_member_storage_path(media_id, digest)
            media_type = "image/png" if role == "asset" else "application/json"
            storage.put_object(storage_path, body, media_type)
            db.add(ReaderPublicationArtifact(media_id=media_id, generation=7, path=key,
                role=role, storage_path=storage_path, media_type=media_type,
                size_bytes=len(body), sha256=digest))
        db.commit()
    return _ReadyArticle(viewer_id, email, library_id, media_id)


def _package_app(verifier: StaticTokenVerifier, *, requires_internal_header: bool = False,
                 internal_secret: str | None = None) -> FastAPI:
    app = create_app(install_auth_middleware=lambda application: application.add_middleware(
        AuthMiddleware, verifier=verifier, requires_internal_header=requires_internal_header,
        internal_secret=internal_secret, bootstrap_callback=None))
    add_request_id_middleware(app, log_requests=False)
    return app


def _prepare(engine: Engine, article: _ReadyArticle) -> UUID:
    with Session(engine) as db:
        ensure_offline_package_for_viewer(db, viewer_id=article.viewer_id,
            media_id=article.media_id, generation=article.generation)
        job_id = db.scalar(text("SELECT id FROM background_jobs WHERE kind = :kind AND payload->>'media_id' = :media"),
                           {"kind": _KIND, "media": str(article.media_id)})
        assert job_id is not None
    worker = JobWorker(session_factory=create_session_factory(engine),
        worker_id=f"offline-package-proof-{uuid4()}",
        registry={_KIND: get_default_registry()[_KIND]}, allowed_kinds=(_KIND,))
    assert worker.run_exact(job_id) is True
    with Session(engine) as db:
        row = db.execute(text("SELECT status, result, error_code, error_message FROM background_jobs WHERE id = :id"), {"id": job_id}).one()
        assert row.status == "succeeded", row
        assert row.result == {"status": "ready", "reader_generation": 7}
    return job_id


def _claimed_jtis(engine: Engine, jtis: tuple[str, ...]) -> set[str]:
    with Session(engine) as db:
        return set(db.scalars(text("SELECT jti FROM stream_token_jti_claims WHERE jti = ANY(:jtis)"), {"jtis": list(jtis)}))


def _mint(article: _ReadyArticle) -> tuple[str, str]:
    minted = mint_offline_reading_package_token(user_id=article.viewer_id,
        media_id=article.media_id, reader_generation=article.generation)
    jti = verify_offline_reading_package_token(minted.token, expected_media_id=article.media_id).jti
    return minted.token, jti


def test_direct_package_is_account_generation_integrity_and_replay_bound(engine: Engine) -> None:
    article = _commit_ready_article(engine, title="Replacement eight is extracting")
    verifier = StaticTokenVerifier(article.viewer_id, article.email)
    headers = {"Authorization": f"Bearer {verifier.token}",
               "X-Nexus-Expected-Account-Id": str(article.viewer_id)}
    mint_path = f"/internal/media/{article.media_id}/offline-reading-token"
    request = {"expected_reader_generation": 7}
    with TestClient(_package_app(verifier)) as client:
        foreign = client.post(mint_path, json=request, headers={**headers,
            "X-Nexus-Expected-Account-Id": str(uuid4())})
        assert foreign.status_code == 403, foreign.text
        with Session(engine) as db:
            assert db.scalar(text("SELECT count(*) FROM background_jobs WHERE kind = :kind AND payload->>'media_id' = :media"),
                             {"kind": _KIND, "media": str(article.media_id)}) == 0
        pending = client.post(mint_path, json=request, headers=headers)
        assert pending.status_code == 202, pending.text
        expected_status = f"/media/{article.media_id}/reader-publications/7/offline-package?schema=2"
        assert pending.json()["data"] == {"reader_generation": 7, "status_path": expected_status}
        repeated = client.post(mint_path, json=request, headers=headers)
        assert repeated.status_code == 202, repeated.text
        preparing = client.get(expected_status, headers=headers)
        assert preparing.json()["data"] == {"reader_generation": 7, "state": {"kind": "Preparing"}}
        wrong_status_account = client.get(expected_status, headers={**headers,
            "X-Nexus-Expected-Account-Id": str(uuid4())})
        assert wrong_status_account.status_code == 403
        with Session(engine) as db:
            assert db.scalar(text("SELECT count(*) FROM background_jobs WHERE kind = :kind AND payload->>'media_id' = :media"),
                             {"kind": _KIND, "media": str(article.media_id)}) == 1
            assert db.scalar(text("SELECT count(*) FROM reader_publication_artifacts WHERE media_id = :media AND role = 'archive'"),
                             {"media": article.media_id}) == 0
        _prepare(engine, article)
        ready = client.get(expected_status, headers=headers)
        assert ready.json()["data"] == {"reader_generation": 7, "state": {"kind": "Ready"}}
        binding = client.get("/internal/offline-reading/account-binding", headers=headers)
        assert binding.json()["data"] == {"account_id": str(article.viewer_id),
            "protocol_version": 1, "package_schema_version": 2,
            "reader_contract_version": 1, "minimum_reader_bundle_version": 2}
        mint = client.post(mint_path, json=request, headers=headers)
        assert mint.status_code == 200, mint.text
        minted = mint.json()["data"]
        assert minted["account_id"] == str(article.viewer_id)
        assert minted["reader_generation"] == 7
        assert minted["package_schema_version"] == 2
        direct_headers = {"Authorization": f"Bearer {minted['token']}", "Accept-Encoding": "identity"}
        path = f"/offline-reading/packages/{article.media_id}"
        # Current fragments may be replacing. Transfer must not assemble or read them.
        with Session(engine) as blocker:
            blocker.execute(text("LOCK TABLE fragments IN ACCESS EXCLUSIVE MODE"))
            response = client.get(path, headers=direct_headers)
            blocker.rollback()
        replay = client.get(path, headers=direct_headers)
    assert response.status_code == 200, response.text[:200]
    assert response.headers["content-type"] == "application/vnd.nexus.offline-reading+zip"
    assert response.headers["cache-control"] == "private, no-store, no-transform"
    assert response.headers["content-length"] == str(len(response.content))
    assert "content-encoding" not in response.headers
    assert response.headers["nexus-account-id"] == str(article.viewer_id)
    assert response.headers["nexus-reader-generation"] == "7"
    expected_digest = base64.b64encode(hashlib.sha256(response.content).digest()).decode("ascii")
    assert response.headers["content-digest"] == f"sha-256=:{expected_digest}:"
    verified = verify_offline_reading_zip(response.content, publication_limits=require_reader_publication_limits())
    assert verified.manifest.media_id == article.media_id
    assert verified.manifest.reader_generation == 7
    assert verified.manifest.title == "café 🧠 — retained seven"
    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        assert "reader.json" not in archive.namelist()
        units = [json.loads(archive.read(key)) for key in sorted(archive.namelist()) if key.startswith("units/")]
        assert "".join(unit["canonical_text"] for unit in units) == "café 🧠\ncat"
        assert len([key for key in archive.namelist() if key.startswith("assets/")]) == 1
        expanded = sum(archive.getinfo(entry.path).file_size for entry in verified.manifest.entries)
        assert response.headers["nexus-expanded-length"] == str(expanded)
    assert replay.status_code == 401, replay.text[:200]
    assert replay.json()["error"]["code"] == "E_STREAM_TOKEN_REPLAYED"
    with Session(engine) as db:
        assert db.scalar(text("SELECT generation FROM reader_publications WHERE media_id = :id"), {"id": article.media_id}) == 8
        assert db.scalar(text("SELECT count(*) FROM reader_publication_artifacts WHERE media_id = :media AND role = 'archive'"),
                         {"media": article.media_id}) == 1
