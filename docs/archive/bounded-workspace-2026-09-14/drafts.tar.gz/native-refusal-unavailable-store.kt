    @Test
    fun `failed initial store read completes its owner and permits reconciliation after recovery`() {
        val fixture = InstalledLegacyReadingFixture(temporary.newFolder())
        val original = row(fixture.database.readableDatabase, "offline_reader_packages")
        val pending = row(fixture.database.readableDatabase, "offline_reader_progress_pending")
        val baseline = row(fixture.database.readableDatabase, "offline_reader_progress_baselines")
        val databaseFile = fixture.context.getDatabasePath(fixture.databaseName)
        fixture.database.close()
        try {
            assertTrue(databaseFile.isFile)
            assertTrue(databaseFile.setReadable(false, false))
            assertFalse("controlled store read remains available", databaseFile.canRead())
            val store = OfflineReadingStore(fixture.context, database = fixture.database, seal = fixture.seal,
                rootDirectory = fixture.root, durability = HostReadingFilesystemDurability,
                integrityExecutor = Executor(Runnable::run), reconcileOnInit = false)
            var failed: OfflineReadingReconciliationOutcome? = null
            store.reconcileAsync { failed = it }
            assertTrue("failed initial notification orphaned the reconciliation owner", failed is OfflineReadingReconciliationOutcome.Failed)
            assertTrue("store read lost its SQLite cause", (failed as OfflineReadingReconciliationOutcome.Failed).cause is android.database.sqlite.SQLiteException)
            assertTrue(fixture.reader.contentEquals(File(fixture.installedDirectory, "reader.json").readBytes()))
            assertTrue(databaseFile.setReadable(true, true))
            assertTrue(databaseFile.canRead())
            assertEquals(original, row(fixture.database.readableDatabase, "offline_reader_packages"))
            var recovered: OfflineReadingReconciliationOutcome? = null
            store.reconcileAsync { recovered = it }
            assertTrue("failed initial read left reconciliation claimed after recovery", recovered is OfflineReadingReconciliationOutcome.Ready)
            assertTrue((recovered as OfflineReadingReconciliationOutcome.Ready).snapshot.items.single().availability is OfflineReadingAvailability.Ready)
            assertEquals(pending, row(fixture.database.readableDatabase, "offline_reader_progress_pending"))
            assertEquals(baseline, row(fixture.database.readableDatabase, "offline_reader_progress_baselines"))
        } finally {
            assertTrue(databaseFile.setReadable(true, true))
            fixture.close()
        }
    }

