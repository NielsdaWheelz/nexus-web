import { cdp } from "vitest/browser";

/** Actual owned Chromium processes, including workers and native allocations. */
export async function nativeBrowserMemory() {
  const session = cdp();
  // Initialize Vitest's lazy CDP connection before registering its listeners.
  await session.send("Runtime.getHeapUsage");
  const totals = new Map<number, Record<string, unknown>>();
  let finish!: () => void;
  const completed = new Promise<void>((resolve) => { finish = resolve; });
  const collect: Parameters<typeof session.on<"Tracing.dataCollected">>[1] = ({ value }) => {
    for (const event of value) if (event.ph === "v" && event.args?.dumps?.process_totals && Number.isSafeInteger(event.pid)) {
      totals.set(event.pid, event.args.dumps.process_totals);
    }
  };
  session.on("Tracing.dataCollected", collect);
  session.on("Tracing.tracingComplete", finish);
  try {
    await session.send("Tracing.start", { categories: "disabled-by-default-memory-infra", transferMode: "ReportEvents" });
    try {
      const dump = await session.send("Tracing.requestMemoryDump", { deterministic: true, levelOfDetail: "detailed" });
      if (!dump.success) throw new Error("Owned Chromium did not provide its native memory dump");
    } finally { await session.send("Tracing.end"); await completed; }
    if (totals.size === 0) throw new Error("Completed owned trace has no process memory observations");
    const processes = [];
    for (const [pid, values] of totals) {
      const footprint = values.private_footprint_bytes;
      const peak = values.peak_resident_set_size;
      if (typeof footprint !== "string" || !/^[0-9a-f]+$/i.test(footprint) || typeof peak !== "string" || !/^[0-9a-f]+$/i.test(peak)) {
        throw new Error(`Owned browser process ${pid} lacks private-footprint/high-water values`);
      }
      processes.push({ pid, privateFootprintBytes: Number.parseInt(footprint, 16), highWaterBytes: Number.parseInt(peak, 16), highWaterResettable: values.is_peak_rss_resettable });
    }
    return { processes, privateFootprintBytes: processes.reduce((sum, process) => sum + process.privateFootprintBytes, 0),
      sumHighWaterBytes: processes.reduce((sum, process) => sum + process.highWaterBytes, 0) };
  } finally {
    session.off("Tracing.dataCollected", collect);
    session.off("Tracing.tracingComplete", finish);
  }
}
