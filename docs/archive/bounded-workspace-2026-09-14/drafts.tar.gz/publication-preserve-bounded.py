from pathlib import Path
import subprocess,json
root=Path('/home/niels/src/personal/nexus-web-bounded-workspace')
paths='''python/nexus/api/routes/offline_reading.py
python/nexus/api/routes/reader.py
python/nexus/db/models.py
python/nexus/schemas/epub_find.py
python/nexus/schemas/media.py
python/nexus/schemas/offline_reading_package.py
python/nexus/schemas/reader.py
python/nexus/schemas/reader_document_map.py
python/nexus/services/canonicalize.py
python/nexus/services/consumption/_reader_cursor_store.py
python/nexus/services/content_indexing.py
python/nexus/services/epub_find.py
python/nexus/services/epub_ingest.py
python/nexus/services/epub_lifecycle.py
python/nexus/services/epub_read.py
python/nexus/services/epub_structure.py
python/nexus/services/locator_resolver.py
python/nexus/services/media_read_map.py
python/nexus/services/offline_reading_delivery.py
python/nexus/services/offline_reading_packages.py
python/nexus/services/public_resource_sharing.py
python/nexus/services/reader_connections.py
python/nexus/services/reader_document_map.py
python/nexus/services/reader_evidence_markers.py
python/nexus/services/reader_locations.py
python/nexus/services/reader_navigation.py
python/nexus/services/reader_publication.py
python/nexus/services/reader_structure.py
python/nexus/services/search/projection.py
python/nexus/services/search/retrievers/fragments.py
python/nexus/services/web_article_ingest.py
python/nexus/services/web_article_structure.py
python/nexus/services/x_ingest.py
python/tests/kernel/test_offline_reading_package_contract.py
python/tests/kernel/test_reader_document_positions.py
python/tests/migrations/test_reader_structure_migration.py
python/tests/migrations/test_web_reader_cursor_migration.py
python/tests/service/test_canonical_text_parser_equivalence.py
python/tests/service/test_epub2_doctype_entities_extraction.py
python/tests/service/test_epub_structural_anchors.py
python/tests/service/test_offline_reader_account_fence.py
python/tests/service/test_offline_reader_progress.py
python/tests/service/test_offline_reading_package_delivery.py
python/tests/service/test_reader_cursor_admission.py
python/tests/service/test_reader_document_positions.py'''.splitlines()
paths+=subprocess.check_output(['git','ls-tree','-r','--name-only','8c0ab400','migrations'],cwd=root,text=True).splitlines()
for path in paths:
    p=root/path
    source=subprocess.run(['git','show',f'8c0ab400:{path}'],cwd=root,capture_output=True)
    if source.returncode:
        if p.exists():p.unlink()
    else:
        p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(source.stdout);p.chmod(0o644)
Path('/tmp/publication-merge-review/bounded-architecture-preserved.json').write_text(json.dumps(paths,indent=2)+'\n')
print(len(paths))
