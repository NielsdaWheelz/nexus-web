    @Test
    fun `explicit retry survives an older reconciliation held in another package durability`() {
        val canonical = "reader text q" + "\u0301".repeat(65_536)
        val refused = InstalledLegacyReadingFixture(temporary.newFolder(), "<p>$canonical</p>", canonical)
        val other = InstalledLegacyReadingFixture(temporary.newFolder())
        val executor = Executors.newSingleThreadExecutor()
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val retried = CountDownLatch(1)
        var attempts = 0
        var holdOther = true
        val ownPublication = File(refused.root, "${refused.binding}/.staging/${refused.packageId}.migration/publication")
        val otherPublication = File(refused.root, "${refused.binding}/.staging/${other.packageId}.migration/publication")
        val durability = object : OfflineReadingDurability {
            override fun syncDirectory(directory: File) {
                if (directory == ownPublication) {
                    attempts += 1
                    if (attempts == 2) retried.countDown()
                }
                HostReadingFilesystemDurability.syncDirectory(directory)
            }
            override fun syncTree(directory: File) {
                if (directory == otherPublication && holdOther) {
                    holdOther = false
                    entered.countDown()
                    check(release.await(10, TimeUnit.SECONDS)) { "controlled durability was not released" }
                }
                HostReadingFilesystemDurability.syncTree(directory)
            }
        }
        try {
            val initial = OfflineReadingStore(refused.context, database = refused.database, seal = refused.seal,
                rootDirectory = refused.root, durability = durability, integrityExecutor = Executor(Runnable::run))
            assertEquals(OfflineReadingAvailability.UpgradeFailed, initial.snapshot().items.single().availability)
            assertEquals(1, attempts)
            val pending = row(refused.database.readableDatabase, "offline_reader_progress_pending")
            val baseline = row(refused.database.readableDatabase, "offline_reader_progress_baselines")
            // Add a second independently valid retained source to the same
            // installed binding. No source payload or expected text is rewritten.
            other.installedDirectory.copyRecursively(File(refused.root, "${refused.binding}/${other.packageId}"))
            refused.database.writableDatabase.transaction {
                for (table in listOf("offline_reader_packages", "offline_reader_progress_baselines", "offline_reader_progress_pending")) {
                    val values = android.content.ContentValues()
                    for ((name, value) in row(other.database.readableDatabase, table)) {
                        when {
                            name == "binding_id" -> values.put(name, refused.binding.toString())
                            value == null -> values.putNull(name)
                            else -> values.put(name, value)
                        }
                    }
                    insertOrThrow(table, null, values)
                }
            }
            val store = OfflineReadingStore(refused.context, database = refused.database, seal = refused.seal,
                rootDirectory = refused.root, durability = durability, integrityExecutor = executor,
                reconcileOnInit = false)
            OfflineReadingScheduler.runnerStarted()
            store.reconcile()
            assertTrue("second source did not reach its real durability boundary", entered.await(10, TimeUnit.SECONDS))
            // The run captured the old refusal before blocking outside the
            // store monitor. Live-runner reconciliation permits this command.
            store.retry(refused.media)
            store.retry(refused.media)
            release.countDown()
            assertTrue("explicit retry disappeared behind the active reconciliation", retried.await(10, TimeUnit.SECONDS))
            executor.submit {}.get(10, TimeUnit.SECONDS)
            assertEquals("overlapping retries did not coalesce", 2, attempts)
            val item = store.snapshot().items.single { it.mediaId == refused.media }
            assertEquals(OfflineReadingAvailability.UpgradeFailed, item.availability)
            assertTrue(store.snapshot().items.single { it.mediaId == other.media }.availability is OfflineReadingAvailability.Ready)
            for ((table, expected) in listOf("offline_reader_progress_pending" to pending, "offline_reader_progress_baselines" to baseline)) {
                refused.database.readableDatabase.rawQuery("SELECT * FROM $table WHERE media_id = ?", arrayOf(refused.media.toString())).use { cursor ->
                    assertTrue(cursor.moveToFirst())
                    val retained = cursor.columnNames.mapIndexed { index, name -> name to cursor.getString(index) }.toMap()
                    assertEquals(expected, retained)
                    assertFalse(cursor.moveToNext())
                }
            }
            assertTrue(refused.reader.contentEquals(File(refused.installedDirectory, "reader.json").readBytes()))
        } finally {
            release.countDown()
            executor.shutdownNow()
            assertTrue(executor.awaitTermination(10, TimeUnit.SECONDS))
            OfflineReadingScheduler.runnerStopped()
            refused.close()
            other.close()
        }
    }

