# selection glob reuse

status: draft only; no main edits or tests.
origin: 2026-09-14, oi-223 and ci34896942860 at dd21213.

## unchanged result

_glob_matches depends only on its path and pattern arguments. for_path now
records each distinct pattern's boolean in one local dictionary, including
false results, then retains every matching original route in the original
tuple order. it does not merge routes that share a pattern, target, or reason.
the dictionary expires on return; a later path or repeated invocation computes
its own matches. no regex semantics, source routing, priority, discovery,
sensitivity, or owner selection changes.

this adds one dictionary entry per distinct pattern and a second linear route
walk. it avoids an extra accumulated result list and preserves the existing
tuple result. there is no persistent compiled-pattern cache or invalidation
owner. errors still propagate from the same matcher at the first occurrence
of their pattern.

## source cost and observation limit

root observed ci34896942860 controller606537 above13minutes at99.9%cpu and
about108mb, before child capability/file evidence. ptrace was denied. that
observation does not identify this stack as the actual running hotspot, and it
is not a measured before/after performance result.

at dd21213 the declared21762 proof-pattern rows have702 distinct patterns. the
unfiltered2439-path upper shape is53077518 matcher invocations before this
change versus1712178 after, while both still inspect route rows. actual path
selection skips/routes some inputs differently, so these products are source
operation counts, not an observed invocation total or latency forecast.

## proof draft

one new pure case lives in the existing test_selection.py owner. five
interleaved routes share three patterns, including overlapping recursive and
single-directory globs. independent expected tuples cover python, web, nested
python and a repeated earlier path. assertions preserve exact route identity
and order. existing cases cover root/nested globs and broad routing, but do not
exercise duplicate patterns with distinct retained targets across multiple
for_path calls. this case checks that missing semantic edge only.

there is no matcher monkeypatch or call-count assertion. the pure case should
pass old and new source; source review establishes the redundant work removal,
and actual ci selection observations must establish any performance effect.
existing rename/deletion, direct-proof, manifest, generation and platform
routing cases remain unchanged. run the
existing full selector file through the paved command after review:

```sh
./scripts/test changed pytest:python/tests/kernel/nexus_test_control/test_selection.py
```

record the actual next ci/controller selection latency separately. no numeric
performance threshold, new canonical fault, registry edit or controller-wide
cache is proposed. applicability checks are not behavior evidence.
