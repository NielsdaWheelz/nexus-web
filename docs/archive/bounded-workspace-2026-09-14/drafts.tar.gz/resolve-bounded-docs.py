import pathlib, subprocess,re
repo=pathlib.Path('/home/niels/src/personal/nexus-web-bounded-workspace')
scratch=pathlib.Path('/tmp/bounded-docs-merge-sw_7s9cf')
pat=re.compile(r'^<<<<<<<[^\n]*\n(.*?)^\|\|\|\|\|\|\|[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n?',re.M|re.S)
def git(ref,p): return subprocess.check_output(['git','show',f'{ref}:{p}'],cwd=repo).decode()
def resolve_arch(m):
 left,base,right=m.groups()
 return right+left[left.index('Its canonical run environment'): ] if 'Its canonical run environment' in left else right
p='docs/architecture.md'; text=pat.sub(resolve_arch,(scratch/'1-inverse/result').read_text()); (scratch/'architecture-inverse-resolved').write_text(text)
def resolve_rules(m):
 left,base,right=m.groups()
 if left.startswith('Sensitivity resolves'): return left+right
 if left.startswith('one workflow.'):
  start=right.index('Before launching Node/browser')
  end=right.index('Under the same lock')
  memory=left[left.index('Before launching Node/browser'):]
  memory=memory.replace('Before launching Node/browser/build/Gradle or other heavy proof, the controller\nacquires the single-heavy-operation lock and waits at most 30 seconds for\nkernel-reported available memory', 'Before launching Node/browser/build/Gradle or other heavy proof under that\nlease, the controller waits at most 30 seconds for kernel-reported available memory')
  return right[:start]+memory+'\n'+right[end:]
 if 'nexus-test-routing-sha256' in left: return left
 if left.startswith('The controller owns one persistent'):
  return right+left[left.index('Memory-heavy proof'):]
 raise RuntimeError('unreviewed conflict '+left[:80])
p='docs/local-rules/testing-standards.md';text=pat.sub(resolve_rules,(scratch/'209-inverse/result').read_text());(scratch/'rules-inverse-resolved').write_text(text)
for p,stem in [('docs/architecture.md','architecture'),('docs/local-rules/testing-standards.md','rules')]:
 left=scratch/(stem+'-head');base=scratch/(stem+'-base');right=scratch/(stem+'-inverse-resolved')
 left.write_text(git('HEAD',p));base.write_text(git('7fa89b88c8',p))
 proc=subprocess.run(['git','merge-file','--diff3','-p',str(left),str(base),str(right)],capture_output=True,text=True)
 assert 0<=proc.returncode<128,proc.stderr
 (repo/p).write_text(proc.stdout)
 print(p,'remaining conflicts',proc.returncode)
for p in ['docs/cutovers/reader-document-map-council-review.md','docs/cutovers/reader-document-map-structure-hard-cutover.md','docs/modules/epub.md','docs/modules/reader-design-rationale.md','docs/modules/reader-implementation.md','docs/tickets/reader-map-inert-position-and-mobile-controls.md','docs/outstanding-issues.md']:
 (repo/p).write_text(git('HEAD',p))
p=repo/'docs/modules/reader-implementation.md';text=p.read_text();needle='- The adapter projects the same semantic viewport that drives document-position'
assert text.count(needle)==1
text=text.replace(needle,'- a prose tap may adopt the exact restored viewport before a new `Reader`\n  publication. that permission cannot carry into a later restoration, even in\n  the same fragment. source links and control activation do not adopt reading;\n  actual scrolling over a link does. the text leaf and activity adapter share\n  one keyboard-direction classifier so activating an inline button with space\n  cannot claim a forward reading gesture.\n'+needle)
p.write_text(text)
p=repo/'docs/outstanding-issues.md';text=p.read_text()
for ticket,line in [('devbox-buildkit-cache-retention.md','buildkit cache needs an owned retention policy'),('generation-eval-corpus-provider-pin-drifts-from-delivery.md','generation eval corpus provider pin differs from delivery dependencies')]:
 if ticket not in text: text+='\n- open: '+line+'; [ticket](tickets/'+ticket+').\n'
p.write_text(text)
