# two stale fault registrations

status: draft only; no main edits, injected product source or tests.
origin: 2026-09-14, post-merge policy review at dd21213.

## browse: retain one canonical owner

`llm-tools-legacy-browse-owner-bypass` already owns the exact pinned-tools test.
its original mutation replaces llm_tools with the retired web_search_tool import;
the proof catches that precise missing module and asserts the original message.
its patch, row, proof and expected failure stay byte-for-byte unchanged.

`browse-provider-query-round-trip-bypass` was added by ec40d76ad4 after the
compatibility rollback and registers that same exact proof a second time. the
controller correctly rejects this duplicate (policy.py:2145). its obsolete
context also names the private request wrapper restored by rollback01b5b6d5db;
current delivery retains the direct WebSearchRequest owner from468ac466bb.

remove the duplicate row and its tracked patch together; leaving the patch would
fail the separate unmanifested-patch guard (policy.py:2215). retain the same
query corruption as `browse-query-auxiliary.patch` under this /tmp review folder.
it changes only query=query.query to the same altered string at the actual
provider request constructor. the existing controlled HTTP provider assertion
still checks q == x and its named canonical-query message. that assertion is not
removed, weakened or split into a duplicate owner. the auxiliary has not run and
is not registered; any later sensitivity execution needs a separately approved
paved invocation, not an alias or extra canonical row.

## worker: move the same eager-import fault to the live entrypoint

0977dfe3e1 deleted llm_profiles.py during the generation hard cut.
rollback01b5b6d5db resurrected it;20b7b88df3 then placed the eager import fault
there for the compatibility worker graph. the merged delivery correctly retains
the hard cut, so that file cannot remain the fault's production target.

current apps/worker/main.py is the actual entrypoint imported by the unchanged
whole-file proof. its registry imports handler implementations only inside
resolve_job_handler; generation initialization belongs to the child runtime in
process_executor.py:_initialize_child_runtime. adding ProviderRuntime to
metadata that this idle entrypoint no longer imports would be a vacuous fault.

rebase the one original statement, `from provider_runtime.runtime import
ProviderRuntime`, to the top-level imports of apps/worker/main.py. this is an
explicit semantic owner move, not a claimed file rename. it makes the actual
idle worker eagerly load precisely the same forbidden execution module. the
proof still runs a fresh child interpreter, imports apps.worker.main, checks
sys.modules for the existing exact blocked roots, and raises the unchanged
"the idle worker loaded provider execution modules" assertion in its parent.
provider9ab makes HTTP adapters lazy, but provider_runtime.runtime itself remains
an explicitly forbidden root; therefore the injected import does not depend on
accidentally loading a particular vendor SDK to reach this oracle.

only the worker patch sha changes in its manifest row. its whole-file proof,
expected message and absence of coherent opt-in remain unchanged. the production
runtime-health source routing already owns apps/worker. no product patch is
active and no claim of red or green follows from source review.

## applicability and pending proof

read-only git apply --check accepts the proposed main bundle and both individual
faults against current main. this validates patch context only. inventory binds
the original rows, untouched canonical patch, source/proof bytes and candidate
hashes. main.patch changes exactly the worker fault, removes the duplicate browse
fault, and makes those two manifest edits. it must be applied surgically if
another owner changes that shared manifest.

after review/integration, retain the existing canonical invocations:

```sh
./scripts/test prove --proof pytest:python/tests/kernel/test_worker_runtime_health.py --against fault:worker-provider-execution-import-bypass
./scripts/test prove --proof pytest:python/tests/llm_tools_contract/test_pinned_llm_tools.py::test_exact_pins_round_trip_one_canonical_native_tool --against fault:llm-tools-legacy-browse-owner-bypass
```

neither has executed in this review. the independent browse query assertion still
runs in the ordinary pinned-tools owner; query-fault sensitivity remains pending.
