# doctor privilege fixture tool contract

status: draft; actual replay pending. origin: run b45be17460a6b9cc at 2f37025d74d82c10fc0d9117842f7b7871bf92b9, 2026-09-14. area: controller proof fixture.

the retained failure is exact: test_runner.py:709 expected “effective uid 0 or non-interactive sudo” but received “required tools are absent: node”. _run_doctor checks actionlint, bun, docker, git, java, node, supabase and uv before privilege admission. this fixture owns a sealed fake-tool path and supplied every old prerequisite except node. add node to that existing tool list.

the sudo executable still exits 1 with “sudo: a password is required”. not_run, the exact privilege diagnostic, the sudo error, and the sole recorded command [sudo] remain unchanged. dependency work must still never start. no product change or new proof.

the neighboring doctor audit found no second sealed-path omission: test_ingest_node_capability creates node explicitly before passing the same tool directory to its doctor fixture. test_llm_tools_capability intentionally combines its fake tool directory with the actual host path, including real git; node resolves from that host path. no alteration to that independent proof is proposed. test_runner's generic absent-tool and one-shot-reporting scenarios intentionally stop before dependency admission; the offline-cache test calls its narrower existing owner directly. other actionlint lists belong to static workflow tests, not doctor.

only a sibling test body changes. the exact native host selection canonical source digest is unchanged, and its existing fault has no coherent opt-in. no manifest or ownership-floor update is required. inventory-v1.json records exact hashes. no checks or tests were executed.
