# proposed hosted selected-cell contract

status: proposal only; no source, schema, endpoint or capability activation.

## request and identity

add one `TableHeaders` case to the existing source `view` query and session
query lease. hosted transport uses the existing admitted, repeatable-read
publication router:

`POST /media/{media_id}/reader-publications/{generation}/table-headers`

```ts
{ fragment_id, table_ordinal, row, column, limit, after }
```

`fragment_id` is the published uuid; other coordinates use the existing safe
integer `ReaderTableCoordinate` contract. the tuple identifies the original
cell, including continued excerpts. no unit-local row number or synthesized id.
`limit` proposes the existing overlay scale, 1–24, still subordinate to the
actual `index_bytes` response envelope. `after` is a signed opaque keyset cursor.

## result

```ts
{ kind: "Found", reader_generation,
  table: ReaderPublicationTableMetadata,
  cell: ReaderPublicationTableCellMetadata,
  headers: ReaderPublicationTableCellMetadata[],
  next_cursor: string | null }
| { kind: "Unresolved", reader_generation }
```

these are the existing `Table` and `Cell` record types, not new label/geometry
models. every returned record must match the exact requested fragment/table;
`cell` additionally matches the requested row/column. generation is exact,
never silently advanced. missing or revoked media and absent retained generation
keep the existing member-read errors. a valid cell with no associated headers
is `Found` with an empty completed page. an absent coordinate is `Unresolved`.
the existing publication-ready fence includes all required query projections.
`table_metadata_ref == null` means no logical-excerpt metadata; a referenced
table whose required sql rows are missing is a loud publication defect, never
a new unavailable/empty state. no source assembly or preparation runs in this read.

`headers.length` counts this page only. `next_cursor == null` proves exhaustion;
otherwise the next request advances after the last emitted unique header.
there is no eager global count. response byte pressure may return fewer than
`limit`; one row must fit or return the existing capacity disposition. an empty
nonfinal page is not allowed for this selected-result query. cursor binding
includes viewer/media/generation/cell. its internal key and algorithm version
are deferred until independent sql algorithm review establishes exact first-
occurrence order and dedup without prefix rescans or per-row round trips. native
internal ids never become public source identities. changed bindings are
rejected. explicit headers retain source order, including allowed `td`
targets; automatic rays, opacity and group append follow the existing corpus.

## exact accessible content

caption is `table.caption`; each header retains its full existing `range`.
no fixed-length string stands in for the complete header or caption. a detail
selects one range and uses the existing unit addressing/lease owner to expose
its complete content through as many bounded unit pages as needed. range start
can belong to an opening-only unit and range end can cross later units; never
clamp either to the first unit. preserve source text/render semantics and make
continuation explicit. client review confirms `positionPublicationRange` can
already navigate/pulse the exact range, including nonresident units, but cannot
render its complete authored content in a side panel. that bounded unit-page
disclosure still needs implementation and qualification; a source jump alone
is insufficient to claim complete in-context header/caption disclosure.
query page, decoded units and rendered detail must all remain charged; retiring
the selection releases their existing leases. native `view == null` remains an
explicit unavailable capability until its actual production query is wired.

## existing ownership and necessary implementation

`reader_publication_artifacts.prepare_text_reader_publication` already receives
source `Table`/`Cell`/`ColumnGroup`/`ExplicitHeader` records and writes bounded,
digest-bound table index members. `install_prepared_reader_publication` already
installs same-generation unit/search/target projections under the publication
fence. extend that owner with source-sized scalar table relations, exact source
order and range/unit joins. **no such postgres table projection currently
exists** in `db/models.py`; no claim of an already-available header sql owner.
reuse its file-backed preparation, title-only sql copy and generation purge
paths. new generations install sparse rows atomically with existing projections;
there is no second completion row, reader pointer or readiness state. store
geometry/explicit edges, never all automatic header pairs.

retained generations must be backfilled before query activation. extend the
existing `prepare_reader_publication` job and publication preflight owners to
consume the selected retained descriptor and digest-bound table index members,
not current fragments. their present implementations only visit the current
generation and return early when a descriptor exists; those branches need a
reviewed extension, not a claim that old-generation backfill already works.
stage bounded records outside the final transaction, then hold existing media/
publication ownership and exact retained-descriptor identity while installing
all required rows atomically under the job claim. if retained bytes were purged,
discard preparation; never advance the current generation. preflight must
verify every retained generation before endpoint activation. existing permanent
job dedupe also needs the new preparation work identity, since an old successful
`reader-1` job is returned unchanged; this is job identity, not reader readiness.

queries reuse `get_reader_publication_member_for_viewer` for access/generation,
existing signed cursors, `_query_response` for the byte envelope, and existing
unit members for content. do not read the whole metadata chain in the api or
browser. the native header reducer is still a test-source characterization,
not a production postgres implementation. its sqlite scalar-call algorithm
must not become postgres round trips. the query algorithm and derivative
completion/backfill must be reviewed separately; page bounds do not qualify
first-page cpu, scratch, physical reads or retained-growth latency.

acceptance requires the existing normative/differential source corpus plus
actual emitted excerpt/caption fixtures, exact paging without duplicates,
shared-target/empty/explicit-td/group/overlap cases, stale-generation and revoked
access checks, and full multi-unit header/caption disclosure. measure the actual
hosted selected query on maximum accepted sparse and overlapping source shapes
before activation. no schema or endpoint edit is authorized by this proposal.
