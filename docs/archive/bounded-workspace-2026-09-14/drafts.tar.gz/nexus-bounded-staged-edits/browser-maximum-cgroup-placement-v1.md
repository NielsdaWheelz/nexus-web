# maximum browser experiment: existing controller scope

status: source draft only; no repository edit, probe, or maximum execution.
origin: 2026-09-14 client audit while 5593 is queued.

## established seams

- `services.py:1239` already supplies the exact caller's user-systemd bus environment.
- `services.py:1256` probes real cgroup delegation; its success attests only that probe's background-worker scope, not a later browser scope.
- `services.py:1855` already uses `systemd-run --user --scope --quiet --collect -p MemoryMax=... -p MemorySwapMax=0 -p OOMPolicy=continue`.
- `runner.py:2944–2953` constructs and runs one browser command. this is the narrow placement for the same scope wrapper. retain `_run_owned_commands` and `process.run_command`, including owned process group, signal cleanup, output bounds and result classification.
- `runner.py:6785` rewrites bun script fail-fast only at the argv prefix. apply `_fail_fast_command` to the inner browser command before wrapping; the outer pass is then idempotent.

## proposed placement, requiring review

use a fixed controller experiment ceiling and a separately named host headroom requirement. trial proposal: 2,048 mib scope ceiling + 2,048 mib available outside that ceiling. these are containment choices, NOT evidence that the source will fit. smaller effective ancestor limits must be reported. refuse the maximum if the real scope cannot establish its limit.

in `_run_component`, after exact browser argv construction and before `_run_owned_commands`:

```python
inner = _fail_fast_command(argv)
# while the existing shared heavy lock is held:
available = available_memory_mib()
if available is None or available < ceiling_mib + reserve_mib:
    return _not_run(capability, "browser experiment lacks its ceiling plus host headroom")
failure = cgroup_delegate_failure()
if failure is not None:
    return _not_run(capability, failure)
child_environment = {
    **_component_environment(environment, execution.run_id),
    **user_systemd_environment(),
}
argv = (
    "systemd-run", "--user", "--scope", "--quiet", "--collect",
    f"--unit=nexus-browser-{execution.run_id}",
    "-p", f"MemoryMax={ceiling_bytes}",
    "-p", "MemorySwapMax=0", "-p", "OOMPolicy=continue",
    # existing controller-owned exec bootstrap, described below
    *inner,
)
# require both systemd-run and inner[0], not only the wrapper executable.
```

selection must be closed before this becomes executable. an exact owner and complete suite expose their targets. the existing `vitest related` branch leaves `targets=()`, so checking one target string there can silently run the same experiment without a ceiling. two honest choices are (a) constrain all component commands under this one lane ceiling, or (b) resolve related owners before admitting the named maximum experiment. (a) is simpler but changes every browser proof's host contract and needs explicit approval plus ordinary portfolio validation; (b) is more machinery for one characterization. do not add a per-proof unbounded escape or a special launcher outside `./scripts/test`.

## required readback before original-source allocation

prefix the inner exec with a fixed, controller-owned bootstrap in the existing process owner, not a test-controlled shell command or environment knob. inside the ACTUAL scope, before importing Vitest or the fixture, it reads `/proc/self/cgroup`, then `memory.max`, `memory.swap.max`, `memory.oom.group`, `memory.events` and effective ancestor `memory.max` values. exact scope name, requested ceiling and swap=0 must match. mismatch exits before browser launch. it writes a small exclusive receipt under the existing run directory and execs the unchanged fixed inner argv. the controller binds that receipt to run id, source/proof identity, launch `MemAvailable`, required reserve and command.

use the existing owned browser pid observation (`browserMemoryCommand.ts`) to additionally attest that each actual Chromium process belongs to this scope before the source is allocated. inheritance from the scoped Vitest process is expected, but the final receipt must establish actual membership. do not add a second process sampler or a browser worker registry.

`--collect` can remove the scope cgroup before the outer command returns. retain the initial verified readback before allocation. do not turn a missing final `memory.events` file or generic signal exit into a claimed OOM diagnosis. the ordinary failed-command receipt remains failure/incomplete qualification. final peak/event evidence can be added only through the existing memory observer while the cgroup exists.

## reserve and teardown limits

launch `MemAvailable - ceiling >= reserve` bounds this experiment's worst additional charge against the observed host state. the shared lock excludes other cooperating heavy launches. it is NOT a kernel reservation against unrelated processes allocating later; report that assumption explicitly. this host's observed `MemAvailable` was about 1,303 mib during the audit, so the proposed 4,096 mib launch condition was not met.

verify with the existing controller process/service owners that cancellation retires the exact scoped browser descendants and that a deliberately small cgroup ceiling refuses/kills bounded synthetic work without harming the parent. scope launch itself must never escape the existing process group's cancellation owner. no global systemd stop/prune, extra process manager, production unit-cap change or speculative browser cap qualification.

## acceptance before the maximum

actual delegate and actual browser-scope readback; bounded synthetic ceiling/cancellation sensitivity; both missing-headroom and absent-delegate return not-run; ordinary component behavior under the chosen selection policy; artifact receipt survives failed browser work. only then run the exact original 64-mib source experiment. an OOM or excessive shaping time remains an unresolved source contract, not permission to reduce the source silently.
