import { cdp, commands, server } from "vitest/browser";
import { expectRecord } from "@/lib/validation";

// Temporary synthetic diagnosis. No heap snapshot is written to disk.
export async function recordRetainerPath(label: string) {
  const session = cdp();
  await session.send("HeapProfiler.enable");
  let chunks: string[] = [];
  const collect: Parameters<typeof session.on<"HeapProfiler.addHeapSnapshotChunk">>[1] = ({ chunk }) => chunks.push(chunk);
  session.on("HeapProfiler.addHeapSnapshotChunk", collect);
  try { await session.send("HeapProfiler.takeHeapSnapshot", { reportProgress: false }); }
  finally { session.off("HeapProfiler.addHeapSnapshotChunk", collect); }
  const raw = expectRecord(JSON.parse(chunks.join("")), "diagnostic heap");
  chunks = [];
  const metadata = expectRecord(expectRecord(raw.snapshot, "heap snapshot").meta, "heap metadata");
  const nodes: unknown = raw.nodes;
  const edges: unknown = raw.edges;
  const strings: unknown = raw.strings;
  const nodeFields: unknown = metadata.node_fields;
  const edgeFields: unknown = metadata.edge_fields;
  const nodeTypes: unknown = metadata.node_types;
  const edgeTypes: unknown = metadata.edge_types;
  function numberArray(value: unknown): asserts value is number[] {
    if (!Array.isArray(value) || value.some((item) => typeof item !== "number" || !Number.isSafeInteger(item))) throw new Error("Heap omitted numeric records");
  }
  function stringArray(value: unknown): asserts value is string[] {
    if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) throw new Error("Heap omitted string records");
  }
  numberArray(nodes); numberArray(edges); stringArray(strings); stringArray(nodeFields); stringArray(edgeFields);
  if (!Array.isArray(nodeTypes) || !Array.isArray(edgeTypes)) throw new Error("Heap omitted type descriptions");
  const nodeTypeNames: unknown = nodeTypes[nodeFields.indexOf("type")];
  const edgeTypeNames: unknown = edgeTypes[edgeFields.indexOf("type")];
  stringArray(nodeTypeNames); stringArray(edgeTypeNames);
  const nodeWidth = nodeFields.length;
  const edgeWidth = edgeFields.length;
  const nameField = nodeFields.indexOf("name");
  const typeField = nodeFields.indexOf("type");
  const countField = nodeFields.indexOf("edge_count");
  const idField = nodeFields.indexOf("id");
  const toField = edgeFields.indexOf("to_node");
  const edgeTypeField = edgeFields.indexOf("type");
  const edgeNameField = edgeFields.indexOf("name_or_index");
  if ([nameField, typeField, countField, idField, toField, edgeTypeField, edgeNameField].some((field) => field < 0)) throw new Error("Heap fields are incomplete");
  const count = nodes.length / nodeWidth;
  const firstEdges = new Uint32Array(count + 1);
  let target = -1;
  let nextEdge = 0;
  for (let node = 0; node < count; node += 1) {
    firstEdges[node] = nextEdge;
    const end = nextEdge + nodes[node * nodeWidth + countField] * edgeWidth;
    for (; nextEdge < end; nextEdge += edgeWidth) {
      if (edgeTypeNames[edges[nextEdge + edgeTypeField]] !== "property" || strings[edges[nextEdge + edgeNameField]] !== "__nexusRetainerDiagnostic") continue;
      if (strings[nodes[edges[nextEdge + toField] + nameField]] === label) target = node;
    }
  }
  firstEdges[count] = nextEdge;
  const previous = new Int32Array(count).fill(-1);
  const via = new Uint32Array(count);
  const queue = new Uint32Array(count);
  previous[0] = 0;
  let head = 0;
  let tail = 1;
  while (head < tail && (target < 0 || previous[target] < 0)) {
    const node = queue[head++];
    for (let edge = firstEdges[node]; edge < firstEdges[node + 1]; edge += edgeWidth) {
      if (edgeTypeNames[edges[edge + edgeTypeField]] === "weak") continue;
      const child = edges[edge + toField] / nodeWidth;
      if (previous[child] >= 0) continue;
      previous[child] = node;
      via[child] = edge;
      queue[tail++] = child;
    }
  }
  const path = [];
  if (target >= 0 && previous[target] >= 0) {
    let node = target;
    for (;;) {
      const offset = node * nodeWidth;
      const edge = via[node];
      const edgeType = edgeTypeNames[edges[edge + edgeTypeField]];
      path.push({ nodeId: nodes[offset + idField], type: nodeTypeNames[nodes[offset + typeField]], name: strings[nodes[offset + nameField]].slice(0, 400),
        edgeType: node === 0 ? null : edgeType, edge: node === 0 ? null : edgeType === "element" || edgeType === "hidden" ? String(edges[edge + edgeNameField]) : strings[edges[edge + edgeNameField]] });
      if (node === 0) break;
      node = previous[node];
    }
    path.reverse();
  }
  const directory = server.config.env.NEXUS_TEST_RESULTS_DIR;
  const runId = server.config.env.NEXUS_TEST_EVIDENCE_RUN_ID;
  if (!/^[0-9a-f]{16}$/.test(runId) || !directory.endsWith(`/test-results/runs/${runId}`)) throw new Error("Diagnostic requires owned evidence directory");
  await commands.writeFile(`${directory}/retainer-${label}.json`, JSON.stringify({ runId, label, target, reachableNodes: tail, path }, null, 2));
}
