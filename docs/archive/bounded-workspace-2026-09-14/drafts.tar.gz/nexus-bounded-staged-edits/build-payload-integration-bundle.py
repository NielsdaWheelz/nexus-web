from pathlib import Path
import difflib,hashlib,json,subprocess,shutil
client=Path('/home/niels/src/personal/nexus-web-bounded-client-proof')
main=Path('/home/niels/src/personal/nexus-web-bounded-workspace')
staged=Path('/tmp/nexus-bounded-staged-edits')
bundle=Path('/tmp/nexus-bounded-client-green-5682dc44efbff485')
bundle.mkdir(exist_ok=True)
paths=['apps/web/src/lib/api/resourceCache.tsx','apps/web/src/lib/reader/DocumentReaderSession.ts','apps/web/src/lib/reader/useDocumentReaderWindow.ts','apps/web/src/app/(authenticated)/media/[id]/MediaPaneBody.tsx','apps/web/src/lib/api/publicationCache.browser.test.tsx','apps/web/src/lib/reader/ReaderUnitPayloadRetirement.browser.test.tsx']
sha=lambda b: hashlib.sha256(b).hexdigest()
main_bytes={p:(main/p).read_bytes() if (main/p).exists() else None for p in paths}
client_bytes={p:(client/p).read_bytes() for p in paths}
for p in paths:
 if main_bytes[p] != ((main/p).read_bytes() if (main/p).exists() else None): raise RuntimeError('main changed during inventory: '+p)
 if client_bytes[p] != (client/p).read_bytes(): raise RuntimeError('client changed during inventory: '+p)
for label,items in [('client-after',client_bytes),('client-before',client_bytes),('main-observed',main_bytes),('main-proposal',main_bytes)]:
 for p,b in items.items():
  if b is None: continue
  q=bundle/label/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
patches=['reader-unit-payload-retirement-review.patch','publication-cache-current-borrow-proof.patch','reader-unit-borrow-contract.patch']
(bundle/'reviewed-patches').mkdir(exist_ok=True)
for p in patches: shutil.copyfile(staged/p,bundle/'reviewed-patches'/p)
for p in patches[:2]:
 subprocess.run(['git','apply','--reverse',str(staged/p)],cwd=bundle/'client-before',check=True)
# New proof did not exist before this slice.
(bundle/'client-before'/paths[-1]).unlink()
# Mechanical reconciliation draft ONLY: preserve main's tagged settlement,
# capacity taxonomy/constants/pools and all unrelated source changes.
def change(p,old,new):
 f=bundle/'main-proposal'/p;s=f.read_text()
 if s.count(old)!=1: raise RuntimeError(f'{p}: expected one source fragment, got {s.count(old)}')
 f.write_text(s.replace(old,new))
p=paths[0]
s=(bundle/'client-before'/p).read_text();a=s.index('  private retainPublication(');b=s.index('\n  }',a)+4
candidate=(bundle/'client-after'/p).read_text();x=candidate.index('  private retainPublication(');y=candidate.index('\n  }',x)+4
change(p,s[a:b],candidate[x:y])
change(p,'export interface PublicationUnitLease {\n','export interface PublicationUnitLease {\n  /** Borrow before release; an already borrowed promise cannot be revoked. */\n')
p=paths[1]
change(p,'    payloadBytes += reservation;\n    const entry: UnitEntry = {','    payloadBytes += reservation;\n    let retainedUnit: ReaderPublicationUnit | null = null;\n    const entry: UnitEntry = {')
change(p,'          return { kind: "Unit", address, unit: settled.unit };','          retainedUnit = settled.unit;\n          return { kind: "Unit", address, get unit() {\n            if (retainedUnit === null) throw new Error("Reader unit source has retired");\n            return retainedUnit;\n          } };')
change(p,'          entry.released = true;\n          if (!entry.pending) {','          entry.released = true;\n          retainedUnit = null;\n          if (!entry.pending) {')
change(p,'  readonly address: ReaderPublicationUnitAddress;\n  readonly unit: ReaderPublicationUnit;','  readonly address: ReaderPublicationUnitAddress;\n  /** Borrow while its unit lease is live; the handle clears on final release. */\n  readonly unit: ReaderPublicationUnit;')
change(paths[2],'      const item: ReaderWindowUnit = { ...value, lease };','      const item: ReaderWindowUnit = { kind: value.kind, address: value.address, get unit() { return value.unit; }, lease };')
p=paths[3]
for marker in ['      const unit = item.unit;\n      return {\n        fragmentId: unit.fragment_id,']:
 change(p,marker,'      const unit = item.unit;\n      const from = unit.render_start_cp === unit.start_cp ? 0\n        : codepointToUtf16(unit.canonical_text, unit.render_start_cp - unit.start_cp);\n      const to = unit.render_end_cp === unit.end_cp ? unit.canonical_text.length\n        : codepointToUtf16(unit.canonical_text, unit.render_end_cp - unit.start_cp);\n      return {\n        fragmentId: unit.fragment_id,')
change(p,'        canonicalText: unit.canonical_text.slice(\n          codepointToUtf16(unit.canonical_text, unit.render_start_cp - unit.start_cp),\n          codepointToUtf16(unit.canonical_text, unit.render_end_cp - unit.start_cp),\n        ),','        get canonicalText() {\n          const text = item.unit.canonical_text;\n          return from === 0 && to === text.length ? text : text.slice(from, to);\n        },')
p=paths[4]
change(p,'  const second = lease(acquire(cache, reference));\n  await vi.waitFor','  const second = lease(acquire(cache, reference));\n  const firstRead = first.promise;\n  await vi.waitFor')
change(p,'  expect(await first.promise).toBe(await second.promise);','  expect(await firstRead).toBe(await second.promise);')
p=paths[5]
s=client_bytes[p].decode().replace('if ("kind" in first || "kind" in second)', 'if (first.kind === "Capacity" || second.kind === "Capacity")')
q=bundle/'main-proposal'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
def diff(oldlabel,newlabel,name):
 text=[]
 for p in paths:
  a=bundle/oldlabel/p;b=bundle/newlabel/p
  x=a.read_text().splitlines(keepends=True) if a.exists() else []
  y=b.read_text().splitlines(keepends=True) if b.exists() else []
  text.extend(difflib.unified_diff(x,y,fromfile='a/'+p if a.exists() else '/dev/null',tofile='b/'+p if b.exists() else '/dev/null'))
 (bundle/name).write_text(''.join(text))
diff('main-observed','client-after','main-to-client-review-only.diff')
diff('main-observed','main-proposal','main-reconciliation-draft.patch')
receipts=['8802ec32ae19c7cc','5682dc44efbff485','37d5484723bad8d2','3ed208243dd68fb1']
for r in receipts:
 for name in ['summary.json','run-context.json','component-1.log']:
  p=client/'test-results/runs'/r/name
  if p.exists():
   q=bundle/'receipts'/r/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
files=[]
for p in paths:
 row={'path':p}
 for label in ['client-before','client-after','main-observed','main-proposal']:
  q=bundle/label/p;row[label]=sha(q.read_bytes()) if q.exists() else None
 files.append(row)
manifest={'status':'reviewed client source; original raw-payload proof green; main reconciliation draft unexecuted','client_git_base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=client,text=True).strip(),'base_provenance':'client-before reconstructs exact reviewed patch preimages by inverse application to held client source; git base alone does not attest dirty files','files':files,'patches':{str(p.relative_to(bundle)):sha(p.read_bytes()) for p in (bundle/'reviewed-patches').iterdir()},'reconciliation_sha256':sha((bundle/'main-reconciliation-draft.patch').read_bytes()),'main_snapshot_verified_before_after':True}
(bundle/'inventory.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(bundle)
print(manifest['reconciliation_sha256'])
print(json.dumps(files,indent=2))
