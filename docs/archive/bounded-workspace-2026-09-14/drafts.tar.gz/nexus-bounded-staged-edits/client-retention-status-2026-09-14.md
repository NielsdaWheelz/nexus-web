# client retention evidence correction

- raw source payload: pre-fix red 8802ec32ae19c7cc; standalone candidate green 5682dc44efbff485. the latter actually executes the source sharing, live-reader preservation, exact accounting return, and final raw-unit collection assertions.
- earlier share gc failures cannot isolate a product fault: diagnostic 66d97c4abe8dfa7f finds vitest current.onFinished error stack -> PlaywrightLocator._container -> retired trigger. the temporary heap helper and diagnostic attributes were removed; no heap was saved.
- selector-backed Share clicks remove that test owner. unfixed product red 10b2a292db66f5a1 still reaches the original detached-trigger assertion after live Escape/focus succeeds. clearable trigger and weak captured focus must be qualified separately.
- pdf ancestor diagnostic 7169ec7b50a1d70a finds pdfjsLib -> AnnotationEditor._l10n -> GenericL10n.#elements -> retired PDF document region. this is SDK localization lifetime, independent of the pending Range hypothesis. source text collection alone is insufficient.
- all pdf/share retirement clicks now use selector-backed public browser role locators. assertions, held writes, positive source liveness, physical PDF-worker retirement, and acknowledged destinations remain unchanged. no framework state was cleared.
- no main source integration or claim of full retention closure has occurred.
