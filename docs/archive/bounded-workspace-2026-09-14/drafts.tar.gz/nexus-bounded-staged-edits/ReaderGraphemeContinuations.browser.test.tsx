import { render, screen } from "@testing-library/react";
import { afterAll, expect, it } from "vitest";
import { cdp, commands, page, server, userEvent } from "vitest/browser";
import { nativeBrowserMemory } from "@/components/__tests__/browserMemory";

const observations: object[] = [];

it("characterizes one grapheme as one text node and as contiguous inline text spans", async () => {
  await page.viewport(1000, 600);
  const client = cdp();
  const view = render(<>
    <article aria-label="Grapheme rendering" style={{ position: "fixed", left: 40, top: 40,
      width: 800, height: 240, overflow: "hidden", background: "white", color: "black",
      font: "32px/48px Arial", whiteSpace: "pre-wrap", padding: 32 }} />
    <textarea aria-label="Copied source" style={{ position: "fixed", left: 40, top: 340 }} />
  </>);
  const root = screen.getByRole("article", { name: "Grapheme rendering" });
  const destination = screen.getByRole("textbox", { name: "Copied source" });
  try {
    for (const marks of [256, 4096, 65536]) {
      const source = `prefix q${"\u0301".repeat(marks)} suffix`;
      // This is the same source held for both representations. This profile
      // characterizes shaping; it does not establish source-maximum admission.
      let reference: string | null = null;
      for (const chunk of [source.length, 1024]) {
        root.replaceChildren();
        const began = performance.now();
        if (chunk === source.length) root.append(document.createTextNode(source));
        else for (let start = 0; start < source.length; start += chunk) {
          const span = document.createElement("span");
          span.textContent = source.slice(start, start + chunk);
          root.append(span);
        }
        const range = document.createRange();
        range.selectNodeContents(root);
        const bounds = range.getBoundingClientRect().toJSON();
        const layoutMs = performance.now() - began;
        await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
        const rendered = await page.screenshot({ element: root, save: false });
        if (reference === null) reference = rendered;
        else expect(rendered, `inline continuation changed rendered pixels at ${marks} combining marks`).toBe(reference);
        const layoutMemory = await nativeBrowserMemory();
        const selection = document.getSelection();
        if (selection === null) throw new Error("Chromium selection is unavailable");
        selection.removeAllRanges(); selection.addRange(range);
        expect(selection.toString(), "inline continuation changed selected source").toBe(source);
        await userEvent.copy();
        await userEvent.click(destination);
        await userEvent.paste();
        expect(destination, "inline continuation changed copied source").toHaveValue(source);
        observations.push({ marks, chunk, textNodes: chunk === source.length ? 1 : Math.ceil(source.length / chunk),
          bounds, layoutMs, layoutMemory, copiedMemory: await nativeBrowserMemory() });
        await userEvent.clear(destination);
        selection.removeAllRanges();
        root.replaceChildren();
        await client.send("HeapProfiler.collectGarbage");
      }
    }
  } finally { view.unmount(); }
});

afterAll(async () => {
  const directory = server.config.env.NEXUS_TEST_RESULTS_DIR;
  const runId = server.config.env.NEXUS_TEST_EVIDENCE_RUN_ID;
  if (!/^[0-9a-f]{16}$/.test(runId) || !directory.startsWith("/") || !directory.endsWith(`/test-results/runs/${runId}`)) {
    throw new Error("Grapheme observations require the controller-owned evidence directory");
  }
  await commands.writeFile(`${directory}/grapheme-continuations.json`, JSON.stringify({ runId,
    scope: "ordinary Chromium shaping/selection/clipboard characterization; one intact root; no unit eviction, source-maximum, Android or memory-capacity claim",
    observations }));
});
