from pathlib import Path
import difflib,hashlib
root=Path('/home/niels/src/personal/nexus-web-bounded-residency-proof');p='apps/web/src/components/workspace/ReaderWorkspaceResidency.browser.test.tsx'
s=(root/p).read_text();v=s
start=v.index('    const describeWheelTarget = ');end=v.index('    expect(firstReader, "moving a focused reader offscreen retired its body")',start)
v=v[:start]+'''    let trustedWheel = false;
    const observeWheel = (event: WheelEvent) => { trustedWheel = event.isTrusted; };
    document.addEventListener("wheel", observeWheel, { capture: true, once: true });
    try {
      await client.send("Input.dispatchMouseEvent", { type: "mouseWheel", ...wheelOuter, deltaX: 2000, deltaY: 0 });
      await waitFor(() => expect(trustedWheel, "canvas movement requires a trusted wheel").toBe(true));
      await waitFor(() => expect(firstReader.getBoundingClientRect().right,
        "the canvas wheel did not move the focused reader offscreen").toBeLessThanOrEqual(host.left));
    } finally { document.removeEventListener("wheel", observeWheel, true); }
'''+v[end:]
old='''    expect(document.elementFromPoint(dragX, dragY)?.closest('[data-testid="pane-shell-chrome"]'),
      `drag geometry: ${JSON.stringify({ x: dragX, y: dragY, host, chrome: dragBounds, resize,
        hit: document.elementFromPoint(dragX, dragY)?.outerHTML.slice(0, 600) })}`).toBe(dragChrome);'''
assert v.count(old)==1
v=v.replace(old,'''    expect(document.elementFromPoint(dragX, dragY)?.closest('[data-testid="pane-shell-chrome"]')).toBe(dragChrome);''')
start=v.index('    type DragInput = ');end=v.index('    await returnToFirstReader();',start)
v=v[:start]+'''    const trustedDrag = { down: false, move: false };
    const observeDown = (event: MouseEvent) => { trustedDrag.down = event.isTrusted; };
    const observeMove = (event: MouseEvent) => { trustedDrag.move = event.isTrusted; };
    document.addEventListener("mousedown", observeDown, { capture: true, once: true });
    let pressed = false;
    try {
      pressed = true;
      await client.send("Input.dispatchMouseEvent", { type: "mousePressed", button: "left", clickCount: 1, ...outerPoint(dragX, dragY) });
      await waitFor(() => expect(trustedDrag.down, "canvas drag requires a trusted press").toBe(true));
      document.addEventListener("mousemove", observeMove, { capture: true, once: true });
      await client.send("Input.dispatchMouseEvent", { type: "mouseMoved", button: "left", buttons: 1,
        ...outerPoint(dragEndX, dragY) });
      await waitFor(() => expect(trustedDrag.move, "canvas drag requires trusted movement").toBe(true));
      await waitFor(() => expect(draggedReader.getBoundingClientRect().right,
        "the canvas drag did not move the reader offscreen").toBeLessThanOrEqual(host.left));
      expect(draggedReader, "an unfinished canvas drag retired an offscreen reader").toBeInTheDocument();
      await client.send("Input.dispatchMouseEvent", { type: "mouseReleased", button: "left", clickCount: 1,
        ...outerPoint(dragEndX, dragY) });
      pressed = false;
      await waitFor(() => expect(draggedReader, "completed drag kept an unpinned reader mounted").not.toBeInTheDocument());
    } finally {
      document.removeEventListener("mousedown", observeDown, true);
      document.removeEventListener("mousemove", observeMove, true);
      if (pressed) await client.send("Input.dispatchMouseEvent", { type: "mouseReleased", button: "left", clickCount: 1,
        ...outerPoint(dragEndX, dragY) });
    }
'''+v[end:]
f=Path('/tmp/nexus-bounded-staged-edits/workspace-residency-diagnostic-cleanup-v1.patch')
f.write_text(''.join(difflib.unified_diff(s.splitlines(keepends=True),v.splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p)))
print(hashlib.sha256(f.read_bytes()).hexdigest(),f)
print('source lines',len(s.splitlines()),'candidate lines',len(v.splitlines()))
