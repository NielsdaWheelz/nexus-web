from pathlib import Path
import difflib,hashlib,json,subprocess,shutil
client=Path('/home/niels/src/personal/nexus-web-bounded-client-proof')
main=Path('/home/niels/src/personal/nexus-web-bounded-workspace')
staged=Path('/tmp/nexus-bounded-staged-edits')
bundle=Path('/tmp/nexus-bounded-client-green-7c0e3c428b6814cb');bundle.mkdir(exist_ok=True)
paths=['apps/web/src/components/PdfReader.tsx','apps/web/src/components/pdfReaderRuntime.ts','apps/web/src/components/PdfReaderPendingWriteRetirement.browser.test.tsx']
support=['apps/web/src/components/__tests__/pdfReaderSession.ts','apps/web/src/components/__tests__/pdfFixtures.ts','apps/web/src/app/(authenticated)/media/[id]/hostedPdfReaderDecorations.ts']
sha=lambda b:hashlib.sha256(b).hexdigest()
main_bytes={p:(main/p).read_bytes() if (main/p).exists() else None for p in paths+support}
client_bytes={p:(client/p).read_bytes() for p in paths+support}
for p in paths+support:
 if main_bytes[p]!=((main/p).read_bytes() if (main/p).exists() else None):raise RuntimeError('main changed during inventory:'+p)
 if client_bytes[p]!=(client/p).read_bytes():raise RuntimeError('client changed during inventory:'+p)
for label,items in [('main-observed',main_bytes),('main-proposal',main_bytes),('client-before',client_bytes),('client-after',client_bytes)]:
 for p,b in items.items():
  if b is None:continue
  q=bundle/label/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
patch=staged/'pdf-localization-retirement.patch';shutil.copyfile(patch,bundle/patch.name)
subprocess.run(['git','apply','--reverse',str(patch)],cwd=bundle/'client-before',check=True)
subprocess.run(['git','apply',str(patch)],cwd=bundle/'main-proposal',check=True)
# Main's selected immutable PDF source no longer models signed-grant expiry.
proof=client_bytes[paths[2]].decode()
assert proof.count('data: { url, expiresAtMs: null }')==1
proof=proof.replace('data: { url, expiresAtMs: null }','data: { url }')
(bundle/'main-proposal'/paths[2]).write_text(proof)
def diff(old,new,name,items):
 out=[]
 for p in items:
  a=bundle/old/p;b=bundle/new/p
  out.extend(difflib.unified_diff(a.read_text().splitlines(keepends=True) if a.exists() else [],b.read_text().splitlines(keepends=True) if b.exists() else [],fromfile='a/'+p if a.exists() else '/dev/null',tofile='b/'+p if b.exists() else '/dev/null'))
 (bundle/name).write_text(''.join(out))
diff('main-observed','main-proposal','main-reconciliation-draft.patch',paths)
diff('main-observed','client-after','main-to-client-review-only.diff',paths+support)
for r in ['be8ff5fd9322fcac','7c0e3c428b6814cb','7169ec7b50a1d70a']:
 for name in ['summary.json','run-context.json','component-1.log','retainer-pdf-region.json']:
  p=client/'test-results/runs'/r/name
  if p.exists():
   q=bundle/'receipts'/r/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
rows=[]
for p in paths+support:
 row={'path':p,'integration':p in paths}
 for label in ['client-before','client-after','main-observed','main-proposal']:
  q=bundle/label/p;row[label]=sha(q.read_bytes()) if q.exists() else None
 rows.append(row)
manifest={'status':'l10n-only exact client owner green; main reconciliation draft unexecuted','source_patch_sha256':sha(patch.read_bytes()),'reconciliation_sha256':sha((bundle/'main-reconciliation-draft.patch').read_bytes()),'main_snapshot_verified_before_after':True,'base_provenance':'client-before inverse of exact reviewed l10n-only patch; exact same corrected selector-backed proof; pending selection identity patch absent both sides','files':rows}
(bundle/'inventory.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(bundle);print(manifest['reconciliation_sha256']);print(json.dumps(rows[:3],indent=2))
