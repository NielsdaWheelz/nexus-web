from pathlib import Path
r=Path('/home/niels/src/personal/nexus-web-bounded-workspace')
p=r/'python/nexus/services/document_embeds.py';s=p.read_text()
a=s.index('def replace_document_embed_artifact(');b=s.index('\ndef document_embed_summaries_for_media(',a)
part=s[a:b].replace(') -> list[tuple[UUID, UUID]]:',') -> None:')
part=part.replace('    queued_children: list[tuple[UUID, UUID]] = []\n    accepted_target_media_ids: set[UUID] = set()\n    library_ids = library_entries.admin_non_default_library_ids_for_media(\n        db, viewer_id=owner_user_id, media_id=media_id\n    )\n','')
x=part.index('        if isinstance(target, DocumentEmbedTargetAcceptSource):');y=part.index('        elif isinstance(target, DocumentEmbedTargetMaterialized):',x)
part=part[:x]+'''        if isinstance(target, DocumentEmbedTargetAcceptSource):
            raise AssertionError("Parent publication requires already accepted embed sources")
'''+part[y:]
part=part.replace('            target_media_id = target.media_id\n            resolution_status = "resolved"','''            target_media_id = target.media_id
            if target_media_id not in locked_existing_target_media_ids:
                raise AssertionError("Parent publication lacks its accepted child media fence")
            child = db.get(Media, target_media_id)
            if child is None:
                from nexus.services.reader_publication import ReaderPublicationBusy

                raise ReaderPublicationBusy()
            resolution_status = (
                "resolved" if child.processing_status == ProcessingStatus.ready_for_reading
                else "failed" if child.processing_status == ProcessingStatus.failed
                else "resolving"
            )''')
part=part.replace('            error_code = None\n            error_message = None','            error_code = child.last_error_code if resolution_status == "failed" else None\n            error_message = child.last_error_message if resolution_status == "failed" else None')
part=part.replace('    return queued_children\n','')
s=s[:a]+part+s[b:];p.write_text(s)
p=r/'python/nexus/services/x_ingest.py';s=p.read_text()
s=s.replace('from nexus.services.reader_publication_web import WebReaderFragment, prepare_web_reader_publication','from nexus.schemas.media import DocumentEmbedSource\nfrom nexus.services.reader_publication_web import WebReaderFragment, prepare_web_reader_publication')
s=s.replace('    quotes: dict[str, _PreparedXPost]\n','    quotes: dict[str, _PreparedXPost]\n    occurrences: tuple[DocumentEmbedArtifactOccurrence, ...]\n',1)
a=s.index('                publication = staging.enter_context(',s.index('                rendered = render_author_thread_fragment_html'))
s=s[:a]+'''                occurrences = tuple(
                    _document_embed_occurrence(
                        prepared=occurrence,
                        fragment_id=fragment.fragment.id,
                        target_media_ids={key: accepted.media_id for key, accepted in accepted_quotes.items()},
                    )
                    for fragment in fragments
                    for occurrence in fragment.quote_occurrences
                )
'''+s[a:]
s=s.replace('WebReaderFragment(item.fragment.id, item.fragment.idx, item.structure)','''WebReaderFragment(
                                item.fragment.id, item.fragment.idx, item.structure,
                                tuple(DocumentEmbedSource.model_validate(source.model_dump(exclude={"fragment_id"}))
                                      for source in occurrences if source.fragment_id == item.fragment.id),
                            )''',1)
s=s.replace('fragments, publication, accepted_quotes, prepared_quotes','fragments, publication, accepted_quotes, prepared_quotes, occurrences',1)
s=s.replace('prepared_fragments=prepared_thread.fragments,','prepared_fragments=prepared_thread.fragments,\n                        occurrences=prepared_thread.occurrences,',1)
s=s.replace('fragments=(WebReaderFragment(fragment.fragment.id, 0, fragment.structure),),','fragments=(WebReaderFragment(fragment.fragment.id, 0, fragment.structure, ()),),',1)
a=s.index('def _replace_x_thread_snapshot_projection(');b=s.index('    fragments = [',a)
s=s[:a]+s[a:b].replace('    prepared_fragments: tuple[_PreparedXFragment, ...],','    prepared_fragments: tuple[_PreparedXFragment, ...],\n    occurrences: tuple[DocumentEmbedArtifactOccurrence, ...],')+s[b:]
a=s.index('        occurrences=[',a);b=s.index('        extraction_error_code=',a)
s=s[:a]+'        occurrences=occurrences,\n'+s[b:]
p.write_text(s)
