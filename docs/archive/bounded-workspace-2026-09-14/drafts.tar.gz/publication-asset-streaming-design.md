# publication asset streaming cut

status: source-only proposal; no product edits or new qualification.

## authority and existing behavior

- private EPUB reads authorize with can_read_media before kind/readiness/key
  checks, then select exactly one epub_resources row. preserve that order,
  content allowlist, private cache policy and SVG CSP. no generation substitution
  or guessed asset path. the row attests size/content type, not a digest.
- Oracle remains a public, metadata-validated owned plate route. its 304 check
  precedes storage. preserve immutable cache policy, UUID-based ETag, size and
  content type. neither plate nor EPUB old read computes a digest.
- immutable publication members already select an exact retained artifact under
  current visibility and send its persisted size/SHA. reuse that authority,
  including range handling; never derive identity from a mutable EPUB alias.
  SHA remains the persisted publication fact, not an invented per-read check.

## minimal byte change

extend the existing nexus.storage.read owner with stream_object_checked, and
make read_object_checked consume that stream for its remaining actual byte-array
callers. same StorageError size rules and public service mappings. count incoming
bytes before exposing a chunk; reject excess immediately. withhold the chunk
that reaches declared length until the underlying iterator reaches exact EOF.
only then emit that final chunk. truncated or excess objects therefore cannot
finish a successful HTTP representation of the declared length.

this is incremental size verification, not full preflight. missing and failures
in one bounded prefetch can retain the existing E_STORAGE_ERROR response before
headers. later failures terminate the body; status and already-sent bytes cannot
be recalled. do not append JSON to the image, truncate an oversized source into
apparent success, or claim every corrupt object receives pre-header rejection.

replace EpubAssetOut.data with body iterator plus persisted size. rename Oracle's
Bytes result/read operation to describe the stream and preserve its metadata
read/304 separation. update both routes together. no new temp file, object copy,
image decode or automatic redirect to a different publication source.

## physical transport ownership

existing StreamingResponse(member_iterator) is a useful transport composition,
but it has no explicit close owner. installed Starlette's iterate_in_threadpool
has no finally-close and StreamingResponse does not close the iterator on send
failure/disconnect. document and prove this gap, not assumed reuse.

one narrow storage response owner should serve these two routes and the current
member route. it can remain a small StreamingResponse specialization:

1. own exactly the supplied storage generator; authorization and metadata are
   already resolved by the service. its explicit session is closed, but request
   middleware still owns its connection until response.start; prefetch does not
   claim to run after that release;
2. obtain the first checked chunk through a physically awaited thread step
   before response headers, preserving early service error mapping;
3. emit that chunk and advance the same iterator through backpressure; never
   prefetch the whole object or run competing next() calls;
4. on EOF, send error, disconnect or cancellation, await any outstanding sync
   next() before closing the iterator, and await close before leaving __call__.
   existing AdmittedImageRoute/AdmittedReadRoute retains its permit until that
   return. close must not race an executing generator or escape as background
   fire-and-forget cleanup.

hold any private thread shielding/draining helper pending the common admission
review. root proposes cancelling the inner AnyIO scope instead of raw
asyncio.Task.cancel(), so the framework's existing worker shield owns physical
completion. the storage response then needs explicit, framework-shielded close;
no second thread registry. this proposal still needs the actual blocked sync
route/next/close deadline proof. caller cancellation and deadline cancellation
are distinct paths in the existing admission owner.

stream_object and stream_object_range have one product implementation,
StorageClient, under StorageClientBase. extend both existing methods with
keyword-only chunk_bytes: int = 8 * 1024 * 1024. require a positive value before
opening the SDK body. full reads use body.read(chunk_bytes); inclusive ranges
use body.read(min(chunk_bytes, remaining)). this bounds each yielded chunk,
not total object bytes or the HTTP client's internal buffering. preserve the
range owner's existing exact-range/short-body behavior; no new range-digest or
extra-body integrity claim.

HTTP iterator construction passes chunk_bytes=64 * 1024 explicitly. preserve
the 8 MiB default for source download/preparation, archive assembly, verification
and other current non-HTTP callers. the same HTTP choice must reach both object
and range construction, not split an already allocated 8 MiB result afterward.
there is no environment setting or second rechunking buffer. size-tail lookahead
then retains at most two 64 KiB source chunks, plus SDK/framework/socket state;
this is an allocation bound on these chunks, not a measured whole-response peak.

64 KiB costs up to 128 times as many body-read/ASGI-send/threadpool steps as the
8 MiB default for large sequential objects. it does not issue 128 storage GETs:
one iterator still owns one SDK response. actual max-asset and PDF/range/archive
throughput must qualify that CPU/scheduling price with existing read overlap.

current direct HTTP constructors are reader_publications._member_response,
offline_reading.get_offline_reading_package and public_resource_sharing's PDF
file body; the new EPUB/Oracle checked stream joins those owners. full-object
legacy EPUB/Oracle authority remains size-only. avoid changing worker-side
ReaderPublicationObjectReader.stream, parser staging or artifact verification.

there are no additional StorageClientBase subclasses. source-proof doubles in
testkit.epub_fixtures and test_bounded_media_extraction have stream_object only;
the BlockingCopyStorage testkit proxy delegates it. update those narrow method
signatures where the new keyword can reach them; preserve their deliberate
failure and source-chunk behavior while honoring a smaller requested maximum.
no range fake currently duplicates the production range method. the real SDK
boundary proof records actual read(amount), exact range request, reconstructed
bytes and close, with ordinary omitted-keyword calls still requesting 8 MiB.

## proof and sensitivity plan

- retain all actual auth masking/kind/readiness/key/CSP/cache/304 cases. add real
  database media/resource and plate rows at the existing service/route boundary;
  the source identifier in requests must select those exact persisted rows.
- use the actual StorageClient with an external SDK body whose bounded read and
  close are observable. the old eager route must request a later chunk before
  the first response body reaches ASGI send; the candidate sends the first chunk
  before requesting further non-final chunks. no replacement of owned service,
  response or admission collaborators.
- exact bytes/content-length on success; missing/short-first/oversize-first map
  to the existing pre-header error. exact-length prefix plus one extra chunk,
  late truncation and late SDK failure must leave an incomplete response with
  no completed declared-length body. same-length mutation is not detectable by
  these legacy size-only records and is not a newly claimed guarantee.
- gate an actual SDK next() and close(), trigger real send failure/disconnect and
  the admitted deadline, then prove another image remains refused until those
  physical operations finish while a lightweight read succeeds. SDK body closes
  exactly once; no dependency/provider mock can substitute for this ownership.
- use a real HTTP/storage profile for allocation qualification at the largest
  accepted EPUB asset and Oracle plate. SDK boundary tests characterize ordering
  and cleanup, not process peak or remote transport. actual image pool limits
  remain unchanged until the result earns a qualification.

proposed touched owners: storage/read.py, epub_assets.py, oracle_plates.py,
media_assets.py, oracle.py, the existing publication member response seam, one
small shared storage-response module, and focused existing route/admission
proofs. any StorageClient chunk-contract change needs separate review first.
