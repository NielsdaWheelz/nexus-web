proposed contract; no schema or product edits

preventing repeated expensive conversion after a known representability refusal is justified. it is an operational failure state; the accepted max-atom source is STILL unsupported until it can be faithfully read. the refusal must not become an acceptance criterion.

existing authority is sufficient: one immutable installed package row, its exact source revision, existing reconciliation, and explicit retry. no automatic retry on converter upgrade is currently required. the documented explicit retry is therefore enough; do not add a converter-version system or a failure counter. a new installed package row and successful activation start without a refusal.

separate three outcomes at the converter boundary:

- prepared: the existing complete prepared package, including source graph joins and derived readiness. only this may activate or open.
- known unsupported representation: an explicit converter-owned type naming an established local limit of the present representation: the original complete ICU grapheme exceeds the full unit code-point budget. member/hash validation and incremental parsing are not a whole-source semantic verdict. a generic require/check/JSON/SQLite exception is not this fact. introduce this outcome only at the precise condition that proves the source cannot currently be represented, with an actual accepted-source witness. do not simply relabel every "canonical grapheme exceeds capacity" exception: the converter must establish the indivisible atom/budget relation, not infer it from a failed crop mapping.
- retryable resource failure: a precise external resource outcome, such as filesystem I/O or SQLite full/disk-I/O, preserves original bytes/progress and remains eligible for retry. arbitrary SQLite/illegal argument/class cast/missing invariant errors are defects; retain their cause and existing defect reporting. do not coerce them to Storage or a permanent source fact.

minimum state if the documented persistent refusal is retained:

1. one nullable converter-refusal code on the EXISTING installed package row. no enum CHECK, no conversion_failures counter. it belongs to that immutable source identity. only a known converter-owned unsupported outcome writes it; no general exception classifier.
2. explicit Retry clears the code through the existing store command and schedules the existing reconciliation. successful activation clears it with the installed row update; normal package removal/purge owns its retirement. no separate job, map or retry loop.
3. existing ReconciledPackage remains the sole exposure owner. replace its prepared boolean with the minimal closed readiness result only if the documented display distinctions need it: prepared / needs conversion / preflight storage refusal / known converter refusal. the exact installed row remains part of that same record. do not restore storageRefusedPackageIds.
4. a storage preflight refusal is a current observation. publish it through the same reconciled record for that exact row, and reobserve on reconciliation. it does not persist as an assertion about source validity or reserve disk.
5. a known persisted refusal prevents AUTOMATIC conversion of that exact package until explicit retry. member/hash/source-verdict checks still run; a refusal never exempts corrupt bytes from integrity checks or makes an unready index readable.

proof boundaries before integration:

- an actual admitted original that reaches the named typed unsupported condition; two automatic reconciliations preserve exact source/pending/baseline and do not repeat conversion, then explicit retry performs another attempt. actual max-atom refusal is already a source witness; a smaller independently valid boundary witness can exercise the durable policy. do not substitute a manually installed graph-invalid schema-two package and call byte/member verification ingress publication.
- a controlled filesystem resource failure retries and later succeeds with every original/progress field retained; a generic invariant exception remains a defect, never Unsupported/Storage. real SQLite must observe durable state, not a recording repository string.
- package replacement, purge and row change retire any exposure observation through the existing owner. the persistent refusal and current preflight outcome never outlive or attach to another row.

reviewer docs can keep UpgradeRequired / UpgradeBlockedByStorage / UpgradeFailed if these distinct visible remedies are intended. define UpgradeFailed as a known present converter limitation, not proof that original content is invalid. original/candidate disk overlap, local preparation wait and the proxy/source resource gates remain explicit prices. none of these states replaces completion of the supported-source migration contract.
