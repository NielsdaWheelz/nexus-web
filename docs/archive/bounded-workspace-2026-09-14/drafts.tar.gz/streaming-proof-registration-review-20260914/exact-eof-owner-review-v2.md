# exact eof owner disposition

status: reviewed draft; all execution pending. origin: 2026-09-14 client/root review. area: streaming proof sensitivity.

newly added proof paths require pr sensitivity. a whole-file kernel selection without a fault chooses base, where both nexus.api.storage_response and stream_object_checked are absent. delayed response import alone cannot repair that incompatibility; an import failure is not evidence for eof behavior. the earlier whole-file-only registration was insufficient for the same-run required sensitivity set.

the v2 registry keeps the whole-file ordinary owner and adds its existing exact module-level eof test as the single canonical node. the existing coherent-fault clause applies to the actual materialized-to-streaming interface cut: persisted-size integrity formerly completed before returning a whole byte string; streaming must withhold its last chunk until the same exact-eof fact exists. there is no base streaming implementation that this proof could exercise. no proof import, assertion, helper or parameter changes are proposed.

one new product-only fault moves release of the pending chunk before validation of the next chunk. the existing late-extra-byte parameter then emits abcdef although the required partial body is abcd; its unchanged named assertion is “stored object released the declared tail before exact EOF”. sdk close and storage error paths remain active. this targets the exact integrity behavior, not mere availability of the new interface. actual red and restored green remain required.

the pinned canonical source digest is 392e259aa8793d59539678ee2fc6e1976b5cfc7d4b4392e02f06363791be2d07. the unchanged complete kernel file is fce1b2980a460f937fe7e1d89b34b0632c8addf5bba318519d3b01efc8659ff7. the registered product patch is 51d26b7b23efa785cb9eda096caefcb0cf1e561efbd5391a4ab9bb12f3bf5bcf. all seven eof cases and the ordinary default/range and send-failure cases remain in the file.

canonical resolution maps the whole-file selection to this one exact node. workflow_sensitivity_request then selects its coherent fault even for an added path, provided the base revision is valid. no alias, allowlist, exception implementation, second fault for that owner, or controller change is needed. the price is one canonical node and one explicit pinned product fault. this does not qualify independent send-failure/cancellation behavior: retain its ordinary proof and separately observed auxiliary close-fault sensitivity. the private/public service base witnesses also remain required; the unchanged public privacy canonical fault proves only privacy.

v2 supersedes the earlier minimum-registry-v1, privacy-coherent-v1, and floor-v1 drafts. it retains the previously reviewed public privacy opt-in at 37d424f9a8a63269311f1a4cfde6d68162cb6956c04e885e3067cc26bd564d52 and adds only the eof fault row. the floor change is exactly nine risk/source entries over six paths and four proof ids over two files; no removals or capability changes. floor 9cd05ed8 becomes 316f8926. final-registry-inventory-v2.json records every preimage/postimage and patch hash.

complete product/proof stack patches 210f7107 and d309f561 are unchanged. the new inventory references them rather than rewriting their frozen inventory. no main changes, test execution, or policy execution occurred.
