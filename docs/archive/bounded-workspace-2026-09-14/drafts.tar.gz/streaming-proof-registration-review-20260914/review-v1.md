# streaming proof ownership review

status: draft only; all behavior execution pending
origin: 2026-09-14, sole delivery worktree at a25ab33c26855190d78218a7d0c365334791d3da
area: shared stored bytes and public transfer lifetime

## reviewed inputs

- shared product21faec4111dc2f2637a8dcdfd2845d665fb9f83b0211f73cafbabd501b9bcaa0; proof57dd7f85739eb9c15a99a499858836df94a73add86a202372c10d54b59cade0e.
- public PDF proof34fc2554fc3605b4c13df89ac279119fb7b27204ae54b8fcfd4205b5e3209926.
- current public extension producta0876e083a7379d13a9dc358e68a13c391c7b952a957343472a8bc8bb8901ae8; proof5aa384f6826828d5ad01cd03efe2736fb685ef28b3a846ee4a74c3102cc3ab11. these exact bytes include the direct masked error and its preserved storage cause. re-review the hash if its owner changes that late-error case again.

## minimum registration

minimum-registry-v1.patch adds shared storage client/read/response sources to the existing auth risk and runtime-health risk, plus epub-assets and oracle plate/service route sources to runtime health. media-assets/read-admission are already owned there. public routes/services already map to the existing public whole-file proof; no second public canonical is added.

runtime health gains the new private service file plus its single exact first-transfer canonical, and the new kernel whole-file owner. capabilities do not change. no floor edit, alias, fault row or coherent override is included in this patch. adding the absent storage_response source glob must occur in the same batch as the actual module; it must not be activated alone.

## BASE-applicable source-ordering and public admission

all these exact nodes import only product interfaces that already exist before the streaming change; external peers and real PostgreSQL/Minio remain their authority. use the committed pre-streaming delivery a25ab33c26855190d78218a7d0c365334791d3da for the closest explicit BASE candidate, subject to actual execution. the intended smaller historical 318747 base also has all imported product module paths.

- private canonical: pytest:python/tests/service/test_storage_asset_streaming.py::test_stored_asset_sends_bounded_bytes_before_reading_the_complete_object. old eager service returns after consuming all bytes; named red is `stored asset was fully materialized before the first body transfer`.
- public file auxiliary: pytest:python/tests/service/test_public_resource_sharing.py::test_public_file_keeps_transfer_capacity_until_its_cancelled_sdk_read_finishes. old public route lacks transfer admission, so the actual concurrent request must falsify `public file bypassed occupied transfer capacity` (the actual earlier retirement assertion may also fail). first SDK read is held through caller cancellation; this does not require new StorageResponse imports.
- public asset auxiliary: pytest:python/tests/service/test_public_resource_sharing.py::test_public_asset_stream_preserves_bytes_and_masks_private_sources. old eager asset must falsify `public asset was fully materialized before its first body transfer` after actual token/handle rejection and exact-body checks.

explicit pytest node requests remain exact in current canonical_proof, so the two public auxiliary BASE selections do not require registry aliases or stealing the anonymous-link canonical owner. collection/setup failures are not these reds. existing first-byte header/error checks are ordinary compatibility evidence, not automatically sensitive to streaming.

## new EOF and close protocol kernels

one new kernel file contains genuinely distinct EOF, parser-default/range, and send-failure-close oracles. it imports the new StorageResponse at module scope. old BASE cannot collect it; registering a fault on this materially new owner still makes automatic changed-owner workflow choose BASE unless a coherent exception is added. an import-failure exception would violate this review's constraint.

recommend one whole-file registry owner without a permanent fault row for this initial cut, and retain two separately reviewed temporary product counterfactual runs through `./scripts/test changed python/tests/kernel/test_storage_streaming.py`:

1. shared eof-fault.patch moves the previous pending yield before the next chunk's size check. the exact-prefix-plus-excess case must fail `stored object released the declared tail before exact EOF`; it retains SDK size errors rather than fabricating corruption.
2. shared close-fault.patch omits only the explicit response close. the send-failure test must fail `send failure abandoned the opened storage body`; a ordinary exhausted EOF read often closes its generator independently and is not sufficient evidence for this fault.

restore exact current product hashes between these ordinary fault/green runs and retain their real summaries. do not claim an automated registered-fault gate from these auxiliary sensitivities. the draft fault patches also lack git diff headers, so they cannot be inserted directly into the registered fault manifest. if permanent automatic faults are required now, stop for a coherent owner design decision; splitting files does not itself solve absent BASE imports, and no new test-only module adapter is justified.

## public existing canonical ownership

the current public-share-subject-identity-bypass row has NO changed_owner_red or changed_owner_sha256. its ordinary exact canonical and the whole-file ordinary selection already exist. current exact owner is facd53263fb76ce846b4b846050e01a1fd10cfcd7ad77b2fdad77ebca7c5c823; reviewed extension changes it to 37d424f9a8a63269311f1a4cfde6d68162cb6956c04e885e3067cc26bd564d52 through imports and three new shared helpers only. the original anonymous-link test and _seed_pdf bytes are identical; its body sha is e2ddc595511614714b54e636568eafa7da81767b51daa8d4e1363184ba2d835a.

automatic changed-owner BASE would therefore rerun the unchanged privacy scenario and should remain green. this is a real ownership disposition requirement, not permission to infer sensitivity for the new streaming scenarios. the smallest same-file choice, requiring explicit parent approval, is a coherent-fault declaration on this EXISTING privacy fault at exact37d424..., justified only by behavior-preserving shared proof support and an unchanged privacy oracle. it does not solve a missing module: all public imports already exist on BASE. the new streaming cases still need their own explicit BASE/counterfactual evidence above. if that exception is not accepted, the distinct public lifetime/source tests need a separate physical owner and independently prepared source fixture; never change the old privacy canonical to one of them.

no public pin patch is supplied until that policy choice is accepted; no old pin is silently refreshed.

## additional lifetime sensitivities and limits

- private third-read/close and public third-read/close tests cannot claim eager BASE sensitivity: the old default 8 MiB read can consume these small fixtures before a third read occurs. missing the barrier is not the intended lifetime red. use the candidate's exact omitted-close counterfactual, retaining close-before-retirement assertions, or a narrow route-admission removal for the corresponding image/transfer branch.
- public asset image-admission removal should fail its saved live-occupancy observation; run the explicit public asset lifetime node, not the old anonymous-link canonical. transfer admission is independently exercised by the BASE-applicable public-file cancellation case; full/ranged deadline/disconnect variants add candidate composition evidence.
- selected-publication and package routes also adopt StorageResponse. preserve their existing generation/account/token/range/byte proofs in the enclosing ordinary selection. private/public asset proofs do not by themselves establish physical cancellation on those two adapters, accepted maximum sizes, throughput, server private memory or image decode admission.
- no source-sized decode or accepted 25 MiB/100 MiB concurrency qualification follows from these small transfer-ordering and ownership proofs.
