# native transfer retry floor metadata review

status: drafted; actual canonical and auxiliary execution pending. origin: 2026-09-14, delivery 64fa3956122f5a1c653d5fa758cd259f14eb0395. area: native host proof ownership.

complete-metadata-v1.patch changes only three existing fault rows and two patch contexts. no proof/source/floor/capability additions, duplicate owners, aliases, or policy exceptions are introduced. source/proof patches remain e094c28d and b58c9ee5.

## canonical owner disposition

- origin client: whole-file pin 57e5cc3f becomes 9a302fe8. two new tests are appended; all previous tests, imports and support are unchanged. the selected-generation mint mutation, file bytes, and “download selection changed before mint” assertion are unchanged. existing coherent mode remains necessary for the whole-file candidate which now references the new refusal property. the unchanged fault applies to the final candidate.
- scheduler/store boundary: add existing coherent mode with whole-file pin 8646a8a3; prior unpinned file was 15a70e97. one assertion import and two new tests are added, all original cases and support unchanged. old base lacks the added durable-floor method/property and has the former callback contract; whole-file base execution cannot establish the retained starvation behavior. retain the existing starvation mutation, removing only the deferred-pair exclusion. its rebased patch keeps the independent new floor predicate. “preparing publication blocked another transfer” remains unchanged.
- database: whole-file pin b7f39800 becomes 63566eb2. the existing schema-1 fixture now removes the new schema-4 column when reconstructing historical schema 1 and expects current version 4. its literal original retained-row equality, exact source cursor, no-invented-derived-data, foreign-key and table checks remain. a distinct schema-3 migration case is added. the retained-size fault still changes only copied size_bytes to size_bytes + 1 inside the same v1 rebuild; context indentation changes because that unchanged rebuild now sits inside the v1 branch. “database upgrade changed retained rows” remains unchanged.

all three final fault patches pass git apply --check against the supplied candidate source. no behavior or policy command was run. pinning and patch applicability are prerequisites, not sensitivity receipts.

## same-run pr and independent new behavior

current selection requires sensitivity for changed whole-file gradle owners. the three canonical owners already have one registered product fault each. the reviewed coherent pin updates/opt-in allow the normal same-run pr sensitivity portfolio to run each retained fault against the full candidate instead of accepting a compilation or schema-setup failure on base. no registry/floor remapping is needed because all three owners and six product paths already have current ownership.

these retained canonical faults do not demonstrate the newly added retry-floor behavior. the complete ordinary selection must run all three gradle classes, then the supplied auxiliary candidate faults need their own paved red/restored-green receipts:

- origin-floor-fault.patch: whole OfflineReadingOriginClientTest; “capacity refusal lost or shortened the server floor”.
- eligibility-fault.patch: whole OfflineReadingSchedulerStoreBoundaryTest; “server floor admitted an early transfer”.
- idle-retry-fault.patch: the same scheduler/store owner, separately; “durable deferred work lost its OS retry”.
- migration-floor-fault.patch: whole OfflineReadingDatabaseTest; “schema three transfer acquired an invented delay”. the new default changes only the actual upgrade-added field, leaving the before/after old-column comparison intact.

auxiliary mutations are temporary, one at a time, and must be removed with exact source hashes restored between runs. they are not additional registered faults for an already owned file. their actual behavioral receipts remain separate from the automated same-run canonical set; absence of those receipts leaves the new behavior unqualified even if the pr canonical portfolio passes. no claim about actual device wake timing, full jobservice-to-origin operation, or physical background delivery follows from these host classes.

inventory-v1.json contains exact main/candidate owner hashes, old/new mutation hashes and complete metadata preimages. root must independently review this disposition before applying the metadata. all four proposed auxiliary fingerprints remain unobserved.
