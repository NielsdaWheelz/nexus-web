# retry floor forwarding lacks a composed host proof

status: open; append to the existing retry-after ticket if it owns this same acceptance. origin: 2026-09-14 runtime/client review of product e094c28d and proof b58c9ee5. area: native offline transfer.

the new origin proof observes the parsed response floor, and the store proof calls deferForServerCapacity directly. neither executes the actual capacity catch in apps/android/app/src/main/java/app/nexus/android/offline/reading/OfflineReadingTransferJobService.kt:384. replacing refusal.retryNotBefore with null at that call leaves those new proofs unchanged. this is a source-confirmed coverage gap, not an observed behavioral failure.

prerequisite: integrate the reviewed native source and preserve the current run/account/staging authority fences. add the smallest existing jobservice host composition that receives a real origin capacity refusal, observes its persisted floor, and rejects an early subsequent claim. retain existing cancellation/account replacement behavior; no new scheduler or physical-device timing claim.

acceptance: the actual forwarding mutation fails the composed proof at the persisted-floor or early-claim assertion, restored source passes, and exact red/green receipts are retained. canonical legacy faults and the four separate new parser/store/migration auxiliary faults do not close this boundary.
