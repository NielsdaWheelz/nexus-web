    @Test
    fun `known original grapheme limitation is durable until explicit retry without losing source or progress`() {
        // q has no precomposed acute form. This is valid original NFC text and
        // exactly one 65,537-code-point grapheme after an ordinary prefix.
        val canonical = "reader text q" + "\u0301".repeat(65_536)
        val fixture = InstalledLegacyReadingFixture(temporary.newFolder(), "<p>$canonical</p>", canonical)
        val original = row(fixture.database.readableDatabase, "offline_reader_packages")
        val pending = row(fixture.database.readableDatabase, "offline_reader_progress_pending")
        val baseline = row(fixture.database.readableDatabase, "offline_reader_progress_baselines")
        val originalHash = File(fixture.installedDirectory, "reader.json").sha256Hex()
        val migration = File(fixture.root, "${fixture.binding}/.staging/${fixture.packageId}.migration")
        var attempts = 0
        val durability = object : OfflineReadingDurability {
            override fun syncTree(directory: File) = HostReadingFilesystemDurability.syncTree(directory)
            override fun syncDirectory(directory: File) {
                if (directory == File(migration, "publication")) attempts += 1
                HostReadingFilesystemDurability.syncDirectory(directory)
            }
        }
        fun openStore(database: OfflineReadingDatabase) = OfflineReadingStore(
            fixture.context, database = database, seal = fixture.seal,
            rootDirectory = fixture.root, durability = durability,
            integrityExecutor = Executor(Runnable::run),
            progressOriginFactory = OfflineReaderProgressOriginFactory { error("local refusal must not contact the origin") },
        )
        try {
            assertTrue(fixture.reader.size < OFFLINE_READING_MAX_READER_JSON_BYTES)
            val declared = JSONObject(File(fixture.installedDirectory, "manifest.json").readText()).getJSONArray("entries").getJSONObject(0)
            assertEquals(fixture.reader.size.toLong(), declared.getLong("sizeBytes"))
            assertEquals(originalHash, declared.getString("sha256"))
            assertEquals(canonical, JSONObject(fixture.reader.toString(Charsets.UTF_8)).getJSONArray("fragments").getJSONObject(0).getString("canonicalText"))
            val store = openStore(fixture.database)
            assertEquals(OfflineReadingAvailability.UpgradeFailed, store.snapshot().items.single().availability)
            assertEquals(1, attempts)
            assertThrows(IllegalStateException::class.java) { store.open(fixture.media) }
            val refused = original + ("conversion_refusal" to "GraphemeExceedsUnitCapacity")
            assertEquals("known limitation changed another installed field", refused, row(fixture.database.readableDatabase, "offline_reader_packages"))
            store.reconcile()
            assertEquals("automatic reconciliation repeated the refused conversion", 1, attempts)
            fixture.database.close()
            OfflineReadingDatabase(fixture.context, fixture.databaseName).use { reopened ->
                val retained = openStore(reopened)
                assertEquals(OfflineReadingAvailability.UpgradeFailed, retained.snapshot().items.single().availability)
                assertEquals("process recreation repeated the refused conversion", 1, attempts)
                assertEquals(refused, row(reopened.readableDatabase, "offline_reader_packages"))
                assertEquals(pending, row(reopened.readableDatabase, "offline_reader_progress_pending"))
                assertEquals(baseline, row(reopened.readableDatabase, "offline_reader_progress_baselines"))
                val retried = retained.retry(fixture.media)
                assertEquals("explicit retry did not attempt the original source", 2, attempts)
                assertEquals(OfflineReadingAvailability.UpgradeFailed, retried.items.single().availability)
                assertEquals(refused, row(reopened.readableDatabase, "offline_reader_packages"))
                assertEquals(pending, row(reopened.readableDatabase, "offline_reader_progress_pending"))
                assertEquals(baseline, row(reopened.readableDatabase, "offline_reader_progress_baselines"))
                assertEquals(originalHash, File(fixture.installedDirectory, "reader.json").sha256Hex())
                assertTrue(fixture.reader.contentEquals(File(fixture.installedDirectory, "reader.json").readBytes()))
            }
        } finally { fixture.close() }
    }

    @Test
    fun `filesystem preparation failure stays retryable and does not become a converter refusal`() {
        val fixture = InstalledLegacyReadingFixture(temporary.newFolder())
        val original = row(fixture.database.readableDatabase, "offline_reader_packages")
        val pending = row(fixture.database.readableDatabase, "offline_reader_progress_pending")
        val baseline = row(fixture.database.readableDatabase, "offline_reader_progress_baselines")
        val migration = File(fixture.root, "${fixture.binding}/.staging/${fixture.packageId}.migration")
        var fail = true
        val durability = object : OfflineReadingDurability {
            override fun syncTree(directory: File) = HostReadingFilesystemDurability.syncTree(directory)
            override fun syncDirectory(directory: File) {
                if (fail && directory == File(migration, "publication")) {
                    fail = false
                    throw IOException("controlled filesystem failure before derived units")
                }
                HostReadingFilesystemDurability.syncDirectory(directory)
            }
        }
        try {
            val store = OfflineReadingStore(fixture.context, database = fixture.database, seal = fixture.seal,
                rootDirectory = fixture.root, durability = durability, integrityExecutor = Executor(Runnable::run))
            assertFalse("filesystem fault did not reach preparation", fail)
            assertEquals(OfflineReadingAvailability.UpgradeRequired, store.snapshot().items.single().availability)
            assertEquals(original, row(fixture.database.readableDatabase, "offline_reader_packages"))
            assertEquals(pending, row(fixture.database.readableDatabase, "offline_reader_progress_pending"))
            assertEquals(baseline, row(fixture.database.readableDatabase, "offline_reader_progress_baselines"))
            assertTrue(fixture.reader.contentEquals(File(fixture.installedDirectory, "reader.json").readBytes()))
            store.reconcile()
            assertTrue("resource recovery did not retry conversion", store.snapshot().items.single().availability is OfflineReadingAvailability.Ready)
            assertNull(row(fixture.database.readableDatabase, "offline_reader_packages").getValue("conversion_refusal"))
            assertEquals(pending, row(fixture.database.readableDatabase, "offline_reader_progress_pending"))
            assertEquals(baseline, row(fixture.database.readableDatabase, "offline_reader_progress_baselines"))
        } finally { fixture.close() }
    }

    @Test
    fun `ordinary source mapping failure propagates without a durable converter limitation`() {
        // Deliberately inconsistent attested local bytes exercise the defect
        // branch; this fixture is NOT an admitted-source capacity witness.
        val fixture = InstalledLegacyReadingFixture(temporary.newFolder(), "<p>other words</p>")
        try {
            val original = row(fixture.database.readableDatabase, "offline_reader_packages")
            val pending = row(fixture.database.readableDatabase, "offline_reader_progress_pending")
            val baseline = row(fixture.database.readableDatabase, "offline_reader_progress_baselines")
            assertThrows(IllegalArgumentException::class.java) {
                OfflineReadingStore(fixture.context, database = fixture.database, seal = fixture.seal,
                    rootDirectory = fixture.root, durability = HostReadingFilesystemDurability,
                    integrityExecutor = Executor(Runnable::run))
            }
            assertEquals(original, row(fixture.database.readableDatabase, "offline_reader_packages"))
            assertEquals(pending, row(fixture.database.readableDatabase, "offline_reader_progress_pending"))
            assertEquals(baseline, row(fixture.database.readableDatabase, "offline_reader_progress_baselines"))
            assertTrue(fixture.reader.contentEquals(File(fixture.installedDirectory, "reader.json").readBytes()))
        } finally { fixture.close() }
    }

