# pdf localization retirement integration

status: l10n-only client source passes its complete post/patch owner; combined main replay pending.
origin: client proof worktree, 2026-09-14.

actual corrected-proof baseline red: `be8ff5fd9322fcac`, “pending PDF write retained
the retired source DOM”. l10n-only green: `7c0e3c428b6814cb`. both use the same
selector-backed browser proof bytes. the earlier selection-identity candidate
is absent from both sources and is not included in this bundle.

`7169ec7b50a1d70a/retainer-pdf-region.json` supplies the narrow synthetic diagnostic:
`window.pdfjsLib` -> `AnnotationEditor._l10n` -> `GenericL10n.#elements` -> retired
pdf reader region. the installed public `destroy()` disconnects and clears
those localization roots synchronously. `setDocument(null)` alone does not.
no heap snapshot is retained or proposed for integration.

`pdf-localization-retirement.patch` is the exact root-reviewed source patch,
sha `22d04c23c0ab629113b4d473a55951ecbb175246eb68009c77a87f2698f40bc8`.
it adds only the public typed `l10n.destroy()` capability and calls it in the
existing viewer teardown. rejection goes to existing client defect telemetry;
it cannot publish a teardown error into a replacement reader's UI. no viewer
loading, worker destruction, source identity or selection behavior is changed.

`inventory.json` names exact patch preimages/current client/main hashes.
`client-before/` reconstructs the original patch preimage from the held candidate
and retains the same proof. `main-observed/` was read twice without drift.
`main-reconciliation-draft.patch` applies only the two source hunks and adds the
actual proof. its sole proof adaptation removes client-only `expiresAtMs:null`
from main's existing immutable `{url}` source shape. all collection, worker,
post/patch acknowledgment and exact quote assertions remain unchanged.

main's existing `pdfReaderSession` helper now calls the source factory with its
argument object and uses the shared member response builder. this bundle keeps
that helper. support bytes are retained for review only. the broad
`main-to-client-review-only.diff` MUST NOT be applied; it includes unrelated
incoming source changes. no main files were written.

acceptance limits: this proves retirement while actual post and patch replies
are held, followed by exact acknowledged id/quote delivery. it observes the
real pdf worker's removal before collection. it does not qualify maximum binary
or multi-pane memory, and it does not replace the final coupled loading,
reattachment, selection and capacity gates. no new fault row or coherent owner
pin is included.

root integrated the reviewed slice and the hosted-source proof call correction.
combined focused replay `e7dfd613c31bfce0` at `86c0986` passes all five selected
cache/session/window/body/pdf owners and selected web static. receipt retained.
this supersedes the pending combined-replay note above; maximum composition and
canonical sensitivity remain separate.
