status: open
origin: 2026-09-14 bounded-workspace capacity run f52060eb73f93122
area: test-controller background image composition

actual epub source completion schedules follow-up metadata jobs. the isolated worker
has no configured Codex catalog socket; `enrich_metadata` fails with
`CodexGenerationUnavailable: Codex catalog host is unavailable`, wrapped by
`GenerationCatalogRefreshError`. the retained worker log in
`nexus-web-bounded-web-proof/test-results/runs/f52060eb73f93122/api-capacity-candidate-worker-epub.json`
records the actual child failures after source publication.

compose the required existing local external-provider fixture/capability, or define
and execute an explicitly scoped source-preparation boundary without claiming the
follow-up generation path. do not swallow jobs, fake successful metadata, dispatch
paid providers from this lane, or treat missing composition as product availability.

acceptance: the named capacity profile states and exercises its complete composition;
required background work has real successful outcomes and no hidden missing-service
failures. separate provider qualification remains explicit.
