# positioned reader cursors do not identify their source publication

- status: open; source-level consistency gap
- origin: 2026-09-13 bounded-workspace spec adversarial review; checkout `7fa89b88c8342bca9edfb46a6d20053c49555fb2`
- area: canonical reader progress / publication replacement

`python/nexus/services/consumption/_reader_cursor_store.py` stores and reads a
locator and cursor revision without the publication generation that gave those
coordinates meaning. `services/consumption/offline_reader_progress.py:22-40`
returns that cursor alongside the current publication generation. replacement
can therefore pair old cursor coordinates with a newer generation. an atomic
generation check on a later write does not identify the old cursor's source.
this is not allocation evidence or a demonstrated cause of the api memory kills.

prerequisites: define source identity for positioned document cursors separately
from cursor compare-and-swap revision and the current publication pointer.

fix: persist and return the source generation with positioned document cursors;
set it under the existing atomic generation/cursor write boundary. historical
unprovable provenance must remain explicitly unresolved, not backfilled from
the current pointer by assumption. preserve locator, revision, authored intent,
reset fencing, and the separate transcript contract.

acceptance: publication replacement cannot relabel an existing positioned
cursor. migration preserves unknown provenance and pending work; exact-generation
replay and explicit reconciliation work through hosted/native paths. demonstrate
sensitivity and correctness through `./scripts/test`.
