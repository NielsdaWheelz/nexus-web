# recent nexus history loads every usage row

- status: open
- origin: 2026-09-13 second-tab investigation; revision `7fa89b88c8342bca9edfb46a6d20053c49555fb2`
- area: nexus history api memory and query work

## evidence

`python/nexus/services/nexus_history.py:41-66` loads and materializes every usage
row for the viewer, then keeps only five distinct recent targets in python.
the selected rows include visit timestamps and other fields unused by recency.
deployed revision `7e8fd48244b3b436965037738e05785bb4931be1` has the same code.
the initial history read therefore grows with lifetime usage despite its
five-result output bound. this is a static scaling hazard, not measured incident
causality.

## prerequisites and fix

retain the current definition of recency and tie-breaking; inspect the actual
history size and query plan. select the latest row per target and the five newest
targets in sql, project only the recency fields, and choose indexes from the
measured plan. preserve independent frecency semantics.

## acceptance

through `./scripts/test`, compare returned recency against an independent
ordering oracle over repeated targets and tied timestamps; establish that the
application materializes only the bounded recency result for a large history.
capture the current implementation failing that budget before accepting the fix.
