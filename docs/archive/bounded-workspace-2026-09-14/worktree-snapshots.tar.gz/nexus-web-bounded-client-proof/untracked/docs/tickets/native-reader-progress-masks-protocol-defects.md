status: open
origin: 2026-09-14 bounded-workspace native progress review
area: native reader progress HTTP boundary

`HttpOfflineReaderProgressOriginClient.kt:117–123` catches all successful-body
`IllegalArgumentException` failures as modeled Server errors and other exceptions
as Network errors. wrong account/generation headers and malformed owned JSON can
therefore become silent pending retries in `OfflineReaderProgressSync.kt:78–87`,
without reaching the newly explicit per-media defect reporter. this is source
inspection evidence; the real HTTP regression has not run.

retain modeled HTTP/transport availability and auth/source outcomes. classify
successful owned-protocol violations as defects, preserve exact stored intent,
and keep their reporting/content privacy contract. reuse existing native HTTP
and durable progress owners; do not catch arbitrary exceptions as network loss.

acceptance: actual controlled HTTP responses exercise malformed successful JSON,
wrong attestation, real transport failure and owned availability outcomes; protocol
defects remain visible, pending rows survive, and unaffected writers can complete.

inspection refinement: `StrictJson.parse` decodes UTF-8 and uses Moshi over an
in-memory buffer. malformed completed bytes can throw IOException subclasses;
a broad IOException catch around parsing would still hide the protocol defect.
limit transport translation to HTTP execute/body reads. cookie persistence
failures also belong outside that translation. the reviewed existing session
factory dependency is staged mechanically, with actual malformed JSON/UTF-8,
attestation, cookie-persistence and transport/HTTP outcome cases; the old catches
remain until the regression is observed.
