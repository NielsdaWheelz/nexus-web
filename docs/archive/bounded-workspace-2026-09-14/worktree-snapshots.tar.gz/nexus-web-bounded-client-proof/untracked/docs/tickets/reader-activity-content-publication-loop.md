# reader activity publication re-registers its own observer

- status: open
- origin: 2026-09-14 composed reader navigation, run `034f4c3447fd722e`
- area: hosted document activity

`MediaPaneBody.tsx` passes a new publication activity-content wrapper on every render. `ReaderActivityAdapter.ts:197` depends on that object when registering its observer. after trusted wheel input starts recording, cleanup unregisters the observer, publishing recording=false; setup publishes true again. the body subscribes to those snapshots and repeats until react throws “maximum update depth exceeded.” the actual component run fails through adapter cleanup line 194 and `activityRuntime.ts:731`; its reader unmounts before the scroll oracle.

fix the existing registration effect to depend on the actual source/content facts rather than wrapper identity. preserve source replacement, idle tracking, trusted input, and recorder eligibility. no second recorder or registration owner.

acceptance: actual composed trusted scrolling preserves the mounted reader and records movement without an update loop. unchanged source publications retain one observer; source retirement still unregisters it. the pre-fix run above is the actual red witness.
