status: open
origin: 2026-09-14 bounded-workspace run 66a2d2004332e575
area: nexus history / database work

`python/nexus/services/nexus_history.py:58` computes every distinct target before
limiting recents to five. real postgres at 100,000 retained rows sorts all 100,000,
spills 10,392 kib, and takes 601.714 ms in explain analyze. the existing candidate
frecency query returns only 190 indexed rows in 2.779 ms.
receipt: `test-results/runs/66a2d2004332e575/nexus-history-growth.json`.

preserve exact distinct-target order, latest label/source, tie breaking and scores.
review the existing recency index and mutation owner before choosing a query or
stored projection. do not truncate candidate rows before deduplication.

acceptance: actual retained-growth and highly repeated-target fixtures preserve
results without a full-history sort; record query plans and bounded materialization,
then qualify the actual api overlap and cold-read scope.
