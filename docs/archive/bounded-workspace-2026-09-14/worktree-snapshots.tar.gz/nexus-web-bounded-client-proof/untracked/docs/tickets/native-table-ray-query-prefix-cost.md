status: open
origin: 2026-09-13 bounded workspace native geometry qualification
area: offline table header context

unactivated `OfflineReadingTableGeometry.kt::intersecting` bounds returned rows
with keyset pages, but its ordinary btree still examines a source-sized prefix
for a tiny late slot. native receipt `792026fe6800d47c` at `d5b330da07` retains
actual sqlite measurements: 16 tiny queries cost 0.077–0.160s at 65,536 cells
and 0.301–0.576s at 262,144 cells. repeating that query for each principal
row/column would multiply the source scan for large spans.

the selected-header event candidate now skips impossible axes and pages group
headers directly (`ffab9e7615993229`), but still rescans active endpoints at
each inner band. actual canonical `acadb25b123d1f06` at `f3df479f1a` observes
1,000/2,000 overlapping headers taking 8.37/17.02 seconds to first page, with
3,001,000/6,002,000 endpoint visits despite only 2,000/4,000 changed unique
cell spans. actual EPUB sanitizer/table projection attests those rectangles
in `48899c7db2a2eae1`; this is far below the existing encoded source envelope.
web sanitization removes scope, tracked separately in oi-162.

the query-private disk interval tree passes `44ae28f4a554d64e`; those first
pages improve to 1.915/3.507 seconds, with 86,760/187,520 node reads instead
of 3m/6m endpoint visits. scratch grows to 393,216/688,128 bytes. maximum
source, repeated selection, physical temp storage and device costs remain
unqualified. this is an improvement, not closure of the latency/activation gate.

the scalar cursor correction plus expanded source proof passes
`31bf96457f77a5a8` at `5608675026`, but 8,000 headers still take 5.624s to
first page (750,744 encoded reader bytes). source index is 1,048,576 bytes,
query scratch 2,580,480 bytes; 852,080 node reads cost 1.624s and interval
state/opacity work 2.807s. late irrelevant 65,536/262,144-cell tables take
46.9/90.8ms despite zero decoded candidates. fixed returned pages alone do
not qualify foreground work.

first finalize the sparse immutable cell/header semantics. choose and measure
one selected-cell association algorithm that merges equivalent geometric events
or uses a justified interval index; do not emit all-cell header associations or
silently reduce the supported source envelope. the exact index is now built and revision-bound before package activation;
its selected-query costs remain a candidate, not a release-qualified budget.

acceptance: exact normative header corpus plus maximum supported encoded-source
shapes (large implied rows, long spans, overlaps/gaps, groups, many headers),
bounded retained pages/heap and measured query work/time. attested members and
revision-bound derived files must retain separate closure/accounting under the
existing package installation owner. actual device qualification remains required.
