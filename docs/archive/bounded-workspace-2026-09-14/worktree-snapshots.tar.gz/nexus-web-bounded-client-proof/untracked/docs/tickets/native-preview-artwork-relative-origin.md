# native preview artwork lacks its owned origin

- status: open
- origin: 2026-09-13 bounded-workspace image caller survey
- area: native playback preview / artwork delivery

`python/nexus/services/browse/podcast_index.py:411` emits a relative
`/api/media/image?url=...` URL. the web browse contract preserves this as
`MediaImageProxySrc`; native `PlayerProtocol.kt:975` decodes preview `imageUrl`
as a plain string. `NexusPlaybackService.kt:1504` gives that relative URI to
media3 `setArtworkUri` without an owned origin. default media3 datasource URI
handling cannot interpret that path as the authenticated hosted API origin.
canonical playback artwork is different: `consumption/_projection.py:262`
passes the remote podcast image URL directly.

reuse existing exact hosted-origin construction for proxy preview artwork,
and preserve its account/auth delivery requirements. coordinate any measured
proxy admission with this actual caller's bounded recovery; do not add API
retry behavior to canonical artwork that bypasses the API.

acceptance: a native preview's relative proxy artwork reaches the configured
owned origin with the required auth, external/ambiguous paths are rejected,
and an admission response has a real delivery/recovery owner.
