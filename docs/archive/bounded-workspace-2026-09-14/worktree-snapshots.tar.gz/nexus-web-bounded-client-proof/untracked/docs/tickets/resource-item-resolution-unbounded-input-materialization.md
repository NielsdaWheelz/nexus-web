# resource resolution has no request or result allocation bound

- status: open
- origin: 2026-09-13 bounded-workspace runtime survey
- area: foreground resource queries

`python/nexus/api/routes/resource_items.py:41` accepts `refs: list[str]` with no
count or byte limit, then resolves and materializes every requested resource in
one list. the route accepts caller-sized work even with concurrency admission.

prerequisite: inventory callers and the maximum supported resource-reference
batch. reuse existing bounded batch request primitives and metadata projections;
reject oversized bodies before JSON materialization and reject invalid batch
shape explicitly. do not truncate requested results.

acceptance: maximum supported batch succeeds with bounded response allocation;
one-over-limit and oversized-wire requests fail before materialization; ordinary
workspace callers retain complete results.
