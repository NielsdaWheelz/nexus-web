status: open
origin: 2026-09-14 bounded workspace review; known native snapshot `905f5b7f52`
area: native verification provenance

main contains changes beyond the reviewed anchor-preparation cut:
`OfflineReadingStore.kt` adds free-space admission and changes sync/defect reporting;
`OfflineReaderPublicationVerifier.kt` adds origin-based find admission;
`OfflineReaderPublicationFixture.kt` changes range-window and boundary construction.
the current native agent did not author those changes in this resumed turn.

preserve the edits, establish their contracts and review their complete diffs.
keep them out of the current narrow snapshot until reviewed. the invalid unit-edge
rule has its own ticket. no receipt for the older snapshot attests these bytes.

acceptance: reviewed ownership and contract disposition, followed by applicable
behavior/sensitivity proofs over the final exact source and fixture bytes.

root independently reviewed the store and synchronizer deltas: per-media
defects preserve pending intent and allow other writers to continue; an
unrecognized accepted cursor remains a durable conflict. the disk check is an
availability preflight, not a reservation or expansion bound. two real sqlite
lifecycle cases now assert pending/source/baseline conservation after reopen;
their sensitivity is pending. algorithm-only outcome strings do not close it.

word-origin review and both auxiliary sensitivities passed `87bdfdf09a940a3a`
and `fb24cd882f6dc595`. the range fixture's separate render-text correction is
reviewed and awaits its original byte-volume fault replay. older snapshots do
not attest these final source and fixture changes.

HTTP snapshot audit also found prior main-only changes in
`OfflineReadingOriginClient.kt` (clock injection, named constants and polling
comment), `OfflineReadingOriginClientTest.kt` (clock-bound cases and account
attestation) and its `OfflineReadingAccountAttestor` constructor dependency.
these are not part of the progress HTTP catch correction. review their exact
source/test diffs before the next full native snapshot; a selective HTTP
regression can reuse the prior loopback boundary without importing them.
