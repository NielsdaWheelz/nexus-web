status: open
origin: 2026-09-14 bounded-workspace source receipt review
area: capacity fixture identity

`reader_capacity_sources.py:80` uses `epub_fixtures.py:53` with
`ZipFile.writestr(path, content)`, which supplies the current archive timestamp.
identical chapter bytes therefore have different source archive hashes in
`f52060eb73f93122` and `8bb58bd302499f69`. their canonical chapter hashes agree;
they are not identical whole archives despite identical source shape.

use explicit deterministic zip entry metadata in the existing fixture owner.
preserve all member paths, bytes, compression and old committed archives.

acceptance: repeated construction has identical complete archive bytes/hash;
new capacity receipts preserve that identity and all existing source assertions.
