# image admission needs a matching client delivery owner

status: open
origin: 2026-09-13 bounded-workspace qualification
area: foreground image memory / client availability

`apps/web/src/components/ui/MediaImage.tsx` sends unoptimized image URLs directly
to native image loading. `lib/player/mediaSession.ts` also publishes proxy URLs
to the OS artwork consumer. neither consumes the JSON retry protocol or
`Retry-After`. a strict API image slot returning503 would strand otherwise valid
artwork after concurrent requests; a slot alone is incomplete.

prerequisite: measure remaining image fetch allocation with concurrent JSON,
progress and readiness. pair its resulting admission with bounded scheduling and
owned retry/recovery for all proxy consumers, or replace those consumers with
prepared artwork artifacts. preserve SSRF/content validation and private access;
do not reinstate the128mib resident byte cache or add an unbounded server queue.

acceptance: excess image demand stays bounded, foreground writes/reads retain
headroom, and all demanded visible/OS artwork eventually loads or exposes its
actual terminal failure. retain a real concurrency/recovery proof.
