# reader cursor saves fail during upstream outages

- status: open
- origin: 2026-09-13 second-tab investigation; user-provided production network evidence
- area: reader progress persistence

## evidence

the user observed `put /api/media/043e7f93-bff0-4e6d-8c2e-ff684288641c/reader-state`
returning `502` in `183 ms`, then `185 ms`, with the browser logging a failed
reader-cursor save. the failure also occurs independently of the workspace
crash. other endpoints returned `502` concurrently; this does not establish a
reader-specific server defect or show that cursor writes cause the shell failure.

the investigated deployed revision is
`7e8fd48244b3b436965037738e05785bb4931be1`; local revision is
`7fa89b88c8342bca9edfb46a6d20053c49555fb2`.

deployed `apps/web/src/lib/reader/useReaderProgress.ts:227-228` logs the observed
save failure and records a failed save; current code does so at `:312-313`.
`readerProgress.ts:292-301` preserves the latest queued/sent locator in memory.
the existing reader surface shows unsynced progress with retry
(`apps/web/src/app/(authenticated)/media/[id]/ReaderProgressHandoff.tsx:101-113`).
retry re-reads canonical state before writing (deployed hook `:660-677`, current
`:830-850`); an identical committed locator reconciles without a duplicate write
(`readerProgress.ts:177-190`). pending work does not survive owner teardown;
see [the separate lifecycle ticket](second-tab-reader-cursor-teardown-durability.md).

## prerequisites and fix

correlate the failed write with the upstream outage investigation and distinguish
an uncommitted write from a committed write whose response was lost. verify the
reader persistence owner retains the latest unsaved cursor and reconciles it
without overwriting a newer cursor from another reader. repair the upstream
failure and preserve the existing unsynced/retry behavior. server writes already
compare the base revision and accept an identical locator idempotently
(`python/nexus/services/consumption/_reader_cursor_store.py:137-145`).

## acceptance

through `./scripts/test`, demonstrate that rejected and ambiguously completed
saves preserve the latest reader intent, recover after service restoration,
and respect the cursor concurrency contract. reloading resumes from the
acknowledged position. capture failed-write sensitivity and production evidence
of successful saves after the upstream repair. verify independently from the
workspace crash.
