status: open
origin: 2026-09-13 bounded reader integration
area: immutable publication figure admission

captured publication assets retain bytes/digest/type but no decoded geometry or
animation facts (`ReaderPublicationCapturedAsset` in
`python/nexus/schemas/reader_publication.py`). web preparation discards the
validated width/height when constructing this record
(`services/reader_publication_web.py:102`). epub preparation only verifies
asset bytes (`services/reader_publication_sources.py:140`). native's entry
contract permits 512 mib assets, with an 8 mib svg bound
(`OfflineReadingPackageContract.kt:13`). artwork's 4096-axis/static-derivative
policy therefore cannot establish document figure support.

prerequisite: attest actual raster type, oriented dimensions and animation frame
facts to the retained asset digest during preparation/local conversion; retain
the original asset. then measure browser/native decoder peaks for the existing
asset envelope and derive visible-demand admission/release limits. svg instance
expansion has its separate ticket. do not decode first and count afterwards,
freeze figure animation, or silently apply artwork limits to document content.

acceptance: actual retained figure rendering (including animation), stale-demand
withdrawal and source replacement stay within measured view/transition budgets;
maximum supported source behavior is explicit and complete. capacity feedback
alone is not evidence that the existing source envelope is supported.

review 2026-09-14: `publicationDom.ts:100-111` already defers image URLs;
no visible figure admission owner currently supplies them. web validation
checks only the initial oriented canvas, not animation facts; EPUB stores
raster bytes without geometry validation (`epub_ingest.py:871-897`). MIME
attestation is tracked separately in oi-166.

no decoder has been selected. [libvips's own checklist](https://www.libvips.org/API/8.16/Developer-checklist.html)
records a progressive JPEG thumbnail using roughly 4 GB where its sequential
encoding uses 72 MB. [its WebP loader](https://www.libvips.org/API/8.18/ctor.Image.webpload.html)
explicitly lacks shrink-on-load for animation. a thumbnail API alone is not a
resource bound. qualify the actual format/decoder path, including visible
animation and transient allocations, before choosing a budget or derivative.

2026-09-14 decoder inspection: pinned Pillow's GIF `n_frames` walks with
`update_image=False`, deliberately omitting later canvas growth. ordinary frame
`seek` can load the previous pixels and allocate disposal surfaces. ICO opens
and decodes its initially selected image; directory dimensions alone do not
attest other embedded PNG/BMP dimensions. neither is a metadata-only bound.
libvips, ImageMagick and ffprobe are absent from the current host and backend
image dependencies. `reader_publication_rasters.py` is a staged full-frame
preparation experiment, not activated capture or release qualification. measure
it through the existing physical worker reservation before choosing admission.

format closure also remains part of activation: web `IMAGE_FORMAT_MIME_TYPES`
accepts BMP and ICO, while `_verify_asset_signature` in
`offline_reading_packages.py` currently rejects their MIME types. preserve those
existing web formats through archive/native validation; do not classify them as
invalid merely because the new verifier omitted their signatures.

full-frame inspection is not yet a complete malformed-animation attestation:
pinned `PIL/GifImagePlugin.py::_seek` reports the same EOFError for an explicit
GIF trailer and missing bytes. `PIL/ImageFile.py::_get_oserror` also collapses
decoder allocation (-9), configuration (-8) and malformed decoding (-2) statuses
into plain OSError. qualify actual truncated-later-frame/browser behavior and
classify only established malformed results; unknown/system errors must preserve
the original and fail preparation. no generic OSError-to-InvalidImage catch.

native inspection 2026-09-14: java image-info dimensions alone do not expose
frame traversal. the public [ndk image-decoder header](https://android.googlesource.com/platform/frameworks/native/+/master/include/android/imagedecoder.h)
exposes fd ownership and animation frame advance/info from api 31, below the
existing offline minimum api 34. no jni owner or codec is selected. actual
shared gif 2×3-header/8×9-frame and ico 8×8-directory/32×32-png cases from
`test_reader_raster_facts.py` still need native observations; header dimensions
are not a parity proof. platform decoding also needs the explicit device gate.

2026-09-14 host capability inventory: pinned robolectric 4.14.1 contains
`ShadowNativeImageDecoder`, `ShadowNativeAnimatedImageDrawable` and their real
native bridges. public Java decoder behavior can therefore be probed on this
host. native-runtime 1.0.16 exposes skia C++ symbols, but no `AImageDecoder`
NDK exports; the Java bridge has no frame-enumeration API. private skia ABI calls
are not a supported production boundary and have not been used. no native
GIF/ICO dimension/frame parity has yet been observed.

independent Python raster source artifact is retained at publication-proof
`test-results/runs/3c5e13747bb3e4b8/reader-raster-source-facts.json`, sha256
`6930524638e1506dab43090c812700b7748ccade552b9da15ae5f01116fe2944`.
the entire command is now green `3c5e13747bb3e4b8`, including GIF/ICO,
orientation, WebP, BMP and AVIF cases. physical-handset verification is waived on this vps;
any following evidence must name the actual host/native boundary.

the [official ndk reference](https://developer.android.com/ndk/reference/group/image-decoder)
defines frame rectangles within the header width/height and frame advance as
animation traversal. neither statement establishes later encoded GIF canvas
growth or enumeration of ICO alternatives. actual native source observations
remain necessary before selecting this API for the shared all-frame facts.
