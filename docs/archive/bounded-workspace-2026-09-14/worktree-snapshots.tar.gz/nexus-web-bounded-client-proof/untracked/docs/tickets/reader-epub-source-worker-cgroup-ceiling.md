status: open
origin: 2026-09-14 bounded-workspace capacity run f52060eb73f93122
area: epub source preparation / worker memory

candidate `3d94f19f48` worker image `sha256:c5ca25a779482408fcd4e08acb02bc1eb3c52d82c2eda13b58e2b8aa79504489`
publishes the actual 67,108,864-byte HTML-plus-canonical source in 108.56 seconds,
but `memory.peak=469762048` equals its 448 mib cgroup limit; `memory.events.max=342`.
no oom or kill is observed. source sha256 is
`13e4fd7061b4d77ddc1984f205fa0bf787d448bb86ce96aecef51977074c90d6`.
receipt: `nexus-web-bounded-web-proof/test-results/runs/f52060eb73f93122/api-capacity-candidate-worker-epub.json`.

inspect source parsing, canonicalization, segmentation and publication live ownership;
remove unnecessary overlapping source representations before choosing measured capacity.
retain this exact sparse source, then qualify dense words and other accepted shapes.
the concurrent artwork fixture failed its file-permission setup, so that overlap is
not qualified even though worker pressure is independently observed.

corrected harness run `8bb58bd302499f69` at `cbafe2b6fe` verifies all 516 units,
original paths, word boundaries, find and quote resolution; artwork, progress and
readiness overlap all return 200. source completes in 109.55 seconds, but the worker
still peaks at 469,762,048 bytes with 715 ceiling events and no oom/kills. first
observed pressure includes 342,441,984 anonymous bytes and 70,164,480 file bytes.
worker image: `sha256:7cc31947933de3b047800c45cf48a70293e2601aeb4118595c448668c0e83dc8`.

acceptance: actual source completes with all source/locator/query assertions,
zero cgroup ceiling/oom events, responsive progress/readiness and actual artwork overlap;
record exact images, source hashes, full phase samples and required host reserve.
