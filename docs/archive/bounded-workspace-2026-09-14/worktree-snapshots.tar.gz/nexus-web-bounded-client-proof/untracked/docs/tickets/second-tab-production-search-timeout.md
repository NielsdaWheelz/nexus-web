# production search reaches its statement timeout

status: open; relationship to tab failure unconfirmed
origin: 2026-09-13 second-tab council; production `7e8fd48244b3b436965037738e05785bb4931be1`
area: search / foreground latency

retained `nexus-api-1` logs show `http.request.failed` for `get /search` at
`2026-09-13T03:23:03.157180Z`, request
`37593fd6-e86f-40c9-afe8-09d786ba25aa`, followed by an unhandled exception.
the associated content-chunk query reports a postgres statement timeout;
its candidate limit is 4000. no private query text is retained here.

prerequisite: compare the deployed retriever with the substantially changed
current `python/nexus/services/search/retrievers/content_chunks.py`; reproduce
the plan on representative local data. do not assume this remains unfixed in
the current implementation or that it caused the workspace exception.

fix: use indexed candidate selection, bounded intermediate work, and late
snippet construction where the measured plan requires them. verify the
supported corpus and latency budget before changing limits or indexes.

acceptance: the identified query shape stays within its deadline on realistic
local data with concurrent reader activity, with unchanged authorization and
independently checked ranking; retain read-only release evidence. do not
silence the exception or merely extend its timeout.
