status: open
origin: 2026-09-13 bounded workspace verification review
area: test controller / sensitivity

`workflow_sensitivity_request` (`sensitivity.py:488–563`) selects BASE for
changed whole-file owners even when the registered product fault is applicable.
against real base `7fa89b88c8342bca9edfb46a6d20053c49555fb2`, 49 changed
declared-fault vitest/gradle owners take that path. new native conversion classes
and reader source modules do not exist there; compilation/import failure cannot
prove the behavioral oracle. explicit candidate fault runs already demonstrate
real assertion failures, e.g. native list `d55a85e4810c5cde` and find
`582036fe1ac37426`.

prerequisite: explicitly review the existing coherent-fault exception's owner
contract. permit canonical whole-file vitest/gradle owners to opt in with exact
file-byte SHA-256, the existing product-only applicable patch, and expected
assertion fingerprint. keep BASE the default, reject qualified/noncanonical
owners and digest drift, and require behavioral red then green. no automatic
fallback or invented baseline. each registration proves only its named risk.

acceptance: the controller mechanism itself fails behaviorally against BASE;
its corrected policy/routes pass real repository fixtures and existing guards.
each newly opted-in reader proof receives independent review and same-run
fault sensitivity in the PR portfolio.
