# bounded table continuation

status: open
origin: 2026-09-13 bounded-workspace implementation
area: immutable reader publication and rendering

the original `reader_publication_units.py` treated tables as atomic. the staged
replacement now emits bounded excerpts (small-source kernel green
`c6dda79f655206e3`, original-source red `0dc32a58890e91da`); real publication,
accessibility and maximum-source qualification remain open. the existing 64-mib encoded reader envelope admits larger tables than the
experimental unit profile. browser receipt `a6b1e927cbd3818f` measured a 2-mib
dense table at 309,408 dom nodes and about 351 mib of embedder heap for one view;
two views approached 970 mib. a larger atomic allowance is not qualified.

implement the reviewed oversized-table excerpts: preserve logical grid positions,
spans, source caption/header access, exact canonical ranges, images and empty cells.
keep intact layout when it fits. one cell's arbitrarily long explicit header list
must also have bounded access; repeating that list in every continued unit is not
a bounded solution. prepare references in the existing two-pass temporary staging
owner, before publication.

acceptance: dense corpus plus oversized individual cells, rowspan/colspan,
explicit header lists, caption and image-only headers all remain traversable;
each source text range occurs once; no dangling accessibility references; every
encoded/expanded unit and context read obeys its qualified limit. failed preparation
retains the previous publication pointer.

2026-09-14 source allocation review: `ReaderTableSource.canonical_ranges` used
`CanonicalTextBuilder.build_with_source_starts` for a whole fragment, costing an
8-byte source offset per canonical point before other buffers. 64-mib ascii would
add 512 mib; small greens do not qualify this. all-ordinary fragments now skip
that projection. sparse marker mapping now passes the independent nfc, reordered
marks, hangul, emoji and separator corpus in `bd8ea004677d16d3` (kernel passed;
the overall run later failed an unrelated service fixture). the same primitive
now replaces the full array plus sorted list on requested element-anchor reads;
that additional cut awaits its focused replay. largest source and indivisible
normalization-cluster costs remain unqualified.
