/**
 * UNQUALIFIED experiment inputs. Release requires maximum-workload browser
 * receipts for this exact profile; payload reservations are not JS/Blink heap.
 */
export const READER_CAPACITY = {
  descriptorBytes: 16 * 1_024,
  indexBytes: 256 * 1_024,
  unitBytes: 256 * 1_024,
  unitCodePoints: 65_536,
  unitDomNodes: 8_192,
  cache: { maxPayloadBytes: 32 * 1_024 * 1_024, maxReads: 2, reservedViewReads: 1 },
  view: { maxPayloadBytes: 8 * 1_024 * 1_024, maxLeases: 4, maxDomNodes: 16_384 },
} as const;

export interface ReaderCapacity {
  readonly descriptorBytes: number;
  readonly indexBytes: number;
  readonly unitBytes: number;
  readonly unitCodePoints: number;
  readonly unitDomNodes: number;
  readonly cache: { readonly maxPayloadBytes: number; readonly maxReads: number; readonly reservedViewReads: number };
  readonly view: { readonly maxPayloadBytes: number; readonly maxLeases: number; readonly maxDomNodes: number };
}
