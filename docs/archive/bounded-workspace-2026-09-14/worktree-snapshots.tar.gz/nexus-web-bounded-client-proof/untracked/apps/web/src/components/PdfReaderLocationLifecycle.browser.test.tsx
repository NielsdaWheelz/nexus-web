import { render, screen, waitFor } from "@testing-library/react";
import { page, userEvent } from "vitest/browser";
import { expect, it, vi } from "vitest";
import "pdfjs-dist/web/pdf_viewer.css";
import { MobileViewportProvider } from "@/lib/mobileViewport/MobileViewportProvider";
import { ShareControllerProvider } from "@/lib/sharing/controller";
import { MobileChromeProvider } from "@/lib/workspace/mobileChrome";
import { onePagePdf } from "./__tests__/pdfFixtures";
import { LocationReader, QUADS } from "./__tests__/pdfLocation";

it("resumes the same PDF target after callback replacement and drops cancelled frame geometry", async () => {
  await page.viewport(1280, 800);
  const url = URL.createObjectURL(onePagePdf("Retained PDF callback"));
  let reads = 0;
  const quads = new Proxy(QUADS, {
    get(target, key, receiver) {
      reads++;
      return Reflect.get(target, key, receiver);
    },
  });
  const outcomes = new Map<number, string>();
  const view = render(
    <MobileViewportProvider>
      <MobileChromeProvider>
        <ShareControllerProvider>
          <LocationReader
            url={url}
            quads={quads}
            observe={(id, outcome) => outcomes.set(id, outcome)}
          />
        </ShareControllerProvider>
      </MobileChromeProvider>
    </MobileViewportProvider>,
  );
  let pageElement: HTMLElement | null = null;
  let parent: HTMLElement | null = null;
  try {
    const textLayer = await screen.findByTestId(
      "pdf-page-text-layer-1",
      {},
      { timeout: 10000 },
    );
    await waitFor(() =>
      expect(
        screen.getByRole("status", { name: "reader ready" }).textContent,
      ).toBe("true"),
    );
    // eslint-disable-next-line testing-library/no-node-access -- justify-eslint-override: external PDF.js layout interruption requires detaching its actual page node.
    pageElement = textLayer.closest<HTMLElement>(".page");
    // eslint-disable-next-line testing-library/no-node-access -- justify-eslint-override: retain the exact external page parent for restoration after the controlled layout interruption.
    parent = pageElement?.parentElement ?? null;
    if (!pageElement || !parent)
      throw new Error("PDF.js did not install a page");
    const frames = new Map<number, FrameRequestCallback>();
    const cancelled: FrameRequestCallback[] = [];
    let nextFrame = 1000000000;
    const originalCancel = window.cancelAnimationFrame.bind(window);
    vi.stubGlobal("requestAnimationFrame", (callback: FrameRequestCallback) => {
      const id = ++nextFrame;
      frames.set(id, callback);
      return id;
    });
    vi.stubGlobal("cancelAnimationFrame", (id: number) => {
      const callback = frames.get(id);
      if (callback) {
        cancelled.push(callback);
        frames.delete(id);
      } else originalCancel(id);
    });
    pageElement.remove();
    await userEvent.click(
      screen.getByRole("button", { name: "locate target" }),
    );
    await waitFor(() => expect(frames.size).toBeGreaterThan(0));
    await userEvent.click(
      screen.getByRole("button", { name: "replace layout callback" }),
    );
    parent.append(pageElement);
    const callbacks = [...frames.values()];
    frames.clear();
    vi.unstubAllGlobals();
    for (const callback of callbacks) callback(performance.now());
    await waitFor(
      () =>
        expect(
          outcomes.get(1),
          "PDF location stalled after its layout callback changed",
        ).toBe("true:0"),
      { timeout: 4000 },
    );
    const settledReads = reads;
    for (const callback of cancelled) callback(performance.now());
    expect(reads, "retired PDF frame still read borrowed geometry").toBe(
      settledReads,
    );
  } finally {
    vi.unstubAllGlobals();
    if (pageElement && parent && !pageElement.isConnected)
      parent.append(pageElement);
    view.unmount();
    URL.revokeObjectURL(url);
  }
});
