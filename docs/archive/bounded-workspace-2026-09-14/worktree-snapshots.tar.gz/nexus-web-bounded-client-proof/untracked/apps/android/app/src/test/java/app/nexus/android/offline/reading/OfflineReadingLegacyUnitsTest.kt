package app.nexus.android.offline.reading

import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.io.IOException
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class OfflineReadingLegacyUnitsTest {
    @get:Rule val temporary = TemporaryFolder()

    @Test
    fun `interrupted conversion resumes exact original text within unit limits`() {
        val source = temporary.newFolder()
        val staging = temporary.newFolder()
        val mediaId = UUID.fromString("00000000-0000-4000-8000-000000000007")
        val fragmentId = "retained-opaque-fragment"
        val prefix = "<p>A<span>e</span><b>&#x301;</b>🧠</p>".repeat(48)
        val middle = "x".repeat(65534 - 48 * 4)
        val html = "$prefix<p>${middle}e<span>&#x301;</span>🧠${" tail".repeat(300)}</p>"
        val canonical = "Aé🧠\n".repeat(48) + middle + "é🧠" + " tail".repeat(300)
        val bytes = JSONObject().put("readerContractVersion", 1).put("mediaId", mediaId.toString())
            .put("mediaKind", "WebArticle").put("title", "Retained source")
            .put("navigation", JSONArray().put(JSONObject().put("fragmentId", fragmentId).put("label", "Source")))
            .put("fragments", JSONArray().put(JSONObject().put("fragmentId", fragmentId).put("ordinal", 0)
                .put("htmlSanitized", html).put("canonicalText", canonical)))
            .toString().toByteArray()
        File(source, "reader.json").writeBytes(bytes)
        val entries = listOf(OfflineReadingManifestEntry("reader.json", "application/json", bytes.size.toLong(), sha256Hex(bytes)))
        val manifest = OfflineReadingManifest(mediaId, OfflineReadingMediaKind.WebArticle, "Retained source", 7,
            OfflineReadingRevision.compute(7, entries), entries, 1)
        stageLegacyReaderSource(source, manifest, staging, NoOpDurability)
        assertThrows(IOException::class.java) {
            stageLegacyReaderUnits(staging, manifest, object : OfflineReadingDurability {
                override fun syncTree(directory: File) = Unit
                override fun syncDirectory(directory: File) {
                    if (directory.name == "units") throw IOException("interrupted before fragment checkpoint")
                }
            })
        }
        SQLiteDatabase.openOrCreateDatabase(File(staging, "source.sqlite"), null).use { database ->
            database.rawQuery("SELECT count(*) FROM units_complete", null).use { it.moveToFirst(); assertEquals(0, it.getInt(0)) }
        }
        repeat(2) { stageLegacyReaderUnits(staging, manifest, NoOpDurability) }
        val retained = StringBuilder()
        var extent = 0L
        var count = 0
        SQLiteDatabase.openOrCreateDatabase(File(staging, "source.sqlite"), null).use { database ->
            database.rawQuery("SELECT member_key, bytes, sha256 FROM publication_units ORDER BY ordinal", null).use { rows ->
                while (rows.moveToNext()) {
                    val file = File(staging, "publication/${rows.getString(0)}")
                    assertEquals(rows.getLong(1), file.length())
                    assertEquals(rows.getString(2), file.sha256Hex())
                    assertTrue(file.length() <= OFFLINE_READING_MAX_PUBLICATION_MEMBER_BYTES)
                    val unit = JSONObject(file.readText())
                    assertEquals(fragmentId, unit.getString("fragment_id"))
                    assertEquals(extent, unit.getLong("start_cp"))
                    val text = unit.getString("canonical_text")
                    val length = text.codePointCount(0, text.length)
                    assertTrue(length <= OFFLINE_READING_MAX_UNIT_CODEPOINTS)
                    assertTrue(unit.getJSONArray("render_nodes").length() <= OFFLINE_READING_MAX_UNIT_DOM_NODES - 2)
                    assertTrue(unit.isNull("word_boundaries"))
                    extent += length
                    assertEquals(extent, unit.getLong("end_cp"))
                    retained.append(text)
                    count++
                }
            }
        }
        assertTrue("fixture did not cross a publication unit", count > 1)
        assertEquals("converted units changed original canonical text", canonical, retained.toString())
        assertTrue("conversion changed the only installed source", bytes.contentEquals(File(source, "reader.json").readBytes()))
    }
}
