package app.nexus.android.offline.reading

import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.io.IOException
import java.util.concurrent.Executor
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class OfflineReadingLegacyActivationTest {
    @get:Rule val temporary = TemporaryFolder()

    @Test
    fun `failed atomic activation retains original then offline retry preserves exact pending rows`() {
        for ((hasTable, html) in listOf(
            true to "<table><tr><td rowspan=\"65534\">reader text</td></tr></table>",
            false to "<p>reader text</p>",
        )) {
            val fixture = InstalledLegacyReadingFixture(temporary.newFolder(), html)
            val context = fixture.context
            val database = fixture.database
            val root = fixture.root
            val binding = fixture.binding
            val packageId = fixture.packageId
            val media = fixture.media
            val seal = fixture.seal
            val installedDirectory = fixture.installedDirectory
            val reader = fixture.reader
            val revision = fixture.revision
            val locator = fixture.locator
            val pending = row(database.readableDatabase, "offline_reader_progress_pending")
            val baseline = row(database.readableDatabase, "offline_reader_progress_baselines")
            val originalPackage = row(database.readableDatabase, "offline_reader_packages")
            var failCommitSync = true
            val durability = object : OfflineReadingDurability {
                override fun syncTree(directory: File) = HostReadingFilesystemDurability.syncTree(directory)
                override fun syncDirectory(directory: File) {
                    if (directory == File(root, binding.toString()) && failCommitSync) {
                        failCommitSync = false
                        throw IOException("disk failure after candidate rename, before installed row commit")
                    }
                    HostReadingFilesystemDurability.syncDirectory(directory)
                }
            }
            // Conversion must not reach the network to rescue an old generation,
            // so the only origin this scenario can construct refuses to exist.
            fun openStore() = OfflineReadingStore(context, database = database, seal = seal,
                rootDirectory = root, durability = durability, integrityExecutor = Executor(Runnable::run),
                progressOriginFactory = OfflineReaderProgressOriginFactory {
                    error("local conversion must not reach the progress origin")
                })
            try {
                val store = openStore()
                assertEquals("failed conversion must remain locally retryable", OfflineReadingAvailability.UpgradeRequired,
                    store.snapshot().items.single().availability)
                assertTrue(reader.contentEquals(File(installedDirectory, "reader.json").readBytes()))
                assertEquals(packageId.toString(), row(database.readableDatabase, "offline_reader_packages").getValue("id"))
                assertEquals("failed activation changed original package metadata", originalPackage,
                    row(database.readableDatabase, "offline_reader_packages"))
                assertThrows(IllegalStateException::class.java) { store.open(media) }
                assertEquals(pending, row(database.readableDatabase, "offline_reader_progress_pending"))
                assertEquals(baseline, row(database.readableDatabase, "offline_reader_progress_baselines"))
                // The stored binding requires remote authorization; local conversion must not.
                val retried = store.retry(media)
                assertTrue(retried.items.single().availability is OfflineReadingAvailability.Ready)
                database.readableDatabase.rawQuery("SELECT count(*) FROM offline_reader_progress_pending", null).use {
                    check(it.moveToFirst())
                    assertEquals("migration changed durable pending intent", 1L, it.getLong(0))
                }
                assertEquals("migration changed durable pending intent", pending, row(database.readableDatabase, "offline_reader_progress_pending"))
                assertEquals("migration changed canonical baseline", baseline, row(database.readableDatabase, "offline_reader_progress_baselines"))
                val installed = row(database.readableDatabase, "offline_reader_packages")
                assertEquals("2", installed.getValue("package_schema_version"))
                assertNotEquals(packageId.toString(), installed.getValue("id"))
                assertNotEquals(revision, installed.getValue("reader_revision_key"))
                assertEquals("7", installed.getValue("reader_generation"))
                val finalDirectory = File(root, "$binding/${installed.getValue("id")}")
                assertEquals(finalDirectory.walkTopDown().filter(File::isFile).sumOf(File::length),
                    installed.getValue("size_bytes")!!.toLong())
                if (hasTable) {
                    assertEquals(File(finalDirectory, OFFLINE_READING_TABLE_INDEX_NAME).sha256Hex(), installed.getValue("table_index_sha256"))
                } else assertNull("table-free conversion invented a derived index", installed.getValue("table_index_sha256"))
                assertFalse(installedDirectory.exists())
                val lease = openStore().open(media)
                assertEquals(7L, lease.readerGeneration)
                val progress = lease.progress as NativeReaderProgressView.Pending
                assertEquals(locator, progress.deviceLocatorJson)
                val descriptor = JSONObject(lease.resolveEntry("descriptor.json").file.readText())
                val unit = JSONObject(lease.resolveEntry(descriptor.getJSONObject("first_unit_ref").getString("key")).file.readText())
                assertEquals("reader text", unit.getString("canonical_text"))
                assertEquals("intro", unit.getString("fragment_id"))
                assertEquals(0L, unit.getLong("start_cp"))
                if (hasTable) {
                    assertTrue(!descriptor.isNull("table_metadata_ref"))
                    assertThrows(IllegalArgumentException::class.java) { lease.resolveEntry(OFFLINE_READING_TABLE_INDEX_NAME) }
                }
            } finally {
                fixture.close()
            }
        }
    }

    private fun row(database: SQLiteDatabase, table: String): Map<String, String?> =
        database.rawQuery("SELECT * FROM $table", null).use { cursor ->
            check(cursor.moveToFirst())
            cursor.columnNames.mapIndexed { index, name -> name to cursor.getString(index) }.toMap()
                .also { check(!cursor.moveToNext()) }
        }
}
