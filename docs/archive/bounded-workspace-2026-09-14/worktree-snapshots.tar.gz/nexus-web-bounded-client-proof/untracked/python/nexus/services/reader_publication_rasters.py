"""Preparation-only full raster decoding; its worker cost still needs qualification.

This deliberately loads every frame. Pillow's GIF metadata walk omits later
canvas growth, and ICO directory dimensions need not describe embedded pixels.
The result attests conservative oriented surfaces, never intrinsic layout size.
Original bytes and animation remain unchanged. This is not a predecode bound.
"""

import io

from PIL import Image
from PIL.IcoImagePlugin import IcoImageFile

from nexus.schemas.reader_publication import ReaderPublicationRaster
from nexus.services.image_validation import (
    IMAGE_FORMAT_MIME_TYPES,
    prepare_image_validation_bytes,
    read_exif_orientation,
)


def inspect_reader_raster(data: bytes) -> tuple[str, ReaderPublicationRaster]:
    """Decode one original in the existing single-job preparation process.

    The web proxy's dimension policy does not apply to EPUB figures. Physical
    worker admission owns this allocation experiment; memory failure must not
    be relabeled as malformed content or successful capacity support.
    """
    validation, orientation = prepare_image_validation_bytes(data)
    maximum = Image.MAX_IMAGE_PIXELS
    Image.MAX_IMAGE_PIXELS = None
    try:
        with Image.open(
            io.BytesIO(validation), formats=("PNG", "JPEG", "GIF", "WEBP", "BMP", "ICO", "AVIF")
        ) as source:
            media_type = IMAGE_FORMAT_MIME_TYPES[(source.format or "").lower()]
            width = height = count = 0

            def include(frame: Image.Image) -> None:
                nonlocal width, height, count
                frame.load()
                rotation = orientation
                if source.format not in {"JPEG", "PNG"} and (exif := frame.info.get("exif")):
                    rotation = read_exif_orientation(memoryview(exif))
                frame_width, frame_height = frame.size
                if rotation in (5, 6, 7, 8):
                    frame_width, frame_height = frame_height, frame_width
                width, height = max(width, frame_width), max(height, frame_height)
                count += 1

            if isinstance(source, IcoImageFile):
                for index in range(len(source.ico.entry)):
                    with source.ico.frame(index) as frame:
                        include(frame)
            else:
                while True:
                    include(source)
                    try:
                        source.seek(count)
                    except EOFError:
                        break
            return media_type, ReaderPublicationRaster(
                width=width, height=height, frame_count=count
            )
    finally:
        Image.MAX_IMAGE_PIXELS = maximum
