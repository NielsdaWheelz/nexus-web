"""Expensive route work retains its permit across client cancellation and send."""

import asyncio
from pathlib import Path
from threading import Event
from typing import Annotated

import httpx
import pytest
from fastapi import APIRouter, Depends, Request
from fastapi.routing import APIRoute
from sqlalchemy import text
from sqlalchemy.orm import Session
from starlette.types import Message, Receive, Scope, Send

import nexus
from nexus.api.read_admission import (
    AdmittedPackageTransferRoute,
    AdmittedReadRoute,
    ReadAdmission,
)
from nexus.api.routes import offline_reading
from nexus.db.session import get_db
from nexus.logging import request_id_var
from tests.testkit.auth import UserRecord
from tests.testkit.read_admission import production_read_app


def test_cancelled_sync_read_retains_admission_until_its_response_finishes(
    db_session: Session, test_user: UserRecord
) -> None:
    async def scenario() -> None:
        loop = asyncio.get_running_loop()
        entered = asyncio.Event()
        response_finished = asyncio.Event()
        release = Event()
        calls = 0
        transactions = []
        app, headers = production_read_app(db_session, test_user)
        router = APIRouter(route_class=AdmittedReadRoute)

        def materialize(db: Annotated[Session, Depends(get_db)]) -> dict:
            nonlocal calls
            calls += 1
            assert request_id_var.get() == "read-admission"
            transaction = db.scalar(text("SELECT txid_current()"))
            loop.call_soon_threadsafe(entered.set)
            assert release.wait(timeout=5), "the test did not release its materializing thread"
            assert request_id_var.get() == "read-admission"
            transactions.append((transaction, db.scalar(text("SELECT txid_current()"))))
            return {"value": "read"}

        router.add_api_route("/read", materialize, methods=["GET"])
        app.include_router(router)

        @app.get("/progress")
        def progress() -> dict:
            return {"saved": True}

        async def wire(scope: Scope, receive: Receive, send: Send) -> None:
            async def sent(message: Message) -> None:
                await send(message)
                if scope["path"] == "/read" and message["type"] == "http.response.body":
                    if message.get("body") == b'{"value":"read"}':
                        response_finished.set()

            await app(scope, receive, sent)

        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=wire), base_url="http://test", headers=headers
        ) as client:
            opening = asyncio.create_task(client.get("/read"))
            try:
                await asyncio.wait_for(entered.wait(), timeout=5)
                for _ in range(2):
                    opening.cancel()
                    assert (await client.get("/progress")).json() == {"saved": True}
                    assert not opening.done(), (
                        "cancellation unwound request session ownership early"
                    )
                busy = await client.get("/read")
                assert busy.status_code == 503, "cancelled sync work released foreground admission"
                assert busy.json()["error"]["code"] == "E_READ_CAPACITY"
                assert busy.headers["retry-after"] == "1"
                assert busy.headers["x-request-id"] == "read-admission"
                assert "nexus_auth" in busy.headers["server-timing"]
                assert calls == 1, "overload ran another materializing dependency"
                assert (await client.get("/progress")).json() == {"saved": True}
            finally:
                release.set()
                await asyncio.wait_for(response_finished.wait(), timeout=5)
                with pytest.raises(asyncio.CancelledError):
                    await opening
            assert (await client.get("/read")).status_code == 200
            assert all(before == after for before, after in transactions), (
                "request cleanup closed the synchronous worker's transaction after cancellation"
            )

    asyncio.run(scenario())


def test_read_admission_precedes_dependencies_and_covers_body_transfer(
    db_session: Session, test_user: UserRecord
) -> None:
    async def scenario() -> None:
        started = asyncio.Event()
        release = asyncio.Event()
        dependency_calls = 0
        body_receives = 0
        app, headers = production_read_app(db_session, test_user)
        router = APIRouter(route_class=AdmittedReadRoute)

        def dependency() -> None:
            nonlocal dependency_calls
            dependency_calls += 1

        @router.get("/read", dependencies=[Depends(dependency)])
        def read() -> dict:
            return {"value": "read"}

        @router.post("/contributors/capacity-proof", dependencies=[Depends(dependency)])
        def read_body(body: dict) -> dict:
            return body

        app.include_router(router)

        async def wire(scope: Scope, receive: Receive, send: Send) -> None:
            async def counted_receive() -> Message:
                nonlocal body_receives
                if scope["path"] == "/contributors/capacity-proof":
                    body_receives += 1
                return await receive()

            async def blocked_send(message: Message) -> None:
                if (
                    message["type"] == "http.response.body"
                    and message.get("body") == b'{"value":"read"}'
                ):
                    started.set()
                    await release.wait()
                await send(message)

            await app(scope, counted_receive, blocked_send)

        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=wire), base_url="http://test", headers=headers
        ) as client:
            opening = asyncio.create_task(client.get("/read"))
            try:
                await asyncio.wait_for(started.wait(), timeout=5)
                busy = await client.get("/read")
                assert busy.status_code == 503, "body transfer escaped read admission"
                assert dependency_calls == 1, "rejected read entered dependency materialization"
                rejected_body = await client.post(
                    "/contributors/capacity-proof",
                    content=b"{malformed",
                    headers={"Content-Type": "application/json"},
                )
                assert rejected_body.status_code == 503, "JSON parsed before route admission"
                assert body_receives == 0, "overloaded route read its request body"
            finally:
                release.set()
                assert (await opening).status_code == 200
            assert (await client.get("/read")).status_code == 200
            malformed = await client.post(
                "/contributors/capacity-proof",
                content=b"{malformed",
                headers={"Content-Type": "application/json"},
            )
            assert malformed.status_code == 400
            assert malformed.json()["error"]["code"] == "E_INVALID_REQUEST"

    asyncio.run(scenario())


def test_permit_deadline_returns_capacity_and_reports_a_defect(
    db_session: Session, test_user: UserRecord
) -> None:
    """A transfer no client ever finishes must not hold foreground capacity."""

    async def scenario() -> None:
        started = asyncio.Event()
        never = asyncio.Event()
        app, headers = production_read_app(db_session, test_user)
        app.state.read_admission = ReadAdmission(
            max_concurrency=1, deadline_seconds=1, retry_after_seconds=1
        )
        router = APIRouter(route_class=AdmittedReadRoute)

        @router.get("/read")
        def read() -> dict:
            return {"value": "read"}

        app.include_router(router)

        async def wire(scope: Scope, receive: Receive, send: Send) -> None:
            async def stalled_send(message: Message) -> None:
                if (
                    message["type"] == "http.response.body"
                    and message.get("body") == b'{"value":"read"}'
                ):
                    started.set()
                    await never.wait()
                await send(message)

            await app(scope, receive, stalled_send)

        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=wire), base_url="http://test", headers=headers
        ) as client:
            opening = asyncio.create_task(client.get("/read"))
            await asyncio.wait_for(started.wait(), timeout=5)
            assert (await client.get("/read")).status_code == 503, (
                "the stalled transfer released its permit before its deadline"
            )
            with pytest.raises(RuntimeError):
                await asyncio.wait_for(opening, timeout=5)
            assert (await client.get("/read")).status_code == 200, (
                "the expired permit never returned to the foreground pool"
            )

    asyncio.run(scenario())


def test_client_disconnect_on_a_self_read_body_is_not_an_internal_defect(
    db_session: Session, test_user: UserRecord
) -> None:
    """Routes that read their own body classify a hangup exactly as FastAPI's does."""

    async def scenario() -> None:
        app, headers = production_read_app(db_session, test_user)

        @app.post("/contributors/self-read-body")
        async def self_read_body(request: Request) -> dict:
            return {"bytes": len(await request.body())}

        async def wire(scope: Scope, receive: Receive, send: Send) -> None:
            async def disconnecting_receive() -> Message:
                return {"type": "http.disconnect"}

            await app(scope, disconnecting_receive, send)

        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=wire), base_url="http://test", headers=headers
        ) as client:
            response = await client.post("/contributors/self-read-body", content=b'{"a":1}')
            assert response.status_code == 499
            assert response.json()["error"]["code"] == "E_CLIENT_DISCONNECT"

    asyncio.run(scenario())


def test_package_transfer_holds_its_own_budget_and_leaves_reads_admitted(
    db_session: Session, test_user: UserRecord
) -> None:
    """Offline package bytes may fill their own pool without closing the reader."""
    transfer, status = (
        next(
            route
            for route in offline_reading.router.routes
            if isinstance(route, APIRoute) and route.path == path
        )
        for path in (
            "/offline-reading/packages/{media_id}",
            "/media/{media_id}/reader-publications/{generation}/offline-package",
        )
    )
    assert isinstance(transfer, AdmittedPackageTransferRoute)
    assert type(status) is APIRoute, "mint/status lost the lightweight headroom they reserve"

    async def scenario() -> None:
        started = asyncio.Event()
        release = asyncio.Event()
        app, headers = production_read_app(db_session, test_user)
        reads = APIRouter(route_class=AdmittedReadRoute)
        transfers = APIRouter(route_class=AdmittedPackageTransferRoute)

        @reads.get("/read")
        def read() -> dict:
            return {"value": "read"}

        @transfers.get("/transfer")
        def package() -> dict:
            return {"value": "package"}

        app.include_router(reads)
        app.include_router(transfers)

        async def wire(scope: Scope, receive: Receive, send: Send) -> None:
            async def held_send(message: Message) -> None:
                if (
                    message["type"] == "http.response.body"
                    and message.get("body") == b'{"value":"package"}'
                ):
                    started.set()
                    await release.wait()
                await send(message)

            await app(scope, receive, held_send)

        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=wire), base_url="http://test", headers=headers
        ) as client:
            opening = asyncio.create_task(client.get("/transfer"))
            try:
                await asyncio.wait_for(started.wait(), timeout=5)
                busy = await client.get("/transfer")
                assert busy.status_code == 503, "package transfers escaped their budget"
                assert busy.json()["error"]["code"] == "E_READ_CAPACITY"
                assert (await client.get("/read")).status_code == 200, (
                    "a package transfer consumed the reserved foreground read budget"
                )
            finally:
                release.set()
                assert (await opening).status_code == 200

    asyncio.run(scenario())


def test_this_owner_is_the_only_producer_of_the_capacity_code() -> None:
    """`E_READ_CAPACITY` carries exactly one meaning: this pool is momentarily
    full, retry after the advertised seconds, and `retryPolicy.ts` replays it
    three times on that promise. A second producer — a deterministic oversize
    that fails identically on every attempt — would silently restore that replay
    and make a permanently unservable document indistinguishable in telemetry
    from a busy server. Deterministic oversize is `E_READER_CONTENT_TOO_LARGE`
    (422) instead; see tests/service/test_reader_content_too_large.py."""
    package = Path(nexus.__file__).parent
    producers = sorted(
        module.relative_to(package).as_posix()
        for module in package.rglob("*.py")
        if module.name != "errors.py" and "E_READ_CAPACITY" in module.read_text()
    )

    assert producers == ["api/read_admission.py"], (
        f"only the read admission owner may raise the retryable capacity code: {producers}"
    )
