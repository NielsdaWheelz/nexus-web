"""Actual decoded figure facts, including later canvas and embedded icon pixels."""

import base64
import hashlib
import io
import json
import os
from pathlib import Path

from PIL import Image

from nexus.services.reader_publication_rasters import inspect_reader_raster


def test_reader_raster_scan_includes_later_gif_canvas_and_embedded_icon_pixels() -> None:
    frames = []
    for color, size in enumerate(((2, 3), (8, 9))):
        with io.BytesIO() as encoded, Image.new("P", size, color) as frame:
            frame.putpalette([channel for level in range(256) for channel in (level,) * 3])
            frame.save(encoded, format="GIF", optimize=False)
            frames.append(encoded.getvalue())
    # The logical screen starts small; the later image descriptor retains its
    # independently authored larger dimensions. Pillow expands that canvas on
    # actual seek/load, but its n_frames-only walk does not expose the expansion.
    # Keep the first logical screen/global palette; append the independently
    # encoded second image block. The shared palette is identical. This avoids
    # Pillow's animation writer cropping later frames to its first-frame size.
    second_block = 13 + 3 * (2 ** ((frames[1][10] & 7) + 1))
    assert frames[1][second_block : second_block + 9] == b",\x00\x00\x00\x00\x08\x00\x09\x00"
    gif = frames[0][:-1] + frames[1][second_block:]
    with io.BytesIO() as encoded:
        with Image.new("RGBA", (32, 32), "green") as icon:
            icon.save(encoded, format="ICO", sizes=[(16, 16), (32, 32)])
        ico = bytearray(encoded.getvalue())
    assert int.from_bytes(ico[4:6], "little") == 2
    # The smaller directory declaration must not conceal the second 32px PNG.
    ico[22:24] = b"\x08\x08"
    retained = []
    for name, data, expected in (
        ("later-gif-canvas", bytes(gif), ("image/gif", 8, 9, 2)),
        ("embedded-ico-pixels", bytes(ico), ("image/x-icon", 32, 32, 2)),
    ):
        digest = hashlib.sha256(data).hexdigest()
        media_type, facts = inspect_reader_raster(data)
        assert (media_type, facts.width, facts.height, facts.frame_count) == expected
        assert hashlib.sha256(data).hexdigest() == digest
        retained.append(
            {
                "name": name,
                "sha256": digest,
                "source_base64": base64.b64encode(data).decode("ascii"),
                "expected": dict(
                    zip(("media_type", "width", "height", "frame_count"), expected, strict=True)
                ),
            }
        )
    (Path(os.environ["NEXUS_TEST_RESULTS_DIR"]) / "reader-raster-source-facts.json").write_text(
        json.dumps(
            {
                "run_id": os.environ["NEXUS_TEST_RUN_ID"],
                "scope": "independently authored later GIF canvas and concealed ICO pixels; not capacity qualification",
                "cases": retained,
            },
            indent=2,
        )
        + "\n"
    )


def test_reader_raster_scan_keeps_orientation_and_real_animation_facts() -> None:
    for format, expected_type in (
        ("PNG", "image/png"),
        ("JPEG", "image/jpeg"),
        ("WEBP", "image/webp"),
        ("AVIF", "image/avif"),
    ):
        with io.BytesIO() as encoded:
            with Image.new("RGB", (3, 7), "red") as first:
                exif = Image.Exif()
                exif[274] = 6
                first.save(encoded, format=format, exif=exif)
            data = encoded.getvalue()
        media_type, facts = inspect_reader_raster(data)
        assert (media_type, facts.width, facts.height, facts.frame_count) == (
            expected_type,
            7,
            3,
            1,
        )
    with io.BytesIO() as encoded:
        with Image.new("RGB", (5, 9), "red") as first, Image.new("RGB", (5, 9), "blue") as last:
            first.save(encoded, format="WEBP", save_all=True, append_images=[last], duration=20)
        media_type, facts = inspect_reader_raster(encoded.getvalue())
    assert (media_type, facts.width, facts.height, facts.frame_count) == ("image/webp", 5, 9, 2)
    with io.BytesIO() as encoded, Image.new("RGB", (3, 7), "blue") as bitmap:
        bitmap.save(encoded, format="BMP")
        media_type, facts = inspect_reader_raster(encoded.getvalue())
    assert (media_type, facts.width, facts.height, facts.frame_count) == ("image/bmp", 3, 7, 1)
